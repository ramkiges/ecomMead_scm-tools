import setuptools

with open("wsgc/README.md") as fh:
    long_description = fh.read()

setuptools.setup(
    name="wsgc",
    version="0.1.1",
    author="WSI DevOps",
    author_email="eComTahoe@wsgc.com",
    description="A collection of Libraries for common WSGC Devops work",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.wsgc.com/eCommerce-DevOps/scm-tools/tree/master/wsgc",
    packages=setuptools.find_packages(),
    install_requires=[
        'pylint',
        'ldap3',
        'PyYAML',
        'jira',
        'Flask',
        'cassandra-driver',
    ],
    python_requires=">=3",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
)
