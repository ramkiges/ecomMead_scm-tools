#!/bin/env python
"""
Routines for interacting with the WSI Confluence server.

Requires the user to have entered Jira credentials in ~/.credentials (and for some operations, those
need to have admin rights).
"""

import sys
import base64
import json
import requests

from wsgc import util

CONFLUENCE_SERVER_URI = 'https://confluence.wsgc.com'


def _callConfluence(path, action=None, getParams=None, putData=None):
    uri = '{}/rest/api/{}'.format(CONFLUENCE_SERVER_URI, path)

    # Get credentials and connect to Confluence.  The connection can't be reused, so don't bother
    # caching it.
    configSection = 'jira'  # We use Jira credentials for Confluence
    jiraUser = util.getCredential(configSection, 'user')
    jiraPass = util.getCredential(configSection, 'password')
    basicAuthToken = base64.b64encode('{}:{}'.format(jiraUser, jiraPass).encode('utf-8'))

    # Disable warnings, or we'll get a warning about the invalid cert every time we do an operation.
    requests.packages.urllib3.disable_warnings()

    session = requests.Session()
    additionalHeaders = {
        'Authorization': 'Basic {}'.format(basicAuthToken.decode('utf-8')),
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
    session.headers.update(additionalHeaders)

    if action == 'get':
        return session.get(uri, verify=False, params=getParams)

    if action == 'put':
        return session.put(uri, verify=False, data=json.dumps(putData))

    sys.exit("Unexpected action '{}'".format(action))


def getContent(pageSpace, pageTitle):
    # Returns content, contentID (needed for updating the page if you choose), and version (ditto),
    # or None if there's an error getting the page.
    getParams = {
        'spaceKey': pageSpace,
        'title': pageTitle,
        'expand': 'body.storage,version',
    }

    response = _callConfluence(path='content', action='get', getParams=getParams)

    if response.status_code != 200:
        return None, None, None

    data = response.json()

    if len(data['results']) == 0:
        # No such page.
        return None, None, None

    content = data['results'][0]['body']['storage']['value']
    contentID = data['results'][0]['id']
    versionNum = int(data['results'][0]['version']['number'])

    return content, contentID, versionNum


def putContent(contentID, newVersionNum, pageSpace, pageTitle, newContent):
    putData = {
        'id': contentID,
        'type': 'page',
        'space': {'key': pageSpace},
        'title': pageTitle,
        'version': {
            'number': newVersionNum,
            'minorEdit': 'false',
        },
        'body': {
            'storage': {
                'value': newContent,
                'representation': 'storage',
            },
        },
    }

    _callConfluence(path='content/{}'.format(contentID), action='put', putData=putData)
