# WSGC 

A collection of libraries with routines for managing various WSGC tools and tasks including:
- Confluence
- Jira
- LDAP
- GitHub Enterprise
- merges
- Jenkins
- and much, much, more!
