# rundeckTools.py
"""
Library of tools for interacting with Rundeck
"""

import requests

from wsgc import util

# This quiets the squawking about our certs not being signed by a trusted authority.  It may silence
# things we care about more than that, so if we can solve the cert problem some other way that would
# be preferable.
requests.packages.urllib3.disable_warnings()

# Constants used throughout the library.
RUNDECK_API_VERSION = '14'
RUNDECK_HOSTNAME = 'rundeck.wsgc.com'
RUNDECK_API_BASE_URL = f'https://{RUNDECK_HOSTNAME}/rundeck/api/{RUNDECK_API_VERSION}'

# Session cache used by getSession().
_cachedSession = None


def getSession():
    global _cachedSession

    if _cachedSession is None:
        authToken = util.getCredential('rundeck', 'token')
        session = requests.Session()
        additionalHeaders = {
            'X-Rundeck-Auth-Token': authToken,
        }
        session.headers.update(additionalHeaders)
        _cachedSession = session

    return _cachedSession


def callRundeck(path, params=None, headers=None, responseIsJson=True):
    # Return the resource given at uri.
    session = getSession()

    if params is None:
        params = {}

    if headers is None:
        headers = {}

    if 'Accept' not in headers and responseIsJson:
        headers['Accept'] = 'application/json'

    url = f'{RUNDECK_API_BASE_URL}/{path}'

    response = session.get(url, verify=False, params=params, headers=headers)

    # A bad link is an error.
    response.raise_for_status()

    return response.json() if responseIsJson else response.text


def getProjectJobs(*, projectName):
    return callRundeck(f'project/{projectName}/jobs')


def getJobDefinition(*, jobId):
    return callRundeck(f'job/{jobId}', params={'format': 'yaml'}, responseIsJson=False)


def getLastSuccessExecution(jobId):
    return callRundeck(f'job/{jobId}/executions', params={'status': 'succeeded', 'max': 1}, responseIsJson=True)


def getJobExecutionOutputJson(executionId):
    return callRundeck(f'execution/{executionId}/output', responseIsJson=True)


def updateJobDefinitionYaml(*, project, jobContents):
    session = getSession()

    url = f'{RUNDECK_API_BASE_URL}/project/{project}/jobs/import'

    params = {
        'fileFormat': 'yaml',
        'dupeOption': 'update',
        'uuidOption': 'preserve',
    }

    response = util.callURL(url=url,
                            session=session,
                            params=params,
                            action='post',
                            postIsJSON=False,
                            postIsYaml=True,
                            formDict=jobContents)
    return response
