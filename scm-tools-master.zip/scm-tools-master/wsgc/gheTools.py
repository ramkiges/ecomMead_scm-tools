# gheTools.py
"""
Library of tools for interacting with GitHub Enterprise
"""

import sys
import os
import csv
import io
import time
import base64
import re
import subprocess
import enum
import requests

import wsgc.repo

from wsgc import util
from wsgc import semver

# This quiets the squawking about our certs not being signed by a trusted authority.  It may silence
# things we care about more than that, so if we can solve the cert problem some other way that would
# be preferable.
requests.packages.urllib3.disable_warnings()

# Constants used throughout the library.
GHE_HOSTNAME = 'github.wsgc.com'
GHE_API_BASE_URL = 'https://{}/api/v3'.format(GHE_HOSTNAME)

GHE_ADMINS = {
    'ciuser',
    'dstephens',
    'hvenkataraman',
    'jcox4',
    'pharlan',
    'sgaddam',
    'smehta1',
    'svcagitad',
}

# There are two auth tokens we use for talking with GHE: one for "ciuser" and one that has admin
# access.  For most of the read-only types of operations we do, the admin token is preferred because
# we tend to do admin-y things when reading GHE (user reports, existence of branches, etc.)  But
# when setting statuses on PRs, that's a CI function, and we want to use the "ciuser" token so it
# shows up in the interface as being done by CI, and not by one of our admins.
#
# These are the allowable values for 'sessionKeyName' below.  They will be used to look up the
# corresponding token values in ~/.credentials.
_GHE_CIUSER_KEY_NAME = 'ciuser_org_owner_token'
_GHE_ADMIN_KEY_NAME = 'ghe_admin_token'
_GHE_PRE_RECEIVE_ADMIN_KEY_NAME = 'ghe_pre_receive_hook_admin_token'

# Give names and centralized descriptions to the PR statuses we'll use.
GHE_STATUS_SEMVER_TAG = 'ci-semver-tag'
GHE_STATUS_CI_JENKINSFILE = 'ci-jenkinsfile-check'
GHE_STATUS_CI_UPDATE_SEMVER = 'ci-update-semver-check'
GHE_STATUS_CI_KEEP_SEMVER = 'ci-keep-semver-check'
GHE_STATUS_CI_AUTO_MERGABLE = 'ci-check-auto-mergability'
GHE_STATUS_PR_TAG_CONVENTION = 'ci-pr-tag'


GHE_STATUSES = {
    GHE_STATUS_SEMVER_TAG: {
        'description': 'Find semantic versioning tag in PR title'
    },
    GHE_STATUS_CI_JENKINSFILE: {
        'description': 'Block merging of branch-specific Jenkinsfile changes'
    },
    GHE_STATUS_CI_UPDATE_SEMVER: {
        'description': 'Ensure project has updated semver'
    },
    GHE_STATUS_CI_KEEP_SEMVER: {
        'description': 'Ensure project has not updated its semver'
    },
    GHE_STATUS_CI_AUTO_MERGABLE: {
        'description': 'Check whether project is auto-mergable'
    },
    GHE_STATUS_PR_TAG_CONVENTION: {
        'description': 'Find tags(JIRA/INC/SERREQ/EMERGENCY/CLEANUP) in PR title and commits'
    },
}

GHE_STATE_PENDING = 'pending'
GHE_STATE_SUCCESS = 'success'
GHE_STATE_ERROR = 'error'
GHE_STATE_FAILURE = 'failure'
GHE_STATUS_VALID_STATES = [GHE_STATE_PENDING, GHE_STATE_SUCCESS, GHE_STATE_ERROR, GHE_STATE_FAILURE]

# Names for legal enforcement values for pre-receive hooks.
# Skip 'testing', because it doesn't work from the API despite being
# documented to.
PRE_RECEIVE_ENABLED = 'enabled'
PRE_RECEIVE_DISABLED = 'disabled'

PRE_RECEIVE_ENFORCEMENT_VALUES = {PRE_RECEIVE_ENABLED, PRE_RECEIVE_DISABLED}

# Translate permission names from what we think of them to the
# keywords that GHE expects.
PERMISSION_TRANSLATIONS = {  # ourName -> gheName
    'read': 'pull',
    'write': 'push',
    'admin': 'admin',
}

# The default branch name site-wide.
DEFAULT_DEFAULT_BRANCH = 'release'


class GHEError(Exception):
    """
    Exception thrown when GHE doesn't like the data we passed for whatever reason.
    """


# Session cache used by getSession().
_cachedSessions = {}


def getSession(*, sessionKeyName):
    try:
        session = _cachedSessions[sessionKeyName]
    except KeyError:
        authToken = util.getCredential('github', sessionKeyName)
        session = requests.Session()
        additionalHeaders = {
            'Authorization': 'token {}'.format(authToken),
            'Accept': 'application/vnd.github.v3+json',
        }
        session.headers.update(additionalHeaders)
        _cachedSessions[sessionKeyName] = session

    # Validate the session.
    data = session.get(GHE_API_BASE_URL + '/meta', verify=False).json()
    if 'message' in data:
        sys.exit('Error talking to GitHub Enterprise: {}'.format(data['message']))

    return session


def _getGHEListResource(ghePath, accumulator, sessionKeyName, params=None, headers=None):
    # Return a list of the resources given at uri, using the provided accumulator (which will be
    # specific to the type of content returned by the uri).  Follows 'next' links, to handle paging
    # of resources by GHE.
    session = getSession(sessionKeyName=sessionKeyName)
    retval = []

    if params is None:
        params = {}

    if headers is None:
        headers = {}

    # Start with the normal URL; as we loop, it will take on successive page values.
    nextPageLink = GHE_API_BASE_URL + ghePath
    isFirstPage = True

    while True:
        response = session.get(nextPageLink, verify=False, params=params, headers=headers)

        if isFirstPage and response.status_code != 200:
            # Not an error, there just must not have been any of this resource.
            break

        # After the first page, a bad link is an error.
        response.raise_for_status()
        isFirstPage = False

        retval += accumulator(response.json())

        if 'next' in response.links:
            nextPageLink = response.links['next']['url']
        else:
            break

    return retval


def _getGHESingleResource(ghePath, sessionKeyName, params=None, headers=None):
    # Return the resource given at uri.
    session = getSession(sessionKeyName=sessionKeyName)

    if params is None:
        params = {}

    if headers is None:
        headers = {}

    # Start with the normal URL; as we loop, it will take on successive page values.
    url = GHE_API_BASE_URL + ghePath

    response = session.get(url, verify=False, params=params, headers=headers)

    # A bad link is an error.
    response.raise_for_status()

    return response.json()


def _postGHEForm(ghePath, sessionKeyName, formDict=None):
    """Post the given form to GHE"""
    session = getSession(sessionKeyName=sessionKeyName)

    url = GHE_API_BASE_URL + ghePath

    util.callURL(url=url, session=session, action='post', formDict=formDict)


def dictLookupAccumulatorFactory(key, itemFilter=None):
    if itemFilter is None:
        itemFilter = lambda x: True

    return lambda jsonResponse: [d[key] for d in jsonResponse if itemFilter(d)]


def onlyListsAccumulator(jsonResponse):
    # Non-list response means there were no values for this response, and isn't an error.
    return jsonResponse if isinstance(jsonResponse, list) else []


def getOrgNames():
    return _getGHEListResource(ghePath='/organizations',
                               accumulator=dictLookupAccumulatorFactory('login'),
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getOrgMembers(*, orgName, role='all'):
    if role not in ('all', 'admin', 'member'):
        raise ValueError("unknown org role spec '{}'".format(role))

    return _getGHEListResource(ghePath='/orgs/{}/members'.format(orgName),
                               accumulator=dictLookupAccumulatorFactory('login'),
                               params={'role': role},
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getOrgRepoNames(orgName, includeArchived=True):
    if includeArchived:
        itemFilter = lambda x: True
    else:
        itemFilter = lambda x: not x['archived']

    return _getGHEListResource(ghePath='/orgs/{}/repos'.format(orgName),
                               accumulator=dictLookupAccumulatorFactory('name', itemFilter=itemFilter),
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getBranchNames(orgName, repoName):
    return _getGHEListResource(ghePath='/repos/{}/{}/branches'.format(orgName, repoName),
                               accumulator=dictLookupAccumulatorFactory('name'),
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getBranch(orgName, repoName, branchName):
    return _getGHESingleResource(ghePath='/repos/{}/{}/branches/{}'.format(orgName, repoName, branchName),
                                 sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getTagNames(orgName, repoName):
    return _getGHEListResource(ghePath='/repos/{}/{}/tags'.format(orgName, repoName),
                               accumulator=dictLookupAccumulatorFactory('name'),
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getTags(orgName, repoName):
    return _getGHEListResource(ghePath='/repos/{}/{}/tags'.format(orgName, repoName),
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getPRs(orgName, repoName):
    # Return a list of URLs of PRs targeting the org/repo.
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/pulls',
                               accumulator=dictLookupAccumulatorFactory('html_url'),
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)


def getClosedPRs(orgName, repoName):
    # Return a list of URLs of PRs targeting the org/repo.
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/pulls',
                               accumulator=onlyListsAccumulator,
                               params={'state': 'closed'},
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)


def getPRCommits(orgName, repoName, prNumber):
    # Return a list of URLs of PRs targeting the org/repo.
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/pulls/{prNumber}/commits',
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)

def getPRsHavingCommit(orgName, repoName, commit):
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/commits/{commit}/pulls',
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)


def getPRLabels(orgName, repoName, prNumber):
    """ Return a list of labels for a given PR."""
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/issues/{prNumber}/labels',
                               accumulator=dictLookupAccumulatorFactory('name'),
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)


def addPRLabel(orgName, repoName, prNumber, labelName):
    """ Add a label to a given PR."""
    url = '{}/repos/{}/{}/issues/{}/labels'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    params = {
        'labels': [labelName],
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                 formDict=params,
                 action='post')


def addPRReview(orgName, repoName, prNumber, reviewStatus, reviewComment):
    """ Add a review to a given PR."""
    url = '{}/repos/{}/{}/pulls/{}/reviews'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    params = {
        'body': reviewComment,
        'event': reviewStatus,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                 formDict=params,
                 action='post')


def requestPRReview(orgName, repoName, prNumber, userList=[], groupList=[]):
    """ Request review from users or groups."""
    url = '{}/repos/{}/{}/pulls/{}/requested_reviewers'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    params = {
        'reviewers': userList,
        'team_reviewers': groupList,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                 formDict=params,
                 action='post')


def delPRLabel(orgName, repoName, prNumber, labelName):
    """ Remove a label from a given PR."""
    url = '{}/repos/{}/{}/issues/{}/labels/{}'.format(GHE_API_BASE_URL, orgName, repoName, prNumber, labelName)

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                 action='delete')


def mergePullRequest(orgName, repoName, prNumber, mergeTags, mergeTitle, mergeTriggerType):
    """ Merge a given PR."""
    url = '{}/repos/{}/{}/pulls/{}/merge'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    taggedTitle='[{}] {}. Triggered by {}'.format(mergeTags, mergeTitle, mergeTriggerType)

    params = {
        'commit_title': taggedTitle,
        'merge_method': 'squash',
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                 formDict=params,
                 action='put')


def getPreReceiveHooks(orgName, repoName):
    """List all pre-receive hooks, and their enablement, for the repo."""
    return _getGHESingleResource(ghePath='/repos/{}/{}/pre-receive-hooks'.format(orgName, repoName),
                                 sessionKeyName=_GHE_PRE_RECEIVE_ADMIN_KEY_NAME)


def getPreReceiveHookId(orgName, repoName, hookName):
    """Return the numeric hook id for the given hook."""
    for hook in getPreReceiveHooks(orgName, repoName):
        if hook['name'] == hookName:
            return hook['id']

    raise ValueError('No such hook {}'.format(hookName))


def getPreReceiveHookEnforcement(orgName, repoName, hookName):
    """Return the enforcement for the given hook for this repo."""
    for hook in getPreReceiveHooks(orgName, repoName):
        if hook['name'] == hookName:
            return hook['enforcement']

    raise ValueError('No such hook {}'.format(hookName))


def updatePreReceiveHook(orgName, repoName, preReceiveHookId, newEnforcement):
    """
    Update the enablement of the given hook to the new enforcement.

    You can get the preReceiveHookId from a call to getPreReceiveHookId().
    """
    url = '{}/repos/{}/{}/pre-receive-hooks/{}'.format(GHE_API_BASE_URL,
                                                       orgName, repoName, preReceiveHookId)
    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_PRE_RECEIVE_ADMIN_KEY_NAME),
                 formDict={'enforcement': newEnforcement},
                 action='patch')


def deletePreReceiveHook(orgName, repoName, preReceiveHookId):
    """
    Delete any overridden enforcement on this repo for the given hook.

    You can get the preReceiveHookId from a call to getPreReceiveHookId().
    """
    url = '{}/repos/{}/{}/pre-receive-hooks/{}'.format(GHE_API_BASE_URL,
                                                       orgName, repoName, preReceiveHookId)
    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_PRE_RECEIVE_ADMIN_KEY_NAME),
                 action='delete')


def getPipelineType(orgName, repoName):
    """
    Return the pipeline type of the given repo, or None if we are unable to find
    the repo or a Jenkinsfile.
    """
    try:
        jenkinsFile = getFileContents(orgName=orgName,
                                      repoName=repoName,
                                      path='Jenkinsfile')
    except requests.exceptions.HTTPError:
        return None  # No such repo, or no Jenkinsfile.

    match = re.search(r'^\s*plumber\s*\(\s*["\'](.*?)["\']\s*\)',
                      jenkinsFile,
                      re.MULTILINE)

    return match.group(1) if match else None


def getTeamId(orgName, teamName):
    teamInfo = _getGHESingleResource('/orgs/{}/teams/{}'.format(orgName, teamName),
                                     sessionKeyName=_GHE_CIUSER_KEY_NAME)
    return teamInfo['id']


class RepoPermissions(enum.Enum):
    """
    Enumerate the permissions returned by the GHE API when asking
    what access a team has to a repo.
    """
    ADMIN = 'admin'
    PUSH = 'push'
    PULL = 'pull'


def getTeamRepoPermissions(orgName, repoName, teamName):
    """
    Return a set of RepoPermissions to which the team has been assigned for
    this repository.
    """
    repoPermissions = set()

    try:
        teamId = getTeamId(orgName=orgName, teamName=teamName)

        # This Accept header signals the API to return complete permissions info, and not
        # merely whether the team "manages" the repo.
        permInfo = _getGHESingleResource('/teams/{}/repos/{}/{}'.format(teamId, orgName, repoName),
                                         headers={'Accept': 'application/vnd.github.v3.repository+json'},
                                         sessionKeyName=_GHE_CIUSER_KEY_NAME)
    except requests.exceptions.HTTPError:
        # Either the team name doesn't exist in this org, or it has no permissions
        # in this repo.  Either way, the answer is the empty set.
        return repoPermissions

    for permission, hasPermission in permInfo['permissions'].items():
        if hasPermission:
            repoPermissions.add(RepoPermissions(permission))

    return repoPermissions


def addCollaborator(orgName, repoName, username, permission):
    """
    Add user as a collaborator on the repo, with the given permission.
    """
    # Throws requests.exceptions.HTTPError on error.
    url = '{}/repos/{}/{}/collaborators/{}'.format(GHE_API_BASE_URL, orgName, repoName, username)

    # If caller wants to use "write" instead of "push", let them.
    ghePerm = PERMISSION_TRANSLATIONS.get(permission, permission)

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict={'permission': ghePerm},
                 action='put')


def removeCollaborator(orgName, repoName, username):
    """
    Remove user as a collaborator on the repo.
    """
    # Throws requests.exceptions.HTTPError on error.
    url = '{}/repos/{}/{}/collaborators/{}'.format(GHE_API_BASE_URL, orgName, repoName, username)

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 action='delete')


def addTeamAccess(*, orgName, repoName, teamName, permission):
    """
    Grant team the given access to the repo.
    """
    url = '{}/orgs/{orgName}/teams/{teamName}/repos/{orgName}/{repoName}'. \
        format(GHE_API_BASE_URL,
               orgName=orgName,
               teamName=teamName,
               repoName=repoName)

    # If caller wants to use "write" instead of "push", let them.
    ghePerm = PERMISSION_TRANSLATIONS.get(permission, permission)

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict={'permission': ghePerm},
                 action='put')


def addRepoHook(*, orgName, repoName, hookUrl, events=None):
    """
    Add hook to repo.  Default events are pull_request.
    """
    if not events:
        events = ['pull_request']

    url = '{}/repos/{}/{}/hooks'.format(GHE_API_BASE_URL, orgName, repoName)

    params = {
        'config': {
            'url': hookUrl,
            'content_type': 'json',
        },
        'events': events,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict=params,
                 action='post')


def updateOrgHook(*, orgName, hookId, hookUrl):
    url = '{}/orgs/{}/hooks/{}/config'.format(GHE_API_BASE_URL, orgName, hookId)

    params = {
        'url': hookUrl,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict=params,
                 action='patch')


def updateRepoHook(*, orgName, repoName, hookId, hookUrl):
    url = '{}/repos/{}/{}/hooks/{}/config'.format(GHE_API_BASE_URL, orgName, repoName, hookId)

    params = {
        'url': hookUrl,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict=params,
                 action='patch')


def createRelease(*, orgName, repoName, releaseVersion):
    """
    Create a release from the default branch.
    """
    url = '{}/repos/{}/{}/releases'.format(GHE_API_BASE_URL, orgName, repoName)

    params = {
        'tag_name': releaseVersion,
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict=params,
                 action='post')


def setDefaultBranch(*, orgName, repoName, branchName):
    """
    Make branchName the default branch for the repo.
    """
    # Throws requests.exceptions.HTTPError on error.
    url = '{}/repos/{}/{}'.format(GHE_API_BASE_URL,
                                  orgName,
                                  repoName)

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict={'default_branch': branchName},
                 action='patch')


def getRepoWriters(orgName, repoName):
    def repoWritersAccumulator(jsonResponse):
        theseWriters = []
        for writerInfo in jsonResponse:
            if writerInfo['permissions']['push'] or writerInfo['permissions']['admin']:
                theseWriters.append(writerInfo['login'])
        return theseWriters

    return _getGHEListResource(ghePath='/repos/{}/{}/collaborators'.format(orgName, repoName),
                               accumulator=repoWritersAccumulator,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getUserRepoNames(orgName):
    return _getGHEListResource(ghePath='/users/{}/repos'.format(orgName),
                               accumulator=dictLookupAccumulatorFactory('name'),
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getOrgHooks(orgName):
    return _getGHEListResource(ghePath='/orgs/{}/hooks'.format(orgName),
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getRepoHooks(orgName, repoName):
    return _getGHEListResource(ghePath='/repos/{}/{}/hooks'.format(orgName, repoName),
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getRepoPreReceiveHooks(orgName, repoName):
    return _getGHEListResource(ghePath='/repos/{}/{}/pre-receive-hooks'.format(orgName, repoName),
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_PRE_RECEIVE_ADMIN_KEY_NAME,
                               headers={'Accept': 'application/vnd.github.eye-scream-preview+json'})


def getRepoSource(orgName, repoName):
    """
    Return the root of this repo's network as (org, repo).  (This may be the org and
    repo we were passed, if it's already the root of its network.)
    """
    try:
        repoData = _getGHESingleResource(ghePath='/repos/{}/{}'.format(orgName, repoName),
                                         sessionKeyName=_GHE_ADMIN_KEY_NAME)
    except requests.exceptions.HTTPError:
        raise GHEError("org {} or repo {} not found".format(orgName, repoName))

    if 'source' in repoData:
        # We are a fork.
        return (repoData['source']['owner']['login'],
                repoData['source']['name'])

    # We are the root repo.
    return (orgName, repoName)


def deleteRepoHook(orgName, repoName, hookId):
    util.callURL(url='{}/repos/{}/{}/hooks/{}'.format(GHE_API_BASE_URL, orgName, repoName, hookId),
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 action='delete')


def createRepo(orgName,
               repoName,
               description=None,
               isPrivate=True,
               hasIssues=False,
               hasProjects=False,
               hasWiki=False,
               autoCreateReadme=False,
               allowSquashMerge=True,
               allowMergeCommit=False,
               allowRebaseMerge=False,
               ):
    """
    Create a new repo within an org.
    """
    params = {
        'name': repoName,
        'description': description if description else "",
        'private': isPrivate,
        'has_issues': hasIssues,
        'has_projects': hasProjects,
        'has_wiki': hasWiki,
        'auto_init': autoCreateReadme,
        'allow_squash_merge': allowSquashMerge,
        'allow_merge_commit': allowMergeCommit,
        'allow_rebase_merge': allowRebaseMerge,
    }

    _postGHEForm(ghePath='/orgs/{}/repos'.format(orgName), formDict=params, sessionKeyName=_GHE_ADMIN_KEY_NAME)


def doesBranchExist(orgName, repoName, branchName):
    """
    True if the branch exists (along with the org and repo).  A branch is, e.g., 'master', not
    'refs/heads/master'.
    """
    try:
        _getGHESingleResource(ghePath='/repos/{}/{}/branches/{}'.format(orgName, repoName, branchName),
                              sessionKeyName=_GHE_ADMIN_KEY_NAME)
        return True
    except requests.exceptions.HTTPError:
        return False


def protectBranch(*, orgName, repoName, branchName):
    """
    Add branch protection with reasonable defaults for branchName.

    NOTE: This routine doesn't work, failing with a 422 error (Unprocessable
    Entity).  It's left here for inspiration.
    """
    url = '{}/repos/{}/{}/branches/{}/protection'.format(GHE_API_BASE_URL,
                                                         orgName,
                                                         repoName,
                                                         branchName)
    params = {
        'branch': branchName,
        'required_status_checks': {
            'strict': True,  # Branches must be up-to-date before merging
            'contexts': ['foo'],
            'required_pull_request_reviews': {
                'dismiss_stale_reviews': True,
                'require_approving_review_count': 1,
            },
        }
    }

    util.callURL(url=url,
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 formDict=params,
                 action='put',
                 headers={'Accept': 'application/vnd.github.v3+json'})


def getLicenseInfo():
    return _getGHESingleResource(ghePath='/enterprise/settings/license',
                                 sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getDirListing(orgName, repoName, path, ref=None):
    # Throws requests.exceptions.HTTPError on error.
    params = {}

    if ref:
        params['ref'] = ref

    return _getGHEListResource(ghePath='/repos/{}/{}/contents/{}'.format(orgName, repoName, path),
                               accumulator=lambda x: x,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME,
                               params=params)


def getFileContents(orgName, repoName, path, ref=None, textMode=True):
    # Throws requests.exceptions.HTTPError on error.
    params = {'ref': ref} if ref else {}

    fileInfo = _getGHESingleResource(ghePath='/repos/{}/{}/contents/{}'.format(orgName, repoName, path),
                                     sessionKeyName=_GHE_ADMIN_KEY_NAME,
                                     params=params)

    byteStream = base64.b64decode(fileInfo['content'])

    return byteStream.decode('utf-8') if textMode else byteStream


def suspendUser(username):
    # Throws requests.exceptions.HTTPError on error.
    util.callURL(url='{}/users/{}/suspended'.format(GHE_API_BASE_URL, username),
                 session=getSession(sessionKeyName=_GHE_ADMIN_KEY_NAME),
                 action='put')


def writeStatus(orgName, repoName, commitID, statusName, statusState, targetUrl, description):
    """
    Write a status named 'statusName' to commitID with the value 'state' ('pending', 'success',
    'error' or 'failure').
    """
    session = getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME)

    url = '{}/repos/{}/{}/statuses/{}'.format(GHE_API_BASE_URL, orgName, repoName, commitID)

    formDict = {
        'context': statusName,
        'state': statusState,
        'description': description,
    }

    if targetUrl:
        formDict['target_url'] = targetUrl

    util.callURL(url=url,
                 session=session,
                 action='post',
                 formDict=formDict)


def createRef(orgName, repoName, ref, commitID):
    session = getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME)

    url = '{}/repos/{}/{}/git/refs'.format(GHE_API_BASE_URL, orgName, repoName)

    formDict = {
        'ref': ref,
        'sha': commitID,
    }

    util.callURL(url=url,
                 session=session,
                 action='post',
                 formDict=formDict)


def getStatuses(orgName, repoName, commitID):
    url = '{}/repos/{}/{}/commits/{}/status'.format(GHE_API_BASE_URL, orgName, repoName, commitID)

    response = util.callURL(url=url,
                            session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                            action='get')

    return response.json()


def getCommit(orgName, repoName, commitID):
    url = '{}/repos/{}/{}/commits/{}'.format(GHE_API_BASE_URL, orgName, repoName, commitID)

    response = util.callURL(url=url,
                            session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                            action='get')

    return response.text


def getBranchCommitsSinceDate(orgName, repoName, datetime, branch):
    return _getGHEListResource(ghePath='/repos/{}/{}/commits'.format(orgName, repoName),
                               accumulator=onlyListsAccumulator,
                               params={'since': datetime, 'sha': branch},
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def getBranchCommits(orgName, repoName, branch):
    # Return a list of URLs of PRs targeting the org/repo.
    return _getGHEListResource(ghePath=f'/repos/{orgName}/{repoName}/commits',
                               accumulator=onlyListsAccumulator,
                               params={'sha': branch},
                               sessionKeyName=_GHE_CIUSER_KEY_NAME)


def getPRDiff(orgName, repoName, prNumber):
    url = '{}/repos/{}/{}/pulls/{}'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    # It's the custom header that turns this into a diff.
    response = util.callURL(url=url,
                            session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                            action='get',
                            headers={'Accept': 'application/vnd.github.diff'})

    return response.text


def getPR(orgName, repoName, prNumber):
    url = '{}/repos/{}/{}/pulls/{}'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    # It's the custom header that turns this into a diff.
    response = util.callURL(url=url,
                            session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                            action='get',
                            headers={'Accept': 'application/vnd.github+json'})

    return response.text


def getPRReviews(orgName, repoName, prNumber):
    return _getGHEListResource(ghePath='/repos/{}/{}/pulls/{}/reviews'.format(orgName, repoName, prNumber),
                               accumulator=onlyListsAccumulator,
                               sessionKeyName=_GHE_ADMIN_KEY_NAME)


def parsePRDiff(prDiff):
    """
    Given a textual diff as returned by GH for a PR, return a dictionary of:
      <filename>: [<hunk>, ...]
    This can help the caller focus on changes to the files of interest.
    """
    parsedPRDiff = util.DictionaryOfLists()
    currentFilename = None
    currentHunkLines = None
    inHunk = False

    def saveHunk():
        """Save hunk-in-progress to filename's hunks list"""
        if currentFilename and currentHunkLines:
            hunk = ''.join(x + '\n' for x in currentHunkLines)
            parsedPRDiff.append(currentFilename, hunk)

    for line in prDiff.splitlines():
        match = re.match(r"diff --git a/.* b/(.*)$", line)
        if match:
            # Start of a new file.
            saveHunk()
            currentFilename = match.group(1)
            currentHunkLines = []
            inHunk = False
        elif re.match(r"@@", line):
            # Start of a new hunk.
            saveHunk()
            currentHunkLines = []
            inHunk = True
        elif inHunk:
            currentHunkLines.append(line)

    saveHunk()

    return parsedPRDiff


def checkIfAlreadyMerged(orgName, repoName, prNumber):
    """
    Check whether the given PR was already merged.
    Returns True if so, False if otherwise.
    """
    url = '{}/repos/{}/{}/pulls/{}/merge'.format(GHE_API_BASE_URL, orgName, repoName, prNumber)

    try:
        util.callURL(url=url,
                     session=getSession(sessionKeyName=_GHE_CIUSER_KEY_NAME),
                     action='get')
        # The PR is already merged.
        return True
    except requests.exceptions.HTTPError:
        # The PR isn't already merged or something went wrong
        return False


def checkForAutoMergability(prDiff, semverFilename, searchTemplate):
    """
    Check that the prDiff contains conditions that make the PR eligible to be auto-
    merged.
    Currently, those conditions are:
     - Must be a Helm Project Repo
     - Must contain *only* an updated semver in `project.yaml` and a single updated
       tag in an single `values.yaml`
     - Said updated tag must still be a valid semver

    Returns a (possibly empty) list of violations found (no update,
    bad update, etc.)
    """
    parsedPRDiff = wsgc.gheTools.parsePRDiff(prDiff)

    if len(parsedPRDiff.keys()) != 2:
        return ['Auto-merge not possible (err 1). You can still merge manually.']

    for key in parsedPRDiff.keys():

        bareFilename = (key.split('/'))[-1]
        if bareFilename not in ('project.yaml', 'values.yaml'):
            return ['Auto-merge not possible (err 2). You can still merge manually.']

        totalAdditions = 0
        totalSubtractions = 0
        for hunk in parsedPRDiff[key]:
            for line in hunk.splitlines():
                if not line:
                    continue
        
                if line.startswith('+'):
                    totalAdditions += 1
                    if 'values.yaml' in key:
                        oldTag, newTag = getVersionChangeInHunk(hunk, searchTemplate)
                        if newTag is None:
                            return ['Auto-merge not possible (err 3). You can still merge manually.']
                elif line.startswith('-'):
                    totalSubtractions += 1

        if (totalAdditions > 1) or (totalSubtractions > 1) or ((totalAdditions - totalSubtractions) != 0):
            return ['Auto-merge not possible (err 4). You can still merge manually.']


def checkForUpdatedSemver(prDiff, semverFilename, searchTemplate, shouldUpdateVersion):
    """
    Validate that prDiff either does or does not (according to 'shouldUpdateVersion')
    contain an update to the semver of the project in semverFilename (by looking for
    matches with the searchTemplate regex template), and that the semver update, if
    present, makes sense (e.g., that if a major or minor version gets a bump,
    that the following numbers are zeros.)

    Returns a (possibly empty) list of violations found (no update,
    bad update, etc.)
    """

    oldver, newver = None, None

    parsedPRDiff = wsgc.gheTools.parsePRDiff(prDiff)

    if semverFilename in parsedPRDiff:
        for hunk in parsedPRDiff[semverFilename]:
            try:
                thisOldver, thisNewver = getVersionChangeInHunk(hunk, searchTemplate)
            except ValueError as e:
                return [str(e)]

            if thisOldver is not None:
                if oldver is None:
                    oldver = thisOldver
                else:
                    # We fail the PR when multiple versions are removed because it is more
                    # likely that our version matching logic is wrong than that they are fixing
                    # a config that had specified more than one semver.  Fail the PR in order
                    # to call attention to something we didn't expect.
                    return ['Multiple versions removed from {} ({} and {})'.format(semverFilename,
                                                                                   oldver,
                                                                                   thisOldver)]
            if thisNewver is not None:
                if newver is None:
                    newver = thisNewver
                else:
                    return ['Multiple versions added to {} ({} and {})'.format(semverFilename,
                                                                               newver,
                                                                               thisNewver)]

    if shouldUpdateVersion:
        return wsgc.semver.getSemverBumpViolations(oldver=oldver, newver=newver)

    # Caller requires no version update.
    return [] if (newver is None or (newver is not None and oldver is None) or (newver == oldver)) else ['PR changes project version, which should be left alone']


def getVersionChangeInHunk(hunk, searchTemplate):
    """
    Examine hunk for an update to the project's semver, and
    return (oldSemver, newSemver).

    searchTemplate should locate the semver line as it would appear
    outside a diff, with {} in the place where you expect the version
    to appear.

    Either old or new may be None, if it is not present in the diff.

    We raise a ValueError if we see more than one old or
    new version in the diff; that would be a sign that
    the searchTemplate is too loose of a match.  In the worst
    case it could be that we can't do this hunk-by-hunk, and
    instead would have to examine the full contents of the
    pre and post images.  We'll cross that road if we come to
    it.
    """
    oldSemver, newSemver = None, None
    searchRE = searchTemplate.replace('{}', semver.Semver.regex)

    for line in hunk.splitlines():
        if not line:
            continue

        match = re.search(searchRE, line[1:])
        if not match:
            continue

        foundSemver = semver.Semver(*match.groups())

        if line.startswith('-'):
            if oldSemver is None:
                oldSemver = foundSemver
            else:
                raise ValueError('Multiple versions removed ({} and {})'.format(oldSemver, foundSemver))
        elif line.startswith('+'):
            if newSemver is None:
                newSemver = foundSemver
            else:
                raise ValueError('Multiple versions added ({} and {})'.format(newSemver, foundSemver))

    return oldSemver, newSemver


def getUsernames():
    # Gets the all_users.csv file from the admin reports, page, and turns this into a dictionary.
    #
    # There's an API call '/users', but it lacks 2FA information.
    #
    # The information returned will be a dictionary of, e.g.,
    #
    #   pharlan:
    #      {'2fa_enabled?': 'true',
    #       'created_at': '2015-04-20 23:46:40 UTC',
    #       'dormant?': 'false',
    #       'email': 'PHARLAN@wsgc.com',
    #       'id': '6',
    #       'last_active': '2016-07-11 21:33:06 UTC',
    #       'last_logged_ip': '192.168.35.28',
    #       'login': 'pharlan',
    #       'org_memberships': '8',
    #       'raw_login': 'pharlan',
    #       'repos': '8',
    #       'role': 'admin',
    #       'ssh_keys': '2',
    #       'suspended?': 'false'}

    # This URL requires basic authentication, so it's easier to manage this ourselves rather than use getSession().
    authToken = util.getCredential('github', _GHE_ADMIN_KEY_NAME)

    # GHE generates the report on request, so may return 202 if it needs us to wait and
    # re-ask for the report.

    numRetries = 0
    while True:
        r = requests.get('https://{}/stafftools/reports/all_users.csv'.format(GHE_HOSTNAME),
                         auth=(authToken, 'x-oauth-basic'),
                         verify=False)

        if r.status_code == 202 and numRetries < 10:
            time.sleep(30)
            numRetries += 1
            continue

        break

    if r.status_code != 200:
        sys.exit('Got status code of {} when attempting to get the all_users report'.format(r.status_code))

    # Convert text csv file to output format.
    dictOfUsers = {}  # {username: userInfoDict, ...}

    for row in csv.DictReader(io.StringIO(r.text)):
        dictOfUsers[row['login']] = row

    return dictOfUsers


class GitRepo(wsgc.repo.Repo):
    def __init__(self, repoUrl=None, branchName=None, workDir=None):
        if branchName and branchName.startswith("origin/"):
            # This is a Jenkins build that fed us a branch name that doesn't look like what we
            # expect.  Turn it into a proper looking branch name.
            shortBranchName = branchName[len("origin/"):]
            branchName = "refs/heads/" + shortBranchName

        self.isDetachedHead = False  # Until we discover otherwise

        # Initialize our fields, and set workDir if it wasn't already set.
        super().__init__(repoUrl=repoUrl, branchName=branchName, workDir=workDir)

        if self.repoUrl is None or self.branchName is None:
            with util.chdirTmp(self.workDir):
                # If we were passed None for repoUrl or branchName, see if we can figure them out based
                # on our working directory.
                if self.repoUrl is None:
                    self.repoUrl = util.run('git remote get-url origin', stripFinalNewline=True)

                # If they provided branchName and we're in a working directory we _could_ verify
                # that the branch name corresponds to the working directory.  We're not doing that
                # here because we don't expect that case to arise.
                if self.branchName is None:
                    try:
                        self.branchName = util.run('git symbolic-ref HEAD', stripFinalNewline=True)
                    except subprocess.CalledProcessError as e:
                        if 'ref HEAD is not a symbolic ref' in e.output:
                            # Detached head.  Not much to do here except use the sha1 :-/
                            self.branchName = util.run('git rev-parse HEAD', stripFinalNewline=True)
                            self.isDetachedHead = True
                        else:
                            raise e

        # Remember a 'short' branch name, if possible, by stripping refs/heads from the start of the
        # full branch name.
        prefix = 'refs/heads/'
        if self.branchName.startswith(prefix):
            self.shortBranchName = self.branchName[len(prefix):]
        else:
            self.shortBranchName = self.branchName

        # Remember our org and repo name.
        self.orgName, self.repoName = parseFullGHEUrl(self.repoUrl)

    def getCIBuildVersion(self):
        if self.isDetachedHead:
            raise GheUrlError("Detached head: you must specify a branch explicitly to get a CI build version")

        return "ci_{}_{}-SNAPSHOT".format(self.orgName, self.shortBranchName)

    def getPomVersion(self):
        content = getFileContents(self.orgName, repoName=self.repoName, path='pom.xml')
        results = util.getContentByXPath(content, './version')
        return results[0]

    def __repr__(self):
        return '{}(workDir={!r}, repoUrl={!r}, branchName={!r})'.format(type(self).__name__, self.workDir,
                                                                        self.repoUrl, self.branchName)


class GheUrlError(wsgc.repo.UrlError):
    """Exception representing a problem parsing a GHE Url"""
    pass


def parseFullGHEUrl(url):
    """Return orgName, repoName for a GitHub Enterprise repository URL"""
    reStr = r'^(?:https://|git@)' + re.escape(GHE_HOSTNAME) + r'(?:/|:)(.+?)/(.+?)(?:\.git)?$'
    matchResult = re.match(reStr, url)
    if matchResult:
        return matchResult.groups()

    raise GheUrlError("Unparsable URL '{}'".format(url))


def getGHERepoDict(orgName, repoName):
    try:
        return _getGHESingleResource(ghePath='/repos/{}/{}'.format(orgName, repoName),
                                     sessionKeyName=_GHE_ADMIN_KEY_NAME)
    except requests.exceptions.HTTPError:
        # Org or repo not present.
        return {}


def isGitWorkDir(workDir='.'):
    """
    True if workDir is the top level directory of a Git repo.  Allows .git to be a file (for
    submodules, etc.) but ignores the environment variable 'GIT_DIR'.
    """
    return os.path.exists(os.path.join(workDir, ".git"))


def isGHEUrl(repoUrl):
    try:
        parseFullGHEUrl(repoUrl)
    except GheUrlError:
        return False

    return True


def makeGHEUrl(*, orgName, repoName):
    return 'git@{}:{}/{}.git'.format(GHE_HOSTNAME, orgName, repoName)


def makeGHETokenUrl(orgName: str, repoName: str):
    authToken = util.getCredential('github', _GHE_ADMIN_KEY_NAME)
    return 'https://{}:x-oauth-basic@{}/{}/{}.git'.format(authToken, GHE_HOSTNAME, orgName, repoName)


def getGHEApiPage(url: str):
    """Return a GitHub Enterprise api content"""
    url = re.sub(GHE_API_BASE_URL, '', url)
    return _getGHESingleResource(ghePath=url,
                                 sessionKeyName=_GHE_ADMIN_KEY_NAME)
