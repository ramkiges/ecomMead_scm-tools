#!/usr/bin/env python3
"""
pomutils_test.py

Unit tests for pomutils.py

Run from top-level scm-tools dir as 'wsgc/pomutils_test.py', or have the
top-level scm-tools dir in your PYTHONPATH.
"""

import unittest

from wsgc import pomutils


class TestPomutils(unittest.TestCase):
    def setUp(self):
        # Test data.
        SVN_ECOM = 'https://repos.wsgc.com/svn/core/ecommerce'

        self.olderReleaseUrl = f'{SVN_ECOM}/platform/baselogic/branches/release-1.2.3'
        self.olderReleaseVersion = '1.2.3-SNAPSHOT'

        self.newerReleaseUrl = f'{SVN_ECOM}/platform/baselogic/branches/release-1.2.4'
        self.newerReleaseVersion = '1.2.4-SNAPSHOT'

        self.trunkUrl = f'{SVN_ECOM}/platform/baselogic/trunk'
        self.trunkVersion = '1.2-SNAPSHOT'

        self.work1Url = f'{SVN_ECOM}/platform/baselogic/branches/example-wrk-180406'
        self.work1Version = 'example-wrk-180406-SNAPSHOT'

        self.work2Url = f'{SVN_ECOM}/platform/baselogic/branches/sample-wrk-180406'
        self.work2Version = 'sample-wrk-180406-SNAPSHOT'

        # Wrapper to reduce verbosity of calling function under test.
        def fn(srcUrl, destUrl, oldVersion, newVersion):
            emptyArray = []
            return pomutils.getMergedPomProjectVersion(propertyName='project.version',
                                                       oldVersion=oldVersion,
                                                       newVersion=newVersion,
                                                       srcUrl=srcUrl,
                                                       destUrl=destUrl,
                                                       interestingVersionChoices=emptyArray)
        self.fn = fn

    def test_older_release_to_newer_release(self):
        """
        Release-branch to newer release-branch
        """
        mergedVersion = self.fn(srcUrl=self.olderReleaseUrl,
                                destUrl=self.newerReleaseUrl,
                                oldVersion=self.newerReleaseVersion,
                                newVersion=self.olderReleaseVersion)
        self.assertEqual(mergedVersion, self.newerReleaseVersion)

    def test_newer_release_to_older_release(self):
        """
        Release-branch to older release-branch (should fail, because we don't merge new releases
        to old)
        """
        with self.assertRaises(pomutils.MergedVersionError):
            self.fn(srcUrl=self.newerReleaseUrl,
                    destUrl=self.olderReleaseUrl,
                    oldVersion=self.olderReleaseVersion,
                    newVersion=self.newerReleaseVersion)

    def test_release_to_trunk(self):
        """
        Release-branch to trunk
        """
        mergedVersion = self.fn(srcUrl=self.newerReleaseUrl,
                                destUrl=self.trunkUrl,
                                oldVersion=self.trunkVersion,
                                newVersion=self.newerReleaseVersion)
        self.assertEqual(mergedVersion, self.trunkVersion)

    def test_trunk_to_work(self):
        """
        Trunk to work branch
        """
        mergedVersion = self.fn(srcUrl=self.trunkUrl,
                                destUrl=self.work1Url,
                                oldVersion=self.work1Version,
                                newVersion=self.trunkVersion)
        self.assertEqual(mergedVersion, self.work1Version)

    def test_work_to_work(self):
        """
        Work branch to work branch
        """
        mergedVersion = self.fn(srcUrl=self.work1Url,
                                destUrl=self.work2Url,
                                oldVersion=self.work2Version,
                                newVersion=self.work1Version)
        self.assertEqual(mergedVersion, self.work2Version)

    def test_work_to_trunk(self):
        """
        Work branch to trunk
        """
        mergedVersion = self.fn(srcUrl=self.work1Url,
                                destUrl=self.trunkUrl,
                                oldVersion=self.trunkVersion,
                                newVersion=self.work1Version)
        self.assertEqual(mergedVersion, self.trunkVersion)

    def test_trunk_to_release(self):
        """
        Trunk to release branch (should fail)
        """
        with self.assertRaises(pomutils.MergedVersionError):
            self.fn(srcUrl=self.trunkUrl,
                    destUrl=self.newerReleaseUrl,
                    oldVersion=self.newerReleaseVersion,
                    newVersion=self.trunkVersion)

    def test_work_to_release(self):
        """
        Work branch to release branch (used for production-support branches)
        """
        mergedVersion = self.fn(srcUrl=self.work1Url,
                                destUrl=self.newerReleaseUrl,
                                oldVersion=self.newerReleaseVersion,
                                newVersion=self.work1Version)
        self.assertEqual(mergedVersion, self.newerReleaseVersion)

    def test_release_to_work(self):
        """
        Release branch to work branch (used for production-support branches)
        """
        mergedVersion = self.fn(srcUrl=self.newerReleaseUrl,
                                destUrl=self.work1Url,
                                oldVersion=self.work1Version,
                                newVersion=self.newerReleaseVersion)
        self.assertEqual(mergedVersion, self.work1Version)


if __name__ == '__main__':
    unittest.main()
