"""
mergeConfig.py

Library of routines for managing merge configuration files.
"""

import sys
import re


class Merge:
    def __init__(self, srcShortcut, destShortcut, addlMergeShortcutsArgs):
        self.srcShortcut = srcShortcut
        self.destShortcut = destShortcut
        self.addlMergeShortcutsArgs = addlMergeShortcutsArgs

    def isSameMerge(self, otherMerge):
        # Ignore addlMergeShortcutsArgs; this is only used to see if two Merges specify the same
        # shortcuts.
        return (self.srcShortcut == otherMerge.srcShortcut and
                self.destShortcut == otherMerge.destShortcut)

    def __str__(self):
        return '{}->{}'.format(self.srcShortcut, self.destShortcut)


class MergeWithDependents(Merge):
    """A Merge object, and a list of MergeWithDependents objects that depend on it"""
    def __init__(self, srcShortcut, destShortcut, addlMergeShortcutsArgs):
        super().__init__(srcShortcut, destShortcut, addlMergeShortcutsArgs)
        self.dependents = []

    def addDependents(self, newDependents):
        self.dependents += newDependents


def parseConfigFile(fname):
    # Return (reportLabel, mergesWithDepenants) corresponding to the input file.  If there's no
    # report label, provide a default one.
    try:
        with open(fname, 'r') as f:
            data = f.read()
    except (FileNotFoundError, PermissionError, IsADirectoryError) as e:
        sys.exit(e)

    # Indentation levels determine dependency: two entries at the same level are independent, while
    # an entry indented more than its predecessor is dependent on it.

    # For parsing, to keep track of how many levels of indentation we've gone back to, we need to
    # remember the indentation levels of our parents.  We can use a stack for this, MergeStrata,
    # that collects the indentation and merges-with-dependents we've seen at each level,
    # collapsing back when we've gone back a level.  The parsed output will be the
    # mergesWithDependents array when we've popped all the way back down.
    #
    # Sample input:
    #
    # coney-shortcut -> drakes-shortcut
    #     drakes-shortcut -> trunk-shortcut
    #         trunk-shortcut -> fuji-search-wrk-150318-shortcut
    #         trunk-shortcut -> mg-reskin-shortcut
    #             mg-reskin-shortcut -> mg-reskin-sub-branch-shortcut
    class MergeStratum:
        """Class representing an indentation level and its merges-with-dependents"""
        def __init__(self, indentLevel):
            self.indentLevel = indentLevel
            self.mergesWithDependents = []

        def addMergeWithDependents(self, mergeWithDependents):
            self.mergesWithDependents.append(mergeWithDependents)

    class MergeStrata:
        """Class representing a stack of MergeStratum objects"""
        def __init__(self, indentLevel):
            self.strata = []
            self.addStratum(indentLevel)

        def top(self):
            return self.strata[-1]

        def collapseOneLevel(self):
            try:
                # Pop the top MergeStratum.
                oldTopStratum = self.strata.pop()
            except IndexError:
                sys.exit('De-indent found in input file?')

            # Get the most recent of the mergeWithDependents in the newly-exposed top layer.
            newTopFinalMergeWithDependents = self.top().mergesWithDependents[-1]

            # Add the merges-with-dependents of the old top stratum as dependents of that most
            # recent merge-with-dependents of the new top layer.
            newTopFinalMergeWithDependents.addDependents(oldTopStratum.mergesWithDependents)

        def addStratum(self, indentLevel):
            self.strata.append(MergeStratum(indentLevel))

        def getAllMergesWithDependents(self):
            """Return all strata as an array of mergesWithDependents"""
            while len(self.strata) > 1:
                self.collapseOneLevel()

            return self.top().mergesWithDependents

    strata = None
    reportLabel = 'performMergeSeries'  # Provisional

    for line in data.splitlines():
        if re.match(r'\s*(#|$)', line):
            continue  # Ignore blank lines and comments

        match = re.match(r'\s*[Ll]abel\s*=\s*(.*?)\s*$', line)
        if match:
            reportLabel = match.group(1)
            continue

        match = re.match(r'(\s*)(\S+)\s*->\s*(\S+)\s*(.*?)\s*$', line)
        if not match:
            sys.exit("Malformed line '{}'".format(line))

        leadingSpaces, srcShortcut, destShortcut, extra = match.groups()

        # Add to this as appropriate; each is a string that will be whitespace-split
        # and passed to the invocation of mergeShortcuts.
        addlMergeShortcutsArgsList = []

        # Does 'extra' contain a "[mergeArgs: ..]" section?  If so, store it
        # and remove it.
        match = re.match(r'(.*?)\s*\[mergeArgs:\s*(.*?)\s*]\s*$', extra)
        if match:
            extra = match.group(1)  # Remove mergeArgs spec from end of string.
            addlMergeShortcutsArgsList.append(match.group(2))

        # Does 'extra' contain a list of email addresses?
        if isWsgcEmailAddrList(extra):
            # Recognize this shorthand for specifying conflict email addrs, and remove
            # them from extra.
            addlMergeShortcutsArgsList.append('--conflictReportEmailAddrs={}'.format(extra))
            extra = ''

        if extra:
            sys.exit("Malformed line '{}'".format(line))

        indentLevel = len(leadingSpaces)

        if not strata:
            strata = MergeStrata(indentLevel)

        # This is the merge we're seeing.  Determine which stratum it belongs to (current, deeper or
        # shallower).
        addlMergeShortcutsArgs = ' '.join(addlMergeShortcutsArgsList)
        thisMergeWithDependents = MergeWithDependents(srcShortcut, destShortcut, addlMergeShortcutsArgs)

        while indentLevel < strata.top().indentLevel:
            try:
                strata.collapseOneLevel()
            except IndexError:
                sys.exit('Error: back-indentation encountered in input file')

        if indentLevel > strata.top().indentLevel:
            # Indent is greater; create an inner level.
            strata.addStratum(indentLevel)

        # Add this merge to what is now the current stratum.
        strata.top().addMergeWithDependents(thisMergeWithDependents)

    return reportLabel, strata.getAllMergesWithDependents()


def isWsgcEmailAddrList(addrsList):
    """
    True if addrsList is a comma-separated list of valid WSI email addresses.
    No spaces are allowed.
    """
    if not addrsList:
        return False

    for addr in addrsList.split(','):
        if not re.match(r'[-0-9a-z._]+@wsgc\.com$', addr, re.IGNORECASE):
            return False

    return True


def printMergesWithDependents(mergesWithDependents, indentLevel=0):
    for mergeWithDependents in mergesWithDependents:
        mergeText = '{} -> {}'.format(mergeWithDependents.srcShortcut,
                                      mergeWithDependents.destShortcut)
        if mergeWithDependents.addlMergeShortcutsArgs:
            mergeText += ' [mergeArgs: {}]'.format(mergeWithDependents.addlMergeShortcutsArgs)

        print((' ' * indentLevel) + mergeText)
        printMergesWithDependents(mergeWithDependents.dependents, indentLevel + 4)
