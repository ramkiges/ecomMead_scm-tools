# util.py
"""
Library of miscellaneous utility functions.
"""

import sys
import os
import re
import contextlib
import shutil
import smtplib
from email import encoders
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
import logging
import subprocess
import locale
import codecs
import configparser
import json
import tempfile
import xml.etree.ElementTree
import requests
import yaml

# Define the ordering of platform layers based on both dependency (later is dependent on earlier)
# and on the order in which we choose to show them to users.
PLATFORM_LAYERS = (
    'components',
    'baselogic',
)

# Create a dictionary of the above array, providing a quick way to
# identify a layer by name and its place in the ordering.
PLATFORM_LAYER_RANKS = {item: i for i, item in enumerate(PLATFORM_LAYERS)}


def isPlatformLayerName(projectName):
    return projectName in PLATFORM_LAYER_RANKS


@contextlib.contextmanager
def chdirTmp(theDir):
    """
    Change to a directory temporarily, returning to original directory
    when done.

    Usage:
       with chdirTmp(someDir):
           ...
    """
    # Taken from http://orip.org/2012/07/python-change-and-restore-working.html
    originalDir = os.getcwd()

    if theDir == originalDir:
        yield  # Nothing to do
    else:
        try:
            os.chdir(theDir)
            yield
        finally:
            os.chdir(originalDir)


def rmPath(path, ignoreMissing=False):
    """Remove a file or directory"""
    if os.path.isdir(path):
        shutil.rmtree(path, ignore_errors=ignoreMissing)
        return

    try:
        os.remove(path)
    except FileNotFoundError as e:
        if not ignoreMissing:
            raise e


def copyPath(*, src, destDir):
    """Copy file or dir src into directory destDir"""
    copyFn = shutil.copytree if os.path.isdir(src) else shutil.copyfile
    copyFn(src, os.path.join(destDir, os.path.basename(src)))


def sendEmail(recipients, sender, subject, body, cc=None, bcc=None, attachments=None):
    # recipients should be a list of strings; if the user passed one
    # string, make it a list and allow it to have been
    # comma-separated.
    if isinstance(recipients, str):
        recipients = [s.strip() for s in recipients.split(',')]

    if isinstance(cc, str):
        cc = [s.strip() for s in cc.split(',')]

    if isinstance(bcc, str):
        bcc = [s.strip() for s in bcc.split(',')]

    if attachments:
        msg = MIMEMultipart()
        msg.attach(MIMEText(body))
    else:
        msg = MIMEText(body)

    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ','.join(recipients)

    if cc:
        msg['Cc'] = ','.join(cc)
    else:
        cc = []

    if bcc:
        msg['Bcc'] = ','.join(bcc)
    else:
        bcc = []

    if attachments:
        for attachment in attachments:
            msg.attach(attachment)

    # Attempt first to send mail to localhost, so it can worry about
    # connecting to off-machine MTAs.  If that doesn't work (such as
    # on laptops where local insecure delivery is disallowed), send
    # mail to the WSI mail relay.
    mailSent = False
    mailServers = ('localhost', 'mailhost.wsgc.com')
    for mailServer in mailServers:
        try:
            with smtplib.SMTP(mailServer) as server:
                server.sendmail(sender, recipients + cc + bcc, str(msg))
                mailSent = True
                break
        except ConnectionRefusedError:
            continue

    if not mailSent:
        sys.exit('Connection refused at the following mail servers: {}'.format(mailServers))


def createAttachment(contents, filename):
    '''
    Create an attachment object from 'contents' that associates it with 'filename'.
    The result is suitable to be a member of the 'attachments' argument to sendEmail().
    '''
    attachment = MIMEBase('application', 'octet-stream')
    attachment.set_payload(contents)
    encoders.encode_base64(attachment)
    attachment.add_header('Content-Disposition', 'attachment; filename={}'.format(filename))

    return attachment


def initLogging(verbose=0):
    # Custom format (time and message).  If you want the user to see a
    # severity level, include it in your message; it's too unfriendly
    # to precede simple messages with, e.g., "INFO".
    ourFormat = '%(asctime)s  %(message)s'

    if verbose == 0:
        initLogLevel = logging.WARNING
    elif verbose == 1:
        initLogLevel = logging.INFO
    else:
        initLogLevel = logging.DEBUG

    logging.basicConfig(level=initLogLevel, stream=sys.stdout,
                        format=ourFormat, datefmt='%Y-%m-%d %H:%M:%S')


def promptYesNo(questionStr):
    with open('/dev/tty') as ttyinput:
        while True:
            sys.stderr.write(questionStr + ' [y/n]? ')
            sys.stderr.flush()

            try:
                answer = ttyinput.readline()
            except KeyboardInterrupt:
                # ^C or similar.  Write the newline so we don't leave the
                # cursor at the end of the question.
                print('')
                return False

            if answer.startswith('y'):
                return True

            if answer.startswith('n'):
                return False

            sys.stderr.write('Please answer y or n\n')
            sys.stderr.flush()


def isRegexpInList(regexp, lst):
    for item in lst:
        if re.match(regexp, item):
            return True

    return False


def indentText(text, numSpaces, keepEOL=False):
    # Indent each line of text by numSpaces spaces.
    # If text ended in a newline, leave that off unless keepEOL.
    if numSpaces == 0:
        # The format specifier doesn't work in this (unlikely) case, so bypass the normal logic.
        result = text
    else:
        result = '\n'.join([(' ' * numSpaces) + l for l in text.splitlines()])

    if len(result) > 0:
        if keepEOL:
            if result[-1] != '\n':
                result += '\n'
        else:
            if result[-1] == '\n':
                result = result[:-1]

    return result


class RunError(subprocess.CalledProcessError):
    """
    Exception thrown by run() when the process exits with a nonzero value.  This mirrors
    CalledProcessError so the caller doesn't have to import subprocess to call util.run().  We
    subclass CalledProcessError for the callers that were written before we created RunError.
    """

    def __init__(self, e):
        """
        Casting constructor that takes a calledProcessError exception and ingests its values.
        """
        self.returncode = e.returncode
        self.cmd = e.cmd
        self.output = e.output
        self.stdout = e.stdout
        self.stderr = e.stderr


def run(cmd, ignoreDecodingErrors=False, universal_newlines=True,
        stripFinalNewline=False, extendEnv=None, verbose=False, timeoutSeconds=None, **otherArgs):
    """
    Run cmd via subprocess, with output (returned) as text unless universal_newlines is False.
    Throw RunError if command fails.

    If universal_newlines and ignoreDecodingErrors are true, don't throw a decoding error when the
    input isn't well-formed; instead decode it forgivingly, replacing unknown characters with a
    replacement character appropriate for the encoding (e.g., '?').

    If extendEnv is not None, the child's environment will include its additional mappings (in
    addition to that of the current env).  If you want to replace the child's environment entirely,
    use the 'env' parameter (see Popen's documentation).
    """

    # Allow the user to pass a whitespace-separated string instead of a list, for cases where you
    # know the input doesn't have quoting issues (e.g., run('ls /')).
    if isinstance(cmd, str):
        cmd = cmd.strip().split()

    if verbose:
        print(cmd)

    # If the user hasn't specified what to do with stderr, redirect it to stdout.
    if 'stderr' not in otherArgs:
        otherArgs['stderr'] = subprocess.STDOUT

    if extendEnv:
        childEnv = os.environ.copy()
        childEnv.update(extendEnv)
        otherArgs['env'] = childEnv

    if timeoutSeconds is not None:
        otherArgs['timeout'] = timeoutSeconds

    try:
        if universal_newlines and ignoreDecodingErrors:
            # Run the command with no decoding, and then decode it forgivingly and return the output.
            rawOutput = subprocess.check_output(cmd, **otherArgs)
            cmdOutput = bytesToTextForgivingly(rawOutput)
        else:
            cmdOutput = subprocess.check_output(cmd, universal_newlines=universal_newlines, **otherArgs)
    except subprocess.CalledProcessError as e:
        raise RunError(e)

    if stripFinalNewline and len(cmdOutput) > 0 and cmdOutput[-1] == '\n':
        cmdOutput = cmdOutput[:-1]

    if verbose:
        print(cmdOutput, end='')

    return cmdOutput


def bytesToTextForgivingly(rawBytes):
    # Convert a raw byte stream (e.g., the output of a command) to the current locale (e.g., UTF-8),
    # replacing any unrecognized characters with the "?" replacement character instead of failing
    # (as would happen with a simple decode() call.
    codec = locale.getpreferredencoding(False)  # The codec used by subprocess.check_output()
    return codecs.decode(rawBytes, codec, 'replace')


def getCurrentCommitId():
    """
    Return our commit ID, if we can.  For Git working directories, is just our current sha1; for
    deployments, we derive it from a deployed file named ".commit_id" in the root of our checkout dir.
    """
    scmToolsDir = getScmToolsDir()
    commitIdPathname = os.path.join(scmToolsDir, '.commit_id')
    try:
        with open(commitIdPathname) as f:
            return f.read().strip()
    except FileNotFoundError:
        return run('git rev-parse --short HEAD', cwd=scmToolsDir, stripFinalNewline=True)


def getScmToolsDir():
    """Return the top-level directory of this repository."""
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')


# getCurrentUser(): return the username of the currently-logged-in user.
#
# Implementation is from <http://stackoverflow.com/questions/842059>
#
# Note: if the 'pwd' library isn't available (e.g., under Windows), the 'getpass' library will be
# used, which gets its information from environment variables and thus is prone to user
# manipulation.
try:
    import pwd

    getpass = None
except ImportError:
    import getpass

    pwd = None


def getCurrentUser():
    if pwd:
        return pwd.getpwuid(os.geteuid()).pw_name
    else:
        return getpass.getuser()


class DictionaryOfLists(dict):
    """
    An extension of dict that adds an append() method, which assumes the value is a list and doesn't
    require the key to exist yet.
    """

    def append(self, key, value):
        if key in self:
            self[key].append(value)
        else:
            self[key] = [value]


class DictionaryOfSets(dict):
    """
    An extension of dict that adds an add() method, which assumes the value is a set and doesn't
    require the key to exist yet.
    """

    def add(self, key, value):
        if key in self:
            self[key].add(value)
        else:
            self[key] = {value}


def getCredential(section, keyword):
    # Can we read the credential from the environment?
    envVarName = "SCM_TOOLS_CREDENTIAL_{}_{}".format(section, keyword)
    if envVarName in os.environ:
        return os.environ[envVarName]

    configPathname = '~/.credentials'

    # Read credential file only once, caching it as a function attribute.
    try:
        config = getCredential.config
    except AttributeError:
        config = configparser.RawConfigParser()

        config.read(os.path.expanduser(configPathname))
        getCredential.config = config

    try:
        return config.get(section, keyword)
    except (configparser.NoSectionError, configparser.NoOptionError):
        sys.exit("Unable to find '{}' in section [{}] of {}".format(keyword,
                                                                    section,
                                                                    configPathname))


def parseYaml(yamlText):
    # Interpret the yaml source as a "---"-separated list of configurations.
    #
    # yaml parses the file lazily, so instantiate it with list() so we get exceptions immediately.
    #
    # Convert tabs to (single) spaces.  Tabs are forbidden in yaml files because of the significance
    # of indentation in some yaml constructs and the ambiguity that ensues when mixing tabs and
    # spaces, but for the subset we use, tabs can be treated as whitespace.  Handling them this way
    # is nicer to the user than failing to load their file.
    #
    # Throws: yaml.YAMLError, yaml.scanner.ScannerError.
    return list(yaml.safe_load_all(yamlText.replace('\t', ' ')))


def relPathSortKeyFn(relPath):
    # Return a pair, the first of which is a number: 0=platform layer, 1=sites/common, 2=other site,
    # 3=other, and the second of which is a platform layer rank or the relPath.
    result = re.match(r'platform/([^/]+)$', relPath)
    if result:
        return (0, PLATFORM_LAYER_RANKS[result.group(1)])

    if relPath.startswith('sites/common'):
        return (1, relPath)

    if relPath.startswith('sites/'):
        return (2, relPath)

    return (3, relPath)


def callJenkinsURL(**kwargs):
    """
    Wrapper for callURL() that adds Jenkins credentials and passes form as non-JSON per Jenkins's
    requirements.

    Like callURL(), throws exception on error.
    """
    kwargs["authUser"] = getCredential('jenkins', 'user')
    kwargs["authPassword"] = getCredential('jenkins', 'password')
    kwargs["postIsJSON"] = False

    if 'action' not in kwargs:
        kwargs['action'] = 'post'

    # Disable warnings, or we'll get a warning about the invalid cert every time we do an operation.
    requests.packages.urllib3.disable_warnings()

    return callURL(**kwargs)


def callURL(url, session=None, action='get', params=None, formDict=None,
            authUser=None, authPassword=None, postIsJSON=True, postIsYaml=False,
            headers=None, stream=False, shouldVerifySSL=False):
    """
    Calls url, throwing an exception on error, returning a requests "Response" object.

    `params` is a dictionary that will be used to pass query parameters.
    """
    req = session if session else requests

    if action == 'get':
        requestFn = req.get

    if action == 'patch':
        requestFn = req.patch

    elif action == 'post':
        requestFn = req.post

        if formDict is None:
            # Sometimes an API requires POST even if there are no fields.
            formDict = {}

    elif action == 'put':
        requestFn = req.put

    elif action == 'delete':
        requestFn = req.delete

    if headers is None:
        headers = {}

    if postIsJSON:
        headers['Content-Type'] = 'application/json'
    elif postIsYaml:
        headers['Content-Type'] = 'application/yaml'

    requestFnArgs = {
        'url': url,
        'verify': shouldVerifySSL,
    }

    if params:
        requestFnArgs['params'] = params

    if authUser:
        requestFnArgs['auth'] = requests.auth.HTTPBasicAuth(authUser, authPassword)

    if formDict is not None:
        if postIsJSON:
            requestFnArgs['data'] = json.dumps(formDict)
            headers['mimetype'] = 'application/json'
        else:
            requestFnArgs['data'] = formDict

    if headers:
        requestFnArgs['headers'] = headers

    if stream:
        requestFnArgs['stream'] = stream

    response = requestFn(**requestFnArgs)

    # Throw an exception if an error occurred.
    response.raise_for_status()

    return response


def disableInsecureSSLWarning():
    """
    Disable this warning:

        InsecureRequestWarning: Unverified HTTPS request is being made

    This will be issued if your environment doesn't trust the WSI root CA
    that is used to sign internal certs.  Note that it will also be issued
    if you are accessing an attacker's site masquerading as someone else,
    so disable this warning with caution.  It's better to configure your
    system to trust the appropriate roots than it is to defeat this security
    measure.
    """
    import warnings
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')


class Xml:
    def __init__(self, xmlText):
        self.xmlText = xmlText

        # Simplify the '<project xmlns="...">' tag
        # to remove the namespace specifications, so we don't have to add the namespaces in
        # front of every element we are looking up (or, optionally, parse the namespaces
        # from an element to figure out what they are, only to add them back).
        xmlTextNoNamespaces = re.sub(r'<project .*?>', '<project>', xmlText, count=1, flags=re.DOTALL)
        self.root = xml.etree.ElementTree.fromstring(xmlTextNoNamespaces)

    def xpath(self, path):
        return self.root.findall(path)

    def xpathText(self, path):
        return [x.text for x in self.xpath(path)]

    def xpathTextOneValue(self, path):
        results = self.xpath(path)

        if results and len(results) == 1:
            return results[0].text

        # If there is more than one, the caller may want know that.  If we need this, raise an
        # exception here so the caller can decide what to do.
        return None


def getContentByXPath(xmlContent, xpath):
    """Given an xml content returns all matches of given xpath"""
    return Xml(xmlContent).xpathText(xpath)


def getJDKVersionFromPom(pomContents):
    """
    From the effective pom based on pomContents, extract and return the JDK version specified in the
    maven-compiler-plugin 'source' tag.

    If we fail at any point (mvn failure, no version spec, etc.), return None.
    """
    try:
        # We have the contents of pom.xml; turn that into an effective pom to see if we can find the
        # JDK version.

        # Write the pom to a temporary directory and run Maven against it.
        effectivePomFilename = 'effectivePom.xml'

        with tempfile.TemporaryDirectory() as tmpDir:
            with chdirTmp(tmpDir):
                with open('pom.xml', mode='w') as fp:
                    fp.write(pomContents)

                # Write the effective-pom to effectivePomFilename.
                run('mvn --non-recursive help:effective-pom -Doutput={}'.format(effectivePomFilename))

                jdk_xpath = './build/plugins/plugin[artifactId="maven-compiler-plugin"]/configuration/source'

                with open(effectivePomFilename) as fp:
                    effectivePomStr = fp.read()

                results = getContentByXPath(effectivePomStr, xpath=jdk_xpath)
                if len(results) == 1:
                    # We found one and only one JDK version; return it to the caller.
                    return results[0]

    except Exception:
        # Treat all error conditions as silent failures.
        pass

    return None


class PomParseError(Exception):
    def __init__(self, pomFilename, xmlException):
        super().__init__()
        self.pomFilename = pomFilename
        self.xmlException = xmlException

    def __str__(self):
        return "Error parsing {}: {}".format(self.pomFilename, self.xmlException)


class PomMissingError(Exception):
    def __init__(self, pomFilename):
        super().__init__()
        self.pomFilename = pomFilename

    def __str__(self):
        return "No pom found at {}".format(self.pomFilename)


def getPomXmls(pomDir):
    """
    Generator yielding (pomFilename, pomXml) for every pom.xml in the project that is rooted at
    pomDir.  The pomXml returned is an Xml object.  Uses the <modules> tag to find module
    directories.

    Throws:
       PomParseError if there's an error parsing a pom.
       PomMissingError if pomDir or a module is missing its pom.xml file.
    """
    pomFilename = os.path.join(pomDir, "pom.xml")

    try:
        with open(pomFilename) as f:
            pomContents = f.read()
    except FileNotFoundError as e:
        raise PomMissingError(pomFilename)

    try:
        pomXml = Xml(pomContents)
    except xml.etree.ElementTree.ParseError as e:
        raise PomParseError(pomFilename=pomFilename, xmlException=e)

    yield pomFilename, pomXml

    # Look into modules' dirs.
    for moduleName in pomXml.xpathText("modules/module"):
        subdir = os.path.join(pomDir, moduleName)

        for subPomFilename, subPomXml in getPomXmls(subdir):
            yield subPomFilename, subPomXml


def setupCIEnv(java_home='/apps/java', maven_home='/apps/maven/latest/bin'):
    """Setup environment variables needed by SCM Tools
    :param java_home: JAVA_HOME path
    :param maven_home: Apache maven binary folder path
    """

    os.environ['JAVA_HOME'] = java_home
    currentPath = os.environ["PATH"]

    if maven_home not in currentPath:
        os.environ["PATH"] += os.pathsep + maven_home


def pluralize(*, word, n):
    return word if n == 1 else '{}s'.format(word)


def getBuildOrderJson(*, generationTemplateNumBrand, generationTemplateNum, isProd=True):
    """
    generationTemplateNum is of the form:

        219091939.0

    Turn this into a URL like:

        http://buildsystem.wsgc.com/builds/<BRAND>dp_UI/cmx-build-20190919-039/BUILD_ORDER.JSON

    and return the JSON object returned from that URL.
    """
    match = re.match(r'(\d)(\d{2})(\d{4})(\d+)\.0$', generationTemplateNum)
    if not match:
        raise ValueError("Unparseable generationTemplateNum '{}'".format(generationTemplateNum))

    firstDigit = match.group(1)
    yy = match.group(2)
    mmdd = match.group(3)
    nthBuild = match.group(4)

    urlBuildNumber = '{}0{}{}-{:03}'.format(firstDigit, yy, mmdd, int(nthBuild))
    serverUrl = 'http://buildsystem.wsgc.com/builds' if isProd else 'http://bgb-uat1-rk1v.wsgc.com/buildsystem2/builds/'
    buildInfoUrl = '{}/{}dp_UI/cmx-build-{}/BUILD_ORDER.JSON'.format(serverUrl,
                                                                     generationTemplateNumBrand,
                                                                     urlBuildNumber)

    buildOrderJson = callURL(url=buildInfoUrl).json()
    return buildOrderJson


def downloadFile(url, localFilename, **callURLParams):
    """
    Save the contents of the URL to a file.  This uses streaming to avoid having to
    hold all of it in memory at once.
    """

    # Note: Response objects are context managers in Requests 2.18+, but we're
    # on an earlier version on our Python 3.5 boxes (CentOS 6), so we can't
    # use it that way here.
    response = callURL(url, stream=True, **callURLParams)

    with open(localFilename, 'wb') as f:
        shutil.copyfileobj(response.raw, f)

    response.close()
