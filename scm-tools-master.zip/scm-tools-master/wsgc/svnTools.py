# svnTools.py
"""
Library of tools for interacting with Subversion repos.

Most routines expect that our current working directory is at the
top level of the checked-out trunk or branch.
"""

import sys
import os
import subprocess
import re
import logging
import tempfile
import datetime
import functools

import wsgc.ecomldap
import wsgc.util
import wsgc.pomutils
import wsgc.repo

from wsgc.util import run

# Exportable constant giving name of master Subversion host.
MASTER_SVN_SERVER_NAME = 'repos.wsgc.com'
MASTER_SVN_URL = 'https://{}/svn'.format(MASTER_SVN_SERVER_NAME)

# Exit code to be used when a merge succeeds because there was nothing to do.
MERGE_UP_TO_DATE_EXIT_CODE = 2

# Exceptions created in this module will subclass Error.
class Error(Exception):
    """Base class for exceptions in svnTools.py"""
    def __init__(self, workDir=None, msg=None):
        super().__init__()
        self.workDir = workDir
        self.msg = msg


def ensureGoodSubversionVersion():
    # svn:mergeinfo is handled differently in svn 1.8 than it is in previous versions.  In
    # particular, the --reintegrate option is deprecated, and merging back and forth between trunk
    # and branches works.
    #
    # (Previously a merge to trunk broke merging the trunk back to the branch.)
    logging.debug('Checking Subversion version')
    output = run('svn --version')
    firstLine = output.splitlines()[0]
    result = re.match(r'svn, version (\d+)\.(\d+)(?:\..*?)? \(r', firstLine)
    if result:
        major, minor = [int(x) for x in result.groups()]
        if major < 1 or (major == 1 and minor < 8):
            sys.exit('Please use Subversion 1.8 or greater')
    else:
        sys.exit('Unable to determine version of Subversion; please use 1.8 or greater')


# Exceptions raised by ensureCleanRepo.
class RepoDirtyError(Error):
    def __init__(self, repo):
        super().__init__(workDir=repo.workDir)
        self.repo = repo

class RepoUncleanableError(Error):
    def __init__(self, repo):
        super().__init__(workDir=repo.workDir)
        self.repo = repo


def ensureCleanRepo(doClean=False, repo=None, _isRetry=False):
    # "svn revert --depth=infinity ." doesn't descend into externals or remove untracked files, so
    # do those ourselves.
    if repo is None:
        repo = SvnRepo()

    if not _isRetry:
        logging.debug('Ensuring clean repo in %s', repo.workDir)

    svnStatus = getRepoStatus(repo=repo)

    if svnStatus.isAllClean:
        return  # Yay, clean repo

    if not doClean:
        # Dirty and they asked us not to clean it.
        raise RepoDirtyError(repo)

    # Dirty and they asked us to clean it.
    if _isRetry:
        # We failed to clean it.
        raise RepoUncleanableError(repo)

    # Try to clean it.  Start with externals.
    for externalStatus in svnStatus.externalStatuses:
        externalRepo = externalStatus.repo
        with wsgc.util.chdirTmp(externalRepo.workDir):
            ensureCleanRepo(doClean=doClean, repo=externalRepo, _isRetry=_isRetry)

    if not svnStatus.isThisClean:
        # Remove untracked files and directories.
        #
        # Do this before reverting modifications, because revert removes merge conflict files, which
        # show up as untracked, which would confuse us when we try to remove them.
        for path in svnStatus.untrackedPaths:
            wsgc.util.rmPath(path)

        # Undo modifications
        run('svn revert --depth=infinity .', cwd=repo.workDir)

        # Did that work?
        ensureCleanRepo(doClean=doClean, repo=repo, _isRetry=True)


def svnUpdate(workDir, includeExternals=True):
    # Run svn update in workDir
    logging.info('Updating %s', workDir)

    cmd = ['svn', 'update', '--accept', 'postpone']

    if not includeExternals:
        cmd.append('--ignore-externals')

    try:
        run(cmd, cwd=workDir)
    except subprocess.CalledProcessError as e:
        sys.exit('Error updating working directory:\n{}'.format(e.output))


def getSvnInfo(workDir=None, repoUrl=None):
    # Returns a dictionary with the output of 'svn info'.
    cmd = ['svn', 'info']
    addlArgs = {}

    if repoUrl:
        cmd.append(repoUrl)
    elif workDir:
        addlArgs['cwd'] = workDir

    output = run(cmd, **addlArgs)

    infoDict = {}

    for line in output.splitlines():
        result = re.match(r'([^:]+?):\s*(.*)$', line)
        if result:
            field, val = result.groups()
            infoDict[field] = val

    return infoDict


def getRepoUrl(workDir=None, repoUrl=None, getAbsolute=False):
    if repoUrl:
        if getAbsolute:
            return repoUrlToAbsoluteUrl(repoUrl=repoUrl)

        # Caller wants the relative URL.
        if repoUrl.startswith('^'):
            return repoUrl

        return absoluteRepoUrlToRelativeUrl(repoUrl=repoUrl)

    # We don't have a repoUrl to work with, but we have a work directory.  Do our best with that.
    info = getSvnInfo(workDir=workDir, repoUrl=repoUrl)

    tagToMatch = 'URL' if getAbsolute else 'Relative URL'

    return info[tagToMatch]


def repoUrlToBranchName(repoUrl):
    # See getUrlTypeAndBranchName() for meaning of 'branch name' here.
    return getUrlTypeAndBranchName(repoUrl)[1]


def getUrlType(repoUrl):
    # Returns 'branch', 'tag' or 'trunk'.
    return getUrlTypeAndBranchName(repoUrl)[0]


class SvnUrlError(wsgc.repo.UrlError):
    """Exception representing a problem parsing a Subversion Url"""
    pass


def getUrlTypeAndBranchName(repoUrl):
    # Type is 'branch', 'tag' or 'trunk'. Name is a human-readable branch name, tag name (if this is
    # a tag and not a branch) or the string 'trunk' or 'trunk-shortcut' if this is a trunk
    # (including if it's the branch 'trunk-shortcut', which is what the merge scripts will use for
    # the trunk shortcut).
    #
    # It's okay if this is ambiguous (such as a tag name that's the same as a branch name), because
    # it's for messaging when the user has already told us what to work on.
    if re.search(r'/trunk$', repoUrl):
        return 'trunk', 'trunk'

    result = re.match(r'.*/(branches|tags)/([^/]+)/?$', repoUrl)
    if result:
        thing, thingName = result.groups()

        if thing == 'branches':
            if thingName == 'trunk-shortcut':
                return 'trunk', thingName
            else:
                return 'branch', thingName
        else:
            return 'tag', thingName

    raise SvnUrlError("Unable to determine type of URL '{}'".format(repoUrl))


def isRepoUrlAWorkBranch(repoUrl):
    # Returns true iff this points to a non-trunk, non-release branch.  Do not use for shortcuts,
    # but for simple repositories.
    urlType, branchName = getUrlTypeAndBranchName(repoUrl)
    return urlType == 'branch' and not re.match(r'release-(?:[-A-Za-z]+|\d+(?:\.\d+)*)$', branchName)


def getUrlBase(repoUrl):
    # For a URL like '/foo/bar/trunk' or '/foo/bar/branches/baz',
    # return '/foo/bar'.
    result = re.match(r'(.*?)/(?:branches|tags|trunk)(?:/|$)', repoUrl)
    if result:
        return result.group(1)

    sys.exit("Unable to determine base of URL '{}'".format(repoUrl))


def doesUrlExist(repoUrl):
    if re.match(r'\^.*/\.\./', repoUrl):
        # This is a relative URL containing '..', which works fine for
        # externals but not for "svn info".  Turn it into a full URL.
        repoUrl = repoUrlToAbsoluteUrl(repoUrl)

    try:
        run(['svn', 'info', repoUrl])
        return True
    except subprocess.CalledProcessError:
        return False


def repoUrlToAbsoluteUrl(repoUrl, repoRootUrl=None):
    if not repoUrl.startswith('^'):
        return repoUrl # Already an absolute URL

    if not repoRootUrl:
        # Provide a default that will work 100% of the time for current WSI shortcuts, all of whose
        # externals begin with "^/../core/".  This is quick and expedient, but not ideal.  We would
        # ideally be passed an absoluate URL we are relative to, and work against that.
        repoRootUrl = 'https://{}/svn/will-be-ignored'.format(MASTER_SVN_SERVER_NAME)

    absUrl = repoRootUrl + repoUrl[1:] # Drop the leading '^'

    # Resolve '..', which isn't legal in an absolute URL.
    while re.search(r'/\.\./', absUrl):
        origAbsUrl = absUrl
        absUrl = re.sub(r'/([^/]+)/\.\./', '/', absUrl, count=1)
        if absUrl == origAbsUrl:
            logging.warning('Tried removing /../ from %s but failed', absUrl)
            break

    return absUrl


def absoluteRepoUrlToRelativeUrl(repoUrl):
    if repoUrl.startswith(MASTER_SVN_URL):
        # Take advantage of the fact that the URL looks like one we're familiar with.
        strippedUrl = repoUrl[len(MASTER_SVN_URL):]

        # Relative URLs omit the top component of the path and use '^/' instead.
        return re.sub(r'^/[^/]+/?', '^/', strippedUrl)

    # This isn't a URL we recognize; ask the server what the relative URL is.
    return getSvnInfo(repoUrl=repoUrl)['Relative URL']


def getRepoUrlExternals(repoUrl):
    # Returns a dictionary of {<repo-relative path>: <external URL>, ...}
    try:
        output = run(['svn', 'propget', '--depth=infinity', 'svn:externals', repoUrl])
    except subprocess.CalledProcessError:
        sys.exit('Error: {} is not a valid Subversion URL'.format(repoUrl))

    # pylint: disable=line-too-long
    #
    # Example output:
    # https://repos.wsgc.com/svn/shortcuts/evolution/trunk/platform - ^/../core/ecommerce/platform/baselogic/trunk     baselogic
    # ^/../core/ecommerce/platform/tools/trunk         tools
    # ^/../core/ecommerce/platform/components/trunk    components

    # https://repos.wsgc.com/svn/shortcuts/evolution/trunk/sites/admin - ^/../core/ecommerce/sites/admin/content/trunk     content

    fullRepoUrl = getRepoUrl(repoUrl=repoUrl, getAbsolute=True)
    newSectionRegexp = r'^{}/(\S+) - (.+?)\s+(\S+)$'.format(re.escape(fullRepoUrl))

    externals = {}  # <repo-relative path>: <external URL>

    currentRepoRelativePath = None

    for line in output.splitlines():
        if line == '':
            continue

        result = re.match(newSectionRegexp, line)
        if result:
            # Start of a new section.
            currentRepoRelativePath, externalUrl, subPath = result.groups()
        else:
            result = re.match(r'(.+?)\s+(\S+)$', line)
            if result:
                externalUrl, subPath = result.groups()
            else:
                logging.warning('Unexpected output [%s] in externals of %s', line, repoUrl)
                continue

        relPath = os.path.join(currentRepoRelativePath, subPath)
        externals[relPath] = externalUrl

    return externals


def getNewestUnmergedRevision(srcUrl, destUrl):
    # Returns the newest (highest-numbered) revision on srcUrl that isn't already merged to destUrl,
    # or None if there are no unmerged revisions.
    unmergedRevisions = getUnmergedRevisions(srcUrl, destUrl)

    if not unmergedRevisions:
        return None  # Nothing to merge.

    newestUnmergedRevision = max(unmergedRevisions)

    # Because we're going to peg the srcUrl at this revision, make sure it's new enough that the
    # srcUrl exists _at_ this revision.  Otherwise, pick srcUrl's head revision.
    #
    # E.g., say destUrl was created from trunk, then ten commits were made to trunk, and then srcUrl
    # was created from trunk.  The newest unmerged change reachable from srcUrl will have been made
    # before srcUrl existed, so <srcUrl>@<revision> will be an invalid revision spec.  Use srcUrl's
    # head revision in this case.
    try:
        getSvnInfo(repoUrl='{}@{}'.format(srcUrl, newestUnmergedRevision))
    except subprocess.CalledProcessError:
        # SrcUrl didn't exist at that revision; just use its head revision.
        srcUrlInfo = getSvnInfo(repoUrl=srcUrl)
        headRevision = int(srcUrlInfo['Revision'])

        logging.warning('Newest unmerged revision %s not present on %s; using head revision %s instead',
                        newestUnmergedRevision, srcUrl, headRevision)

        return headRevision

    return newestUnmergedRevision


def getUnmergedRevisions(srcUrl, destUrl):
    # Returns the revisions on srcUrl that aren't already merged to destUrl, or [] if there are no
    # unmerged revisions.
    unmergedRevisions = []

    output = run(['svn', 'mergeinfo', '--show-revs=eligible', srcUrl, destUrl])

    for line in output.splitlines():
        result = re.match(r'r(\d+)$', line)
        if result:
            rev = int(result.group(1))
            unmergedRevisions.append(rev)

    return unmergedRevisions


def findLastAgreementRevision(srcUrl, destUrl):
    # Returns the revision number of the last time the two branches were the same.

    # The output of 'svn mergeinfo <src> <dest>' is an ascii diagram that looks either like this:
    #
    #     youngest common ancestor
    #     |         last full merge
    #     |         |        tip of branch
    #     |         |        |         repository path
    #
    #     296572    309979   310900
    #     |         |        |
    #   -------| |------------         ecommerce/sites/common/content/trunk
    #      \         \
    #       \         \
    #        --| |------------         ecommerce/sites/common/content/branches/awesome-forms-141205
    #                        |
    #                        310999
    # or like this:
    #
    #     youngest common ancestor
    #     |         last full merge
    #     |         |        tip of branch
    #     |         |        |         repository path
    #
    #     296572             310999
    #     |                  |
    #        --| |------------         ecommerce/sites/common/content/branches/awesome-forms-141205
    #       /         /
    #      /         /
    #   -------| |------------         ecommerce/sites/common/content/trunk
    #               |        |
    #               309979   310900
    #
    # depending on whether the destination of the last full merge.  So if the first line of numbers
    # has three numbers in it, then the middle number is the revision of the last agreement between
    # the branches, but if the first line of numbers has only two numbers in it and the last line of
    # numbers has two numbers also, then the first number in the last line of numbers is the last
    # point of agreement.
    #
    # (Parsing this is ridiculously clumsy.  If you find a better way to get the merge base between
    # two branches in Subversion please use it!)
    #
    # Note that there is a third possibility for this graph: if the two branches have never merged,
    # then the first line of numbers will contain only two numbers, and the last line of numbers
    # will contain only one.  In that case, the first number in the first line of numbers is the
    # youngest common ancestor, and that's what we'll go with.
    output = run(['svn', 'mergeinfo', srcUrl, destUrl])

    isFirstLineOfNumbers = True
    for line in output.splitlines():
        # Look for two numbers (with a possible trailing third number).
        result = re.match(r'\s*(\d+)\s+(\d+)(?:\s+(\d+))?\s*$', line)
        if result:
            firstNumberStr, secondNumberStr, thirdNumberStr = result.groups()

            if thirdNumberStr:
                # We have three numbers: the middle one is the merge.
                assert isFirstLineOfNumbers
                return int(secondNumberStr)

            # We matched only two numbers.
            if isFirstLineOfNumbers:
                # Remember youngest common ancestor, which we can use if we don't find a merge on
                # the second line of numbers.
                youngestCommonAncestor = int(firstNumberStr)
                isFirstLineOfNumbers = False
            else:
                # We are on the second line of numbers, so the merge is the first of these.
                return int(firstNumberStr)

    logging.debug('No merge found between branches; using youngest common ancestor')
    return youngestCommonAncestor


def findLastMergedToRevision(srcRevision, destUrl):
    print('findLastMergedToRevision({}, {})'.format(srcRevision, destUrl))
    # Returns the revision in destUrl that received, via a merge, srcRevision.

    # In what revision did we merge srcRevision?  Unfortunately there's no direct way to ask
    # Subversion this, but we want to know it so we can later find out who changed certain paths
    # since that merge.  Look backwards through the log on destUrl, using -g so we see merged
    # commits, until we see this revision; it should be annotated with "Merged via: r<n>".  That <n>
    # is what we're looking for.
    #
    # There can be more than one revision listed after 'Merged via:', separated by comma-space.  We
    # are interested in the most recent revision that represents a change on destUrl.
    #
    # Note: this log operation takes a long time because the merge information goes back to the
    # beginning, and there's no way I know of to limit it.  (--limit doesn't limit the merge info.)
    # Instead of waiting for all the output before we start processing, use a pipe and read it one
    # line at a time, killing the process when we have our answer.
    destUrlRevisionsSeen = {}
    logging.debug('Running "svn log -g -q %s"', destUrl)
    proc = subprocess.Popen(['svn', 'log', '-g', '-q', destUrl],
                            bufsize=1, stdout=subprocess.PIPE, universal_newlines=True)

    STATE_FIND_REVISION = 'find revision'
    STATE_FIND_MERGED_VIA = 'find merged via'
    state = STATE_FIND_REVISION

    try: # Use 'finally' to kill child process no matter what
        for line in proc.stdout:
            line = line.rstrip('\n')

            logging.debug("%s: line = '%s'", state, line)
            if state == STATE_FIND_REVISION:
                result = re.match(r'r(\d+) \|', line)
                if result:
                    thisRevision = int(result.group(1))
                    destUrlRevisionsSeen[thisRevision] = None

                    if thisRevision == srcRevision:
                        # We found the revision we're looking for; now see
                        # where it was merged into our path.
                        state = STATE_FIND_MERGED_VIA

            elif state == STATE_FIND_MERGED_VIA:
                result = re.match(r'Merged via: (.+)$', line)
                if result:
                    mergedToRevisions = [revStrToRev(x) for x in result.group(1).split(', ')]

                    for rev in sorted(mergedToRevisions, reverse=True):
                        if rev in destUrlRevisionsSeen:
                            # This is the merge revision we're looking for.
                            return rev

                    # This wasn't the revision we were looking for.  Strange.  Perhaps this revision
                    # entered our branch via a different merge, so keep looking.
                    state = STATE_FIND_REVISION
                else:
                    msg = "Expected 'Merged via:', but found '{line}' after finding '{srcRevision}'." \
                          "Using {srcRevision} as last merged revision in lieu of a better choice". \
                          format(line=line, srcRevision=srcRevision)
                    logging.warning('%s', msg)
                    return srcRevision
            else:
                sys.exit("Unexpected state '{}'".format(state))
    finally:
        # Kill the subprocess we spawned.
        proc.kill()

    # We went all the way to the beginning (or 1000 revisions) without
    # the finding out where srcRevision entered our branch.
    # Fail.
    sys.exit("Failed to find where r{} merged into '{}'".format(srcRevision, destUrl))


def revStrToRev(revStr):
    result = re.match(r'r?(\d+)$', revStr)
    if result:
        return int(result.group(1))

    sys.exit("Error in revStrToRev(): unexpected input '{}'".format(revStr))


def getLastChangedRevision(url):
    svnInfo = getSvnInfo(repoUrl=url)
    try:
        return int(svnInfo['Last Changed Rev'])
    except KeyError:
        sys.exit("Error getting last changed revision for {}".format(url))


def tryMerge(srcUrl, destUrl, revisionNumber):
    # Merges from srcUrl at revisionNumber into the current working directory, which must point at
    # destUrl.  Returns (isConflicted, isFullyMerged).
    #
    # isFullyMerged will be set to False if the user needs to run "svn merge" (possibly again) in
    # order for the merge to be considered done.  (Sometimes when there is a conflict, "svn merge"
    # must be repeated to bring the branch up-to-date, as it effectively applies the changes one at
    # a time.)

    fullUrl = srcUrl + '@' + str(revisionNumber)
    logging.info('Merging from %s', fullUrl)

    isConflicted = False  # So far
    isFullyMerged = True  # So far

    wasNonzeroExitCode = False

    try:
        output = run(['svn', 'merge', '--accept=postpone', fullUrl])
    except subprocess.CalledProcessError as e:
        # Conflicts (which we can deal with) sometimes cause a nonzero error code, but so do other
        # errors that we can't deal with.  And conflicts don't always cause a nonzero error code, it
        # depends on what kind of conflict it was.  So save the output and remember there was a
        # nonzero exit code, and look for conflicts later.
        output = e.output
        wasNonzeroExitCode = True

    if re.search(r'(?:^|\n)(?:svn: E\d+: One or more conflicts were produced|\s*(?:Text|Tree) conflict)|Can\'t merge into conflicted', output):
        isConflicted = True

        if re.search(r'rerun the merge to apply', output):
            isFullyMerged = False

    if wasNonzeroExitCode and not isConflicted:
        # We don't know why there was a nonzero exit code; fail.
        result = re.search(r'(?:^|\n)(svn: E\d+:[^\n]+)', output)
        svnError = result.group(1) if result else '<unknown error>'
        sys.exit('Error merging from {}: {}\n{}'.format(fullUrl, svnError, output))

    if isFullyMerged:
        # Double-check this against the svn:mergeinfo property.
        if not getIsFullyMerged(srcUrl, destUrl, revisionNumber):
            logging.debug('We thought we were fully merged, but getIsFullyMerged(%s, %s, %s) disagreed',
                          srcUrl, destUrl, revisionNumber)

    if not isConflicted and not isFullyMerged:
        # This should not happen; the only reason Subversion may legitimately not complete a merge
        # is if a merge conflict prevented a revision from being merged.
        sys.exit('Failure to fully merge to {} despite lack of conflicts'.format(revisionNumber))

    if not isFullyMerged:
        logging.info('Conflicts prevented the merge from completing')

    return isConflicted, isFullyMerged


def getIsFullyMerged(srcUrl, destUrl, revisionNumber):
    # Validate that the current directory has fully merged from srcUrl up through revisionNumber.
    #
    # We'd like to parse "svn mergeinfo <srcUrl>" but that ignores local changes, so just parse the
    # svn:mergeinfo property for this URL and verify that it looks the way we think it should (see
    # below).
    #
    # Must be called from the root of the merge target working directory.
    try:
        mergeinfo = run('svn propget svn:mergeinfo .')
    except subprocess.CalledProcessError as e:
        sys.exit('Error getting svn:mergeinfo: {}', e.output)

    # The lines in svn:mergeinfo are relative to the repository root.  Trim that from the front of
    # srcUrl if present so we can locate it in the list.
    repoRootUrl = getSvnInfo()['Repository Root']
    absSrcUrl = repoUrlToAbsoluteUrl(srcUrl, repoRootUrl=repoRootUrl)

    if absSrcUrl.startswith(repoRootUrl):
        prefix = absSrcUrl[len(repoRootUrl):]
    else:
        sys.exit('I expected {} to begin with the repo root URL {}'.format(absSrcUrl, repoRootUrl))

    # The revision list we see for a full merge is different depending on the types of the URLs
    # being merged.  If we're merging a branch into the trunk, the list for a full merge will be
    # N-M, where M is the revision we're interested in.  But for trunk->branch, the list may have a
    # lot of segments, the last of which will be N-M where M is revisionNumber and N is the revision
    # of the branch creation.  For branch->branch, there may be many segments and I'm not sure what
    # N is, so just look for M.
    srcType = getUrlType(srcUrl)
    destType = getUrlType(destUrl)

    branchCreationRev = None  # See comment in trunk->branch case below

    if srcType == 'branch' and destType == 'trunk':
        # If the branch has only one revision, there's just one revision, so the leading "N-" isn't there.
        matchRegexp = r':(?:(\d+)-)?(\d+)$'
    elif srcType == 'trunk' and destType == 'branch':
        # To be a full merge, we should see mergeinfo contain N-M, where N is at or prior to the
        # branch creation revision.  (It would normally be the branch-creation revision, but if
        # there were time between the branch copy into a working tree and the commit of that working
        # tree, N could be less than that.  Just look for numbers and validate that they're less
        # than branchCreationRevision.)
        branchCreationRev = getBranchCreationRevision(destUrl)
        if not branchCreationRev:
            sys.exit('Unable to find branch creation revision for {}'.format(destUrl))
        matchRegexp = r':(?:|.+,)(\d+)-(\d+)$'
    else:
        matchRegexp = r':(?:|.+,)(\d+)-(\d+)$'

    prefixLen = len(prefix)
    for line in mergeinfo.splitlines():
        if line.startswith(prefix):
            result = re.match(matchRegexp, line[prefixLen:])

            if result:
                N = result.group(1)
                M = int(result.group(2))

                if branchCreationRev:
                    # We need a complete range, from on or before the branch existed to now.
                    if N != '' and int(N) <= branchCreationRev and M == revisionNumber:
                        return True
                else:
                    # We just need to see that the merge range includes our expected revision.
                    if M == revisionNumber:
                        return True

            return False

    return False


def attemptConflictResolution(path, srcUrl, destUrl, revision):
    # Attempt to resolve this conflict automatically. Returns True iff we believe we have.
    #
    # Currently all we try is to see if the file is the same on both branches, and if so resolve it
    # in favor of the current branch.  This comes up in 'local file obstruction' conflicts when the
    # same thing has been added to two branches independently.
    ourPathUrl = '{}/{}@{}'.format(destUrl, path, revision)
    theirPathUrl = '{}/{}@{}'.format(srcUrl, path, revision)

    # Get the contents of both sides.
    contents = {} # ours/theirs -> contents

    for url, whose in (ourPathUrl, 'ours'), (theirPathUrl, 'theirs'):
        try:
            contents[whose] = run(['svn', 'cat', url], universal_newlines=False)  # Binary mode
        except subprocess.CalledProcessError as e:
            outputText = e.output.decode()
            if re.search(r'some targets are directories', outputText):
                # This path is a directory; compare elsehow.
                return attemptDirectoryConflictResolution(path=path,
                                                          srcUrl=srcUrl,
                                                          destUrl=destUrl,
                                                          revision=revision)

            if re.search(r'(?:^|\n)svn: warning:[^\n]+ path not found', outputText):
                # The file doesn't exist on this external.
                contents[whose] = None
                continue

            # Something went wrong and we don't know how to do anything else.
            logging.debug('Unable to autoresolve conflict in %s: unable to retrieve contents', path)
            return False

    if contents['ours'] != contents['theirs']:
        logging.debug('Unable to autoresolve conflict in %s: the contents differ', path)
        return False

    if contents['ours'] is None:
        whyResolving = 'both sides had deleted the file'
    else:
        whyResolving = 'both sides were the same'

    logging.info('Resolving %s because %s', path, whyResolving)

    # If a path that Subversion treats as text has a conflict, Subversion may put conflict markers
    # in the working copy ("<path>") even if the file was the same on both sides of the merge.  The
    # unmodified workiing copy is in "<path>.working".  So before we accept path, if
    # "<path>.working" exists we'll overwrite the contents of path with contents['ours'].
    #
    # (We don't want to rename "<path>.working" to "<path>", because this would break if there were
    # a tracked file that just happened to be called "<path>.working".)
    #
    # (If the path is considered binary, .working won't be created by Subversion and path will be
    # the original version.  So only rewrite "<path>" if "<path>.working" exists.)
    #
    # For an example of this text conflict for identical files (in Subversion 1.7.17 and 1.8.11)
    # check out https://repos.wsgc.com/svn/core/ecommerce/sites/pk/content/branches/release-baker to
    # revision 303950 and merge in ^/ecommerce/sites/pk/content/branches/release-asbury at revision
    # 303951.

    pathWithWorking = path + '.working'
    if os.path.exists(pathWithWorking):
        logging.debug('%s exists; overwriting %s with its original content prior to resolving',
                      pathWithWorking, path)
        with open(path, 'wb') as f:
            f.write(contents['ours'])
    else:
        logging.debug('%s did not exist; accepting %s as-is', pathWithWorking, path)

    run(['svn', 'resolve', '--accept=working', path])

    return True


def attemptDirectoryConflictResolution(path, srcUrl, destUrl, revision):
    # Like (and called by) attemptConflictResolution(), but used when path represents a directory,
    # not a regular file.
    #
    # We could list the directories and compare their files individually, or we could checkout each
    # directory somewhere on disk and compare the on-disk directories.  The advantage of the former
    # is we don't need to write to the filesystem, the advantage of the latter is that if the
    # directories are large it will require fewer trips to the server to get the data.
    #
    # We have some directories that this routine hits that are large enough that we need to do the
    # latter approach.
    ourPathUrl = '{}/{}@{}'.format(destUrl, path, revision)
    theirPathUrl = '{}/{}@{}'.format(srcUrl, path, revision)

    try:
        ourDir = tempfile.mkdtemp(prefix='ours_')
        theirDir = tempfile.mkdtemp(prefix='theirs_')

        logging.debug("Created tmp dirs %s and %s for comparing %s's path %s", ourDir, theirDir, destUrl, path)

        # Export complains if the directory exists unless --force is passed.  We don't want --force
        # to cover up anything unexpected, so create the new repos within our tmp dirs.
        ourSubdir = ourDir + '/t'
        theirSubdir = theirDir + '/t'

        # Populate the temporary directories
        for url, subdir in (ourPathUrl, ourSubdir), (theirPathUrl, theirSubdir):
            try:
                run(['svn', 'export', '--ignore-externals', '--ignore-keywords', url, subdir])
            except subprocess.CalledProcessError:
                logging.debug('Unable to autoresolve conflict in %s: %s does not exist', path, url)
                return False

        # Diff them.
        try:
            run(['diff', '-q', '-r', ourSubdir, theirSubdir])
        except subprocess.CalledProcessError:
            logging.debug("Unable to autoresolve conflict in %s: the directories' contents differ", path)
            return False

    finally:
        wsgc.util.rmPath(ourDir)
        wsgc.util.rmPath(theirDir)

    # Mark the path resolved.
    logging.info('Resolving %s because both dirs were the same', path)
    run(['svn', 'resolve', '--accept=working', '--depth=infinity', path])

    # Work around a bug in Subversion >= 1.8 that creates subtree svn:mergeinfo properties for
    # add-add tree conflicts.
    cleanUpSubtreeMergeInfo(destUrl=destUrl, path=path, revision=revision)

    return True


def cleanUpSubtreeMergeInfo(destUrl, path, revision):
    # Subversion 1.8.11 adds svn:mergeinfo properties to the contents of directories that had tree
    # conflicts.  We only want svn:mergeinfo properties at the root of externals (and there's a
    # commit hook that ensures that), so remove mergeinfo if the properties look like what the bug
    # produces.
    #
    # See http://thread.gmane.org/gmane.comp.version-control.subversion.user/118260

    # The contents of the new mergeinfo property is the same as the mergeinfo of the root of the
    # repo at the base revision (i.e., prior to initiating the merge), with the exception that the
    # URLs in the new mergeinfo will include the path of the subtree node that bears the property.
    def mergeinfosCompareEqual(aMergeinfo, bMergeinfo, path):
        # Compare aMergeinfo line-by-line with bMergeinfo, removing path first from the end of lines
        # of b but prior to the final colon.  Return True if they compare equal.
        aLines = aMergeinfo.splitlines()
        bLines = bMergeinfo.splitlines()

        if len(aLines) != len(bLines):
            logging.warning('*** Ignorning differing number of lines (%s vs %s) in mergeinfo at %s',
                            len(aLines), len(bLines), path)
            return True

        bLineSuffix = '/' + path
        suffixLen = len(bLineSuffix)

        for aLine, bLine in zip(aLines, bLines):
            result = re.match(r'(.*):(.*)$', bLine)
            assert result, 'Mergeinfo lines contain a colon ({})'.format(bLine)

            bPreColon, bPostColon = result.groups()
            if bPreColon.endswith(bLineSuffix):
                newBLine = bPreColon[:-suffixLen] + ':' + bPostColon
                if newBLine != aLine:
                    logging.debug('** Mergeinfo lines differ: %s vs %s (%s) at %s **', aLine, bLine, newBLine, path)
            else:
                logging.warning('Mergeinfo line %s was expected to include %s', bLine, bLineSuffix)
                return False

        return True

    assert path != '.'

    mergeinfoProp = 'svn:mergeinfo'  # Constant, to avoid typos.

    # Who in the worktree starting at path contains svn:mergeinfo?
    pathsThatHaveMergeinfo = propFind(path, mergeinfoProp)

    if not pathsThatHaveMergeinfo:
        logging.debug('No paths in or under %s had svn:mergeinfo properties', path)
        return

    # Use the URL here, because we're interested in the pre-merge value.
    preMergeRootUrl = '{}@{}'.format(destUrl, revision)
    preMergeRootMergeinfo = propGet(preMergeRootUrl, mergeinfoProp)

    for pathThatHasMergeinfo in pathsThatHaveMergeinfo:
        thisMergeinfo = propGet(pathThatHasMergeinfo, mergeinfoProp)
        assert thisMergeinfo

        if mergeinfosCompareEqual(preMergeRootMergeinfo, thisMergeinfo, path=pathThatHasMergeinfo):
            logging.debug('Removing %s from %s', mergeinfoProp, pathThatHasMergeinfo)
            run(['svn', 'propdel', mergeinfoProp, pathThatHasMergeinfo])
        else:
            sys.exit('{} has {}:\n{}\nbut root {} is:\n{}'.format(pathThatHasMergeinfo, mergeinfoProp,
                                                                  thisMergeinfo, mergeinfoProp, preMergeRootMergeinfo))


def propFind(path, propName):
    # Return files at or under path that have the given Subversion property.
    try:
        output = run(['svn', 'proplist', '--depth=infinity', path])
    except subprocess.CalledProcessError as e:
        sys.exit('Error looking for properites at {}: {}'.format(path, e.output))

    retval = []

    # Output looks like:
    #
    # Properties on 'static/images/contests/design-sponge-sweeps/btn-submit.jpg':
    #   svn:mergeinfo
    #   svn:mime-type
    # Properties on 'static/images/contests/design-sponge-sweeps/hero.jpg':
    # ...
    currentPath = None
    for line in output.splitlines():
        result = re.match(r"Properties on '(.*)':$", line)
        if result:
            currentPath = result.group(1)
            continue

        result = re.match(r'^\s+(.*)$', line)
        if result and result.group(1) == propName:
            assert currentPath
            retval.append(currentPath)

    return retval


def propGet(pathOrUrl, propName):
    # Get the property at path. Subversion returns '' if the property doesn't exist, so we do too.
    try:
        return run(['svn', 'propget', propName, pathOrUrl])
    except subprocess.CalledProcessError as e:
        sys.exit('Error looking for property {} at {}: {}'.format(propName, pathOrUrl, e.output))


class SvnRepo(wsgc.repo.Repo):
    def __init__(self, repoUrl=None, branchName=None, workDir=None):
        # Initialize our fields, and set workDir if it wasn't already set.
        super().__init__(repoUrl=repoUrl, branchName=branchName, workDir=workDir)

        self.absUrl = getRepoUrl(workDir=self.workDir, repoUrl=self.repoUrl, getAbsolute=True)

        if self.repoUrl is None:
            # It wasn't passed, but we've figured out a usable URL.
            self.repoUrl = self.absUrl

        urlBranchName = repoUrlToBranchName(self.absUrl)

        if self.branchName is None:
            self.branchName = urlBranchName
        elif self.branchName != urlBranchName:
            raise SvnUrlError("Url '{}' does not match branch name '{}'".format(self.absUrl, self.branchName))

        self.__pomXmlRoot = None  # Cache for pomXmlRoot().

    def getCIBuildVersion(self):
        # Just use the last component of the branch, tag or trunk path, whether it's a branch, tag
        # or trunk.  We don't build on tags in CI, so don't worry about the potential for confusion
        # there, and if you have a branch named 'trunk' you're asking for trouble anyway.
        branchNickname = self.branchName.split('/')[-1]
        return "ci_{}-SNAPSHOT".format(branchNickname)

    @property
    def pomXmlRoot(self):
        if not self.__pomXmlRoot:
            content = run(["svn", "cat", "{}/pom.xml".format(self.absUrl)])
            self.__pomXmlRoot = wsgc.util.Xml(content)

        return self.__pomXmlRoot

    def getPomVersion(self):
        """Read the version written in our pom.xml file."""
        return self.pomXmlRoot.xpathTextOneValue('version')

    def __repr__(self):
        return '{}(workDir={!r}, url={!r})'.format(type(self).__name__, self.workDir, self.absUrl)


class RepoStatus():
    def __init__(self, repo, isThisClean, isAllClean,
                 modifiedPaths, conflictedPaths, untrackedPaths,
                 externalStatuses):
        self.repo = repo
        self.isThisClean = isThisClean
        self.isAllClean = isAllClean
        self.modifiedPaths = modifiedPaths
        self.conflictedPaths = conflictedPaths
        self.untrackedPaths = untrackedPaths

        # Array of RepoStatus() objects for any externals.
        self.externalStatuses = externalStatuses

    def __str__(self):
        s = ""
        s += str(self.repo) + '\n'
        s += 'isAllClean = ' + str(self.isAllClean) + '\n'
        s += 'isThisClean = ' + str(self.isThisClean) + '\n'
        s += 'modifiedPaths = ' + str(self.modifiedPaths) + '\n'
        s += 'conflictedPaths = ' + str(self.conflictedPaths) + '\n'
        s += 'untrackedPaths = ' + str(self.untrackedPaths) + '\n'

        if self.externalStatuses:
            s += 'Externals:\n'

            theExternals = []
            for extStatus in self.externalStatuses:
                # Indent the external
                oneExternal = ''.join(['   ' + line + '\n' for line in str(extStatus).splitlines()])
                theExternals.append(oneExternal)

            s += '\n'.join(theExternals)

        # Remove trailing newline, as string representations don't typically end in them.
        return s[:-1]


def getRepoStatus(repo=None, workDir=None):
    # Pass at most one of repo or workDir; will use current directory
    # if nothing given. Returns a RepoStatus object.
    if repo is None:
        repo = SvnRepo(workDir=workDir)

    modifiedPaths = []
    conflictedPaths = []
    untrackedPaths = []

    # Our status will mention the externals but not descend into
    # them. Once we've gathered them all we can recurse into them.
    externalPaths = []

    output = run('svn status --ignore-externals', cwd=repo.workDir)

    for line in output.splitlines():
        if line == 'Summary of conflicts:':
            break  # Done with normal output

        result = re.match(r'(.)(.)(....)(.) (.+)$', line)
        if result:
            col1, col2, cols3thru6, col7, filePath = result.groups()

            if not re.match(r'[ +]+$', cols3thru6):
                # This is something we don't currently handle.
                sys.exit("Unexpected output from svn status in {}: '{}'\nCorrect and restart.".
                         format(repo.workDir, line))

            if col1 == 'X':
                externalPaths.append(filePath)
            elif 'C' in (col1, col2, col7):
                conflictedPaths.append(filePath)
            elif 'M' in (col1, col2, col7):
                modifiedPaths.append(filePath)
            elif 'A' in (col1, col2, col7):
                modifiedPaths.append(filePath)
            elif 'D' in (col1, col2, col7):
                modifiedPaths.append(filePath)
            elif 'R' in (col1, col2, col7):
                modifiedPaths.append(filePath)
            elif col1 == '?':
                untrackedPaths.append(filePath)
            elif col7 == '>':
                # Continuation line; ignore
                pass
            else:
                logging.warning("Unexpected output from svn status: '%s'", line)
        else:
            # File conflicts produce an extra line, which we can ignore.
            logging.debug("Ignoring unmatched output from svn status: '%s'", line)

    isThisClean = not modifiedPaths and not conflictedPaths and not untrackedPaths
    isAllClean = isThisClean # So far

    externalStatuses = []

    for externalPath in externalPaths:
        externalStatus = getRepoStatus(workDir=externalPath)

        if not externalStatus.isAllClean:
            isAllClean = False

        externalStatuses.append(externalStatus)

    return RepoStatus(repo=repo, isThisClean=isThisClean, isAllClean=isAllClean,
                      modifiedPaths=modifiedPaths, conflictedPaths=conflictedPaths,
                      untrackedPaths=untrackedPaths, externalStatuses=externalStatuses)


def getBranchCreationRevision(branchPath):
    output = run(['svn', 'log', '-q', '--stop-on-copy', '-r0:HEAD', '-l', '1', branchPath])

    result = re.search(r'\nr(\d+) \|', output)
    if result:
        return int(result.group(1))

    sys.exit("Unable to find branch creation revision for '{}'!".format(branchPath))


class PathModification:
    """Class representing a path and its Subversion modification letters (M, D, R, etc.)"""
    def __init__(self, path, modification):
        self.path = path
        self.modification = modification

class Revision:
    def __init__(self,
                 revisionNumber,
                 author,
                 whenCommitted,
                 message,
                 pathModifications):
        self.revisionNumber = revisionNumber
        self.author = author
        self.whenCommitted = whenCommitted
        self.message = message
        self.pathModifications = pathModifications

    def __str__(self):
        return 'r{} | {} | {}\n{}\n{}'.format(self.revisionNumber, self.author, str(self.whenCommitted), self.message,
                                              '\n'.join('    ' + x.path for x in self.pathModifications))


def getRevisions(repoUrl, revSpecStr=None, shouldIncludeLogMessages=True,
                 shouldIncludePaths=True, limit=None, stopOnCopy=False, ignoreDecodingErrors=False):
    # Return Revisions at repoUrl in the range specified by revSpecStr.
    #
    # revSpecStr should be in a format acceptible to 'svn log', i.e., both bounds (if specified)
    # will be included in the revisions returned.
    #
    # If shouldIncludePaths is true, revisions include path-modification information.
    #
    # If shouldIncludeLogMessages is true, revisions include their log messages.
    #
    # If set to an integer, limit tells Subversion to show no more than that many revisions.
    #
    # A line in the 'modified paths' section looks like, e.g.:
    #
    #   M /ecommerce/sites/pk/content/branches/release-baker/static/sass/shop.sass
    #
    # with a leading fixed-length prefix of spaces and modifier characters, followed by a path
    # relative to the repo root, followed by / and the path we're interested in.
    #
    # In this example, filePathPrefix will be '/ecommerce/sites/pk/content/branches/release-baker/'
    # (i.e., the relativeUrl from the repo root minus the leading ^ and with a trailing /), and
    # we'll use 'static/sass/shop.sass' as the modified path.
    #
    # NOTE: Because we include the slash '/' in the prefix, modifications to the root directory
    # itself will not be included in the modified paths.  Currently this aligns well with our
    # callers, but beware.

    # Changed path lines begin with a fixed-length prefix of spaces and modifier characters.
    changedPathModifierPrefixLen = 5

    if repoUrl.startswith('^'):
        relativeUrl = repoUrl
    else:
        try:
            relativeUrl = getRepoUrl(repoUrl=repoUrl, getAbsolute=False)
        except subprocess.CalledProcessError:
            logging.warning('Bad URL %s; ignoring revisions', repoUrl)
            return []

    filePathPrefix = relativeUrl

    if filePathPrefix.startswith('^'):
        filePathPrefix = filePathPrefix[1:]

    if not filePathPrefix.endswith('/'):
        filePathPrefix += '/'

    filePathPrefixLen = len(filePathPrefix)

    # Use a state machine to parse the various components of the "svn
    # log -v" ouptut.
    STATE_FIND_AUTHORSHIP = 'Find Authorship'
    STATE_FIND_CHANGED_PATHS_LABEL = 'Find Changed Paths Label'
    STATE_FIND_CHANGED_FILES = 'Find Changed Files'
    STATE_FIND_LOG_MESSAGE = 'Find Log Message'
    STATE_GATHER_LOG_MESSAGE = 'Gather Log Message'

    revisions = []

    currentRevision = None

    currentAuthor = None  # Initializing these quiets spurious pylint warning
    currentWhenCommitted = None
    currentPathModifications = []
    currentMessage = ''

    state = STATE_FIND_AUTHORSHIP

    cmdOptions = []

    if revSpecStr:
        cmdOptions += ['-r', revSpecStr]

    if not shouldIncludeLogMessages:
        cmdOptions += ['-q']

    if shouldIncludePaths:
        cmdOptions += ['-v']

    if limit is not None:
        cmdOptions += ['--limit', str(limit)]

    if stopOnCopy:
        cmdOptions += ['--stop-on-copy']

    cmd = ['svn', 'log'] + cmdOptions + [repoUrl]

    output = run(cmd, ignoreDecodingErrors=ignoreDecodingErrors)

    for line in output.splitlines():
        if state == STATE_FIND_AUTHORSHIP:
            result = re.match(r'r(\d+) \| (.+?) \| (\d{4}.*?) \(', line)
            if result:
                if currentRevision:
                    thisRevision = Revision(revisionNumber=currentRevision,
                                            author=currentAuthor,
                                            whenCommitted=currentWhenCommitted,
                                            message=currentMessage,
                                            pathModifications=currentPathModifications)
                    revisions.append(thisRevision)

                currentPathModifications = []
                currentMessage = ''

                currentRevision = int(result.group(1))
                currentAuthor = result.group(2)
                currentWhenCommitted = datetime.datetime.strptime(result.group(3), '%Y-%m-%d %H:%M:%S %z')

                if shouldIncludePaths:
                    state = STATE_FIND_CHANGED_PATHS_LABEL
                elif shouldIncludeLogMessages:
                    state = STATE_FIND_LOG_MESSAGE
                else:
                    pass  # The current state is the only one we need.

        elif state == STATE_FIND_CHANGED_PATHS_LABEL:
            if line == 'Changed paths:':
                state = STATE_FIND_CHANGED_FILES

        elif state == STATE_FIND_CHANGED_FILES:
            # If we are including log messages, there will be a blank line after the file list.  If
            # we aren't, then there will be a '----------' line after it.
            if shouldIncludeLogMessages and line == '':
                state = STATE_FIND_LOG_MESSAGE

            if not shouldIncludeLogMessages and line.startswith('-'):
                state = STATE_FIND_AUTHORSHIP

            if state == STATE_FIND_CHANGED_FILES:
                if not re.match(r'\s*$', line):
                    thisModification = line[:changedPathModifierPrefixLen]
                    pathPartOfLine = line[changedPathModifierPrefixLen:]

                    if pathPartOfLine.startswith(filePathPrefix):
                        # Strip file path prefix.
                        thisFilePath = pathPartOfLine[filePathPrefixLen:]
                    else:
                        # Project root, e.g., svn:mergeinfo update.  Ignore; see comment at top of
                        # function.
                        continue

                    # Sometimes Subversion will follow a path with " (from ..."; strip that portion
                    # if it's there.  (We can be reasonably sure that no actual path contains that
                    # pattern.)
                    result = re.match(r'(.+) \(from ', thisFilePath)
                    if result:
                        thisFilePath = result.group(1)

                    thisPathModification = PathModification(path=thisFilePath,
                                                            modification=thisModification)
                    currentPathModifications.append(thisPathModification)

        elif state == STATE_FIND_LOG_MESSAGE:
            if not re.match(r'\s*$', line):
                state = STATE_GATHER_LOG_MESSAGE
                # Fall through to next state, to pick up the first line of the log message.

        # Using 'if' instead of 'elif' here to allow fallthrough from STATE_FIND_LOG_MESSAGE.
        if state == STATE_GATHER_LOG_MESSAGE:
            if re.match(r'-{40}-*$', line):
                state = STATE_FIND_AUTHORSHIP
            else:
                currentMessage += line + '\n'

    if currentRevision:
        thisRevision = Revision(revisionNumber=currentRevision,
                                author=currentAuthor,
                                whenCommitted=currentWhenCommitted,
                                message=currentMessage,
                                pathModifications=currentPathModifications)
        revisions.append(thisRevision)

    return revisions


def getChangers(repoUrl, filePaths, fromRevision, toRevision):
    # Show usernames that had touched any of filePaths in (fromRevision, toRevision] (i.e.,
    # excluding fromRevision but including toRevision), in the branch specified by repoUrl.
    if fromRevision >= toRevision:
        # Empty revision range (which svn won't treat as empty).
        return []

    revRange = '{}:{}'.format(toRevision, fromRevision + 1)
    output = run(['svn', 'log', '-v', '-r', revRange, repoUrl])

    # Use a dictionary for filePaths for quick lookup.
    filePathsDict = {path: None for path in filePaths}

    # A line looks like, e.g.:
    #
    #   M /ecommerce/sites/pk/content/branches/release-baker/static/sass/shop.sass
    #
    # with a leading fixed-length prefix of spaces and modifier characters, followed by a path
    # relative to the repo root, followed by / and the path we're interested in.
    #
    # In this example, filePathPrefix will be '/ecommerce/sites/pk/content/branches/release-baker/'
    # (i.e., the relativeUrl of the repo root minus the leading ^ and with a trailing /) and we'll
    # look for files that match the remainder of the line.

    # Changed path lines begin with a fixed-length prefix of spaces and modifier characters.
    changedPathModifierPrefixLen = 5

    if repoUrl.startswith('^'):
        relativeUrl = repoUrl
    else:
        relativeUrl = getRepoUrl(repoUrl=repoUrl, getAbsolute=False)

    filePathPrefix = relativeUrl + '/'
    if filePathPrefix.startswith('^'):
        filePathPrefix = filePathPrefix[1:]

    filePathPrefixLen = len(filePathPrefix)

    currentChanger = None

    changers = {}

    # Use a state machine to parse the various components of the "svn
    # log -v" ouptut.
    state = 'Find Revision Header'
    for line in output.splitlines():
        if state == 'Find Revision Header':
            if re.match(r'-+$', line):
                state = 'Find Authorship'

        elif state == 'Find Authorship':
            result = re.match(r'r\d+ \| (.+?) \|', line)
            if result:
                currentChanger = result.group(1)
                state = 'Find Changed Paths Label'

        elif state == 'Find Changed Paths Label':
            if line == 'Changed paths:':
                state = 'Find Changes'

        elif state == 'Find Changes':
            if line == '':
                state = 'Find Revision Header'
            else:
                pathPartOfLine = line[changedPathModifierPrefixLen:]
                if pathPartOfLine.startswith(filePathPrefix):
                    # Strip file path prefix.
                    thisFilePath = pathPartOfLine[filePathPrefixLen:]

                    # If this path is one of the paths we're
                    # interested in, add the current changer to the
                    # set.
                    if thisFilePath in filePathsDict:
                        changers[currentChanger] = None

    return list(changers.keys())


@functools.lru_cache(maxsize=None)
def svnUserToEmailAddr(username):
    """
    Convert username to email address via ldap lookup.

    Reconnects to LDAP server with each call, so if you're looking up a lot of these you should
    inline this routine or update this to optionally take an ldapConnection param.
    """
    answer = wsgc.ecomldap.ldapLookupOne(username=username, lookupProperty='mail')

    if answer:
        # Downcase the email address to make them look less weird (e.g, 'WSGC.com').
        answer = answer.lower()

    return answer


def resolvePomIssues(relPath, srcUrl, destUrl, oldPomVersions, newPomVersions, interestingVersionChoices):
    # In what is presumably a newly-merged repo, compare oldPomVersions and newPomVersions (which are
    # pomhelper output prior to and after the merge), and run pomhelper if we decide we need to fix
    # up the new versions.
    #
    # Returns newPomVersions (possibly updated after running pomhelper).
    if not newPomVersions:
        # pomhelper didn't apply to this repo
        logging.debug('resolvePomIssues: inapplicable in %s', destUrl)
        return newPomVersions

    weModifiedPomfiles = False  # So far.

    projectName = oldPomVersions['projectName']

    if newPomVersions['projectName'] != projectName:
        # The project name changed, which shouldn't happen.
        sys.exit('Project name of {} changed from {} to {}'.
                 format(relPath, projectName, newPomVersions['projectName']))

    oldProjectVersion = oldPomVersions['projectVersion']
    newProjectVersion = newPomVersions['projectVersion']

    if newProjectVersion == oldProjectVersion:
        projectVersion = newProjectVersion
    else:
        try:
            projectVersion = wsgc.pomutils.getMergedPomProjectVersion(
                propertyName='project version',
                oldVersion=oldProjectVersion, newVersion=newProjectVersion,
                srcUrl=srcUrl, destUrl=destUrl,
                interestingVersionChoices=interestingVersionChoices)
        except wsgc.pomutils.MergedVersionError as e:
            sys.exit(e.msg)

        logging.info('Project version changed: %s -> %s, using %s',
                     oldProjectVersion, newProjectVersion, projectVersion)

        if projectVersion != newProjectVersion:
            # Use the correct version.
            wsgc.pomutils.setProjectVersion(projectVersion)
            weModifiedPomfiles = True

    oldPropertyVersions = oldPomVersions['propertyVersions']
    newPropertyVersions = newPomVersions['propertyVersions']

    for propertyName, oldPropertyVersion in oldPropertyVersions.items():
        newPropertyVersion = newPropertyVersions.get(propertyName, '<none>')

        if newPropertyVersion == oldPropertyVersion:
            continue

        if wsgc.pomutils.isPropertyVersionWeCareAboutChanging(propertyName):
            try:
                mergedPropertyVersion = wsgc.pomutils.getMergedPomProjectVersion(
                    propertyName=propertyName,
                    oldVersion=oldPropertyVersion, newVersion=newPropertyVersion,
                    srcUrl=srcUrl, destUrl=destUrl,
                    interestingVersionChoices=interestingVersionChoices)
            except wsgc.pomutils.MergedVersionError as e:
                sys.exit(e.msg)

            logging.info("property '%s' version changed: %s -> %s, using %s",
                         propertyName, oldPropertyVersion, newPropertyVersion, mergedPropertyVersion)
            if mergedPropertyVersion != newPropertyVersion:
                # Use the correct version.
                wsgc.pomutils.setPropertyVersion(propertyName, mergedPropertyVersion)
                weModifiedPomfiles = True
        else:
            # The value changed, but it wasn't one of the properties we pay
            # attention to so we will accept it no matter what.
            logging.info('property %s version changed: %s -> %s',
                         propertyName, oldPropertyVersion, newPropertyVersion)

    for propertyName, newPropertyVersion in newPropertyVersions.items():
        if propertyName not in oldPropertyVersions:
            logging.info('property %s appeared with version %s', propertyName, newPropertyVersion)

    if weModifiedPomfiles:
        newPomVersions = wsgc.pomutils.getPomVersions()

    return newPomVersions


def isReleaseBranchName(branchName):
    # True if this is named like our release branches; we have restrictions on what sorts of things
    # we're willing to do there (e.g., don't merge anything but other release branches to them).
    # Use this to identify them.
    #
    # This will work with shortcut branches or the branches pointed to by the externals of a
    # shortcut.  Handle shortcuts first.
    result = re.match(r'(.*)-shortcut$', branchName)
    if result:
        baseShortcutName = result.group(1)
        if baseShortcutName == 'trunk':
            return False

        # It's a release shortcut if the base is one word, optionally preceded by "release-", and
        # optionally followed by an "interim release" specifier, like 'release-jeangrey-20.10.06'.
        return re.match(r'(?:release-)?[a-zA-Z]+(?:-[a-zA-Z]{3})?(?:-\d{2}\.\d{2}\.\d{2})?$', baseShortcutName)

    # branchName is a code branch, not a shortcut branch.
    return re.match(r'release-(?:(?:\d+\.)*\d+|[a-zA-Z]+)(?:-\d{2}\.\d{2}\.\d{2})?$', branchName)


def getDiff(repoUrl, revisionNumber, paths=None, ignoreDecodingErrors=False):
    # Return the diff represented by the revision number, or None if there was an error.  If paths
    # is passed, limit the diff to those paths.  If ignoreDecodingErrors is True, then instead of
    # raising a decoding error on un-decodable diff output (which happens sometimes), replace
    # unknown characters with the a replacement character (e.g., '?') and consider this a success.

    # You can't use -c with paths(!), so build a revision specifier that can be used with -r.
    revSpec = '{}:{}'.format(revisionNumber - 1, revisionNumber)

    cmd = ['svn', 'diff', '-r', revSpec, '--old', repoUrl]

    if paths:
        # Limit the diffs to changes affecting these paths.
        for path in paths:
            # Subversion expects the paths to be relative to repoUrl, and in most circumstances
            # that's what we'll be passed.  But if a revision modified paths outside the external,
            # or if it modified the root of the external (by updating the svn:mergeinfo property
            # perhaps) it will be listed here as an absolute path, and Subversion will croak.
            # Silently omit them from the diff.  (Alternately, you could check to see if they refer
            # to a path within repoUrl and if so convert them to a relative path.)
            if not path.startswith('/'):
                cmd.append(path)

    try:
        return run(cmd, ignoreDecodingErrors=ignoreDecodingErrors)
    except subprocess.CalledProcessError as e:
        # Because we asked run() to ingore decoding errors, the command output is first gathered in
        # raw form.  When there's an exception, it doesn't get decoded, so we have to do that
        # ourselves here before treating it as a string.
        textOutput = wsgc.util.bytesToTextForgivingly(e.output)

        if 'was not found in the repository at revisions' in textOutput:
            # If the path appeared in this revision, then it won't have existed in revision-1 and
            # we'll get this error.  I don't know a way around this without a WHOLE lot of
            # special-casing that isn't worth it for what we're trying to do.  Punt to the caller.
            return None

        sys.exit(textOutput)


def shortcutNameToUrl(shortcutName):
    # Return a repo URL for this shortcut name.  This hardcodes the path; do not use except in the
    # limited domain of dp shortcuts.
    if shortcutName == 'trunk':
        # The trunk shortcut is represented by a branch named 'trunk-shortcut'.
        branchName = 'trunk-shortcut'
    else:
        branchName = shortcutName

    return 'https://{}/svn/shortcuts/evolution/branches/{}'.format(MASTER_SVN_SERVER_NAME, branchName)


def runAnt(workDir, extendEnv, timeoutSeconds=None):
    # Run ant in workDir, returning (didPass, output)

    def getRemovedPaths(output):
        # Look for lines that remove paths.  If a path is created after it is removed, don't
        # consider it removed.
        #
        # (The sprite process cares about timestamps, but it's looking at tracked files, whose
        # timestamps are unpredictable so sometimes it unnecessarily recreates a file.  Since the
        # tracked filenames it creates are determined by their contents, we can feel confident that
        # a file that has been recreated is the same as the file by the same name that was removed.)
        removedPaths = {}

        for line in output.splitlines():
            result = re.match(r'(?:^|\n)\s+\[[a-z]+\]\s+(remove|create)\s(.+)$', line)
            if result:
                verb, path = result.groups()

                # Some messages are part of normal output, but match the above regexp.  Ignore them.
                if 'from save for later in localstorage' in path:
                    continue

                if verb == 'remove':
                    removedPaths[path] = 1
                elif verb == 'create' and path in removedPaths:
                    del removedPaths[path]

        return removedPaths.keys()

    try:
        output = run('ant', cwd=workDir, extendEnv=extendEnv, timeoutSeconds=timeoutSeconds)
        removedPaths = getRemovedPaths(output)

        if removedPaths:
            # ant succeeded, but it removed files, which is not okay.
            output += '\n*** Failing ant because it removed the following paths ***\n'
            for path in removedPaths:
                output += '    {}\n'.format(path)
            didPass = False
        else:
            didPass = True
    except subprocess.CalledProcessError as e:
        output = e.output
        didPass = False

    return didPass, output


def getBranchCreationDate(repoUrl):
    revisions = getRevisions(repoUrl,
                             shouldIncludeLogMessages=False,
                             shouldIncludePaths=False,
                             stopOnCopy=True)
    if not revisions:
        sys.exit('Unable to get branch creation date of {}'.format(repoUrl))

    # We want the date of the oldest revision, since we stopped on copy.
    return revisions[-1].whenCommitted


class UrlError(Exception):
    pass


def isSvnWorkDir(workDir='.'):
    """
    True if workDir is the top level directory of a Subversion repo.
    """
    return os.path.exists(os.path.join(workDir, ".svn"))


def isSvnUrl(repoUrl):
    try:
        getUrlTypeAndBranchName(repoUrl)
    except SvnUrlError:
        return False

    return True
