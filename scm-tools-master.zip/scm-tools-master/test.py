from wsgc import ecomjira

if __name__ == '__main__':
    try:
        jira = ecomjira.getJiraIssue("TAH-58731")
        print(jira)
#        print(jira.fields)
#        for comment in jira.fields.comment.comments:
#            commentID = comment.id
#            print(commentID)
        #print('there are {} users'.format(len(getJiraGroupMembers('jira-users'))))
    except KeyboardInterrupt:
        # Don't dump stack, just exit.
        sys.exit(' Interrupted by user')  # The space leaves room after the echoed ^C.

