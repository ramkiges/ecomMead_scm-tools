#!/usr/bin/env python3

BRAND_FULL_NAME = {
    'WS': 'williams-sonoma',
    'WE': 'westelm',
    'PK': 'potterybarnkids',
    'PB': 'potterybarn',
    'PT': 'pbteen',
    'MG': 'markandgraham',
    'RJ': 'rejuvenation',
    'GR': 'greenrow'
}

# Akamai Host vs its corresponding WSI host for east and west region
AKAMAI_WSI_DOMAIN = {
    'origin-aktest.pk.wsi.ca.akadns.net': {
        'west': 'origin-sac-aktest.potterybarnkids.ca',
        'east': 'origin-sac-aktest.potterybarnkids.ca'  # east has not been setup yet by the ESRE
    },
    'origin-aktest.pt.wsi.ca.akadns.net': {
        'west': 'origin-sac-aktest.pbteen.ca',
        'east': 'origin-ash-aktest.pbteen.ca'
    },
    'origin-ash-www.pk.wsi.ca.akadns.net': {
        'east': 'origin-ash-www.potterybarnkids.ca',
        'west': None
    },
    'origin-sac-www.pk.wsi.ca.akadns.net': {
        'east': None,
        'west': 'origin-sac-www.potterybarnkids.ca'
    },
    'origin-aktest.pb.wsi.ca.akadns.net': {
        'west': 'origin-sac-aktest.potterybarn.ca',
        'east': 'origin-sac-aktest.potterybarn.ca'  # east has not been setup yet by the ESRE
    },
    'origin-ash-www.pb.wsi.ca.akadns.net': {
        'east': 'origin-ash-www.potterybarn.ca',
        'west': None
    },
    'origin-aktest.gr.wsi.com.akadns.net': {
        'east': 'origin-ash-aktest.greenrow.com',
        'west': 'origin-sac-aktest.greenrow.com'
    },
    'origin-aktest.rj.wsi.com.akadns.net': {
        'east': 'origin-ab-aktest.rejuvenation.com',
        'west': 'origin-rk-aktest.rejuvenation.com'
    },
    'origin-rk-aktest.rj.wsi.com.akadns.net': {
        'east': None,
        'west': 'origin-rk-aktest.rejuvenation.com'
    },
    'origin-sac-www.pb.wsi.ca.akadns.net': {
        'east': None,
        'west': 'origin-sac-www.potterybarn.ca'
    },
    'origin-sac-www.pt.wsi.ca.akadns.net': {
        'east': None,
        'west': 'origin-sac-www.pbteen.ca'
    },
    'origin-ash-www.pt.wsi.ca.akadns.net': {
        'east': 'origin-ash-www.pbteen.ca',
        'west': None
    },
    'origin-aktest.ws.wsi.ca.akadns.net': {
        'west': 'origin-sac-aktest.williams-sonoma.ca',
        'east': 'origin-sac-aktest.williams-sonoma.ca'  # east has not been setup yet by the ESRE
    },
    'origin-ash-www.ws.wsi.ca.akadns.net': {
        'east': 'origin-ash-www.williams-sonoma.ca',
        'west': None
    },
    'origin-sac-www.ws.wsi.ca.akadns.net': {
        'east': None,
        'west': 'origin-sac-www.williams-sonoma.ca'
    },
    'origin-aktest.we.wsi.ca.akadns.net': {
        'west': 'origin-sac-aktest.westelm.ca',
        'east': 'origin-sac-aktest.westelm.ca'  # east has not been setup yet by the ESRE
    },
    'origin-ash-www.we.wsi.ca.akadns.net': {
        'east': 'origin-ash-www.westelm.ca',
        'west': None
    },
    'origin-sac-www.we.wsi.ca.akadns.net': {
        'east': None,
        'west': 'origin-sac-www.westelm.ca'
    }
}

# Derive akamai property name based on ENV-MARKET-BRAND
ENV_AKAMAI_PROPERTY_ENV = {
    'QA': {
        'ALL': {
            'MG': 'qa.markandgraham.com_pm',
            'PB': 'qa.potterybarn.com_pm',
            'PK': 'qa.potterybarnkids.com_pm',
            'PT': 'qa.pbteen.com_pm',
            'WE': 'qa.westelm.com_pm',
            'WS': 'qa.williams-sonoma.com_pm',
            'RJ': 'qa.rejuvenation.com_pm',
            'GR': 'qa.greenrow.wsgc.com_pm',
        },
    },
    'PROD': {
        'USA': {
            'MG': 'prod.markandgraham.com_pm',
            'PB': 'prod.potterybarn.com_pm',
            'PK': 'prod.potterybarnkids.com_pm',
            'PT': 'prod.pbteen.com_pm',
            'WE': 'prod.westelm.com_pm',
            'WS': 'prod.williams-sonoma.com_pm',
            'RJ': 'prod.rejuvenation.com_pm',
            'GR': 'prod.greenrow.com_pm',
        },
        'CAN': {
            'PB': 'prod.potterybarn.ca_pm',
            'PK': 'prod.potterybarnkids.ca_pm',
            'WE': 'prod.westelm.ca_pm',
            'WS': 'prod.williams-sonoma.ca_pm',
            'PT': 'prod.pbteen.ca_pm',
        },
    },
    'AKTEST': {
        'USA': {
            'MG': 'prod.markandgraham.com_pm',
            'PB': 'prod.potterybarn.com_pm',
            'PK': 'prod.potterybarnkids.com_pm',
            'PT': 'prod.pbteen.com_pm',
            'WE': 'prod.westelm.com_pm',
            'WS': 'prod.williams-sonoma.com_pm',
            'RJ': 'prod.rejuvenation.com_pm',
            'GR': 'prod.greenrow.com_pm',
        },
        'CAN': {
            'PB': 'prod.potterybarn.ca_pm',
            'PK': 'prod.potterybarnkids.ca_pm',
            'WE': 'prod.westelm.ca_pm',
            'WS': 'prod.williams-sonoma.ca_pm',
            'PT': 'prod.pbteen.ca_pm',
        },
    },
}

# nginx-helm-config repo config folder name based on ENV-MARKET-BRAND
GIT_REPO_CONFIG_FOLDER = {
    'QA': {
        'ALL': {
            'MG': 'mgqa',
            'PB': 'pbqa',
            'PK': 'pkqa',
            'PT': 'ptqa',
            'WE': 'weqa',
            'WS': 'wsqa',
            'RJ': 'rjqa',
            'GR': 'grqa',
        },
    },
    'PROD': {
        'USA': {
            'MG': 'mg-prod',
            'PB': 'pb-prod',
            'PK': 'pk-prod',
            'PT': 'pt-prod',
            'WE': 'we-prod',
            'WS': 'ws-prod',
            'RJ': 'rj-prod',
            'GR': 'gr-prod',
        },
        'CAN': {
            'PB': 'pb-ca-prod',
            'PK': 'pk-ca-prod',
            'WE': 'we-ca-prod',
            'WS': 'ws-ca-prod',
            'MG': 'mg-ca-prod',
            'PT': 'pt-ca-prod',
            'RJ': 'rj-ca-prod',
            'GR': 'gr-ca-prod',
        },
    },
    'AKTEST': {
        'USA': {
            'MG': 'mg-preprd',
            'PB': 'pb-preprd',
            'PK': 'pk-preprd',
            'PT': 'pt-preprd',
            'WE': 'we-preprd',
            'WS': 'ws-preprd',
            'RJ': 'rj-preprd',
            'GR': 'gr-preprd',
        },
        'CAN': {
            'PB': 'pb-ca-preprd',
            'PK': 'pk-ca-preprd',
            'WE': 'we-ca-preprd',
            'WS': 'ws-ca-preprd',
            'MG': 'mg-ca-preprd',
            'PT': 'pt-ca-preprd',
            'RJ': 'rj-ca-preprd',
            'GR': 'gr-ca-preprd',
        },
    },
}

