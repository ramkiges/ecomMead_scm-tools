#!/usr/bin/env python3
import re
import sys

from akamaiNginx import akamaiConfigParser
from akamaiNginx import constants


# stores the nginx server block
NGINX_SERVER_BLOCKS = []

# nginx server host is the key with value as an index pointing to the NGINX_SERVER_BLOCKS list
NGINX_SERVERBLOCKS_HOSTS_MAPPING = {}

# list containing the akamai rules with regex hosts to be processed at the end
REGEX_HOSTS_RULES = []

# Regex to match the location config
LOCATION_MATCH_REGEX = r'(~\*\s+)(\(\^\(\?\!\(.*\)\)\)){0,1}(\(\^\((.*)\)\$\))'

# nginx per location config character limit
NGINX_LOCATION_CONFIG_LIMIT = 3000

def convertAkamaiToNginxRules(env, brand, market, ruleMap):
    """
    Convert the parsed akamai rules to nginx config
    """
    if env in ["PROD", "AKTEST"]:
        regions = ["west", "east"]
    else:
        regions = ["rk"]  # This region value for non-prod is not used. It's here just to iterate over the regions

    nginxConfigRegion = {}  # Populate the nginx config serverBlock for each region
    nginxHostRegion = {}  # Populate the nginx hosts for each region

    for region in regions:
        # start with index 0 and is incremented as and when a new host serverblock is added.
        index = 0
        for fileName, fileRules in ruleMap.items():
            for rule, ruleObject in fileRules.items():
                hosts = []
                pathRegex = ""  # nginx location regex translated from akamai.
                if checkIfAnyBehaviorExistInRuleTree(ruleObject):
                    pathRegex, index, processLater, noFurtherProcessing = handleRule(ruleObject, hosts, pathRegex,
                                                                                     index, region, env)
                    handleChildRule(ruleObject, hosts, pathRegex, index, region, env,
                                    processLater, noFurtherProcessing)

        # Use the keys of the dict as the hosts for the nginx ingress.
        # Keys will always contain the absolute hosts with no wildcard
        nginxHostRegion[region] = list(NGINX_SERVERBLOCKS_HOSTS_MAPPING.keys())

        for ruleObject in REGEX_HOSTS_RULES:
            hosts = []
            pathRegex = ""
            if checkIfAnyBehaviorExistInRuleTree(ruleObject):
                pathRegex, index, processLater = handleRegexHostRules(ruleObject, hosts, pathRegex, index, region, env)
                handleRegexChildRule(ruleObject, hosts, pathRegex, index, region, env)

        nginxConfig = convertToNGINXConfig(NGINX_SERVER_BLOCKS, env, brand, market)
        nginxConfigRegion[region] = nginxConfig

        NGINX_SERVER_BLOCKS.clear()
        NGINX_SERVERBLOCKS_HOSTS_MAPPING.clear()
        REGEX_HOSTS_RULES.clear()

    return nginxConfigRegion, nginxHostRegion


def handleChildRule(ruleObject, hosts, pathRegex, index, region, env, processLater, noFurtherProcessing):
    """
    Recursively handle the child rules of a rule for criteria and behavior objects
    """
    if "children" in ruleObject and not processLater and not noFurtherProcessing:
        for childRuleObject in ruleObject["children"]:
            pathRegex, index, processLater, noFurtherProcessing = handleRule(childRuleObject, hosts, pathRegex, index,
                                                                             region, env)
            handleChildRule(childRuleObject, hosts, pathRegex, index, region, env, processLater, noFurtherProcessing)


def handleRegexChildRule(ruleObject, hosts, pathRegex, index, region, env):
    """
    Recursively handle the child rules of a rule containing regex hosts for criteria and behavior objects
    """
    if "children" in ruleObject:
        for childRuleObject in ruleObject["children"]:
            pathRegex, index, processLater = handleRegexHostRules(childRuleObject, hosts, pathRegex, index, region, env)
            handleRegexChildRule(childRuleObject, hosts, pathRegex, index, region, env)


def checkIfAnyBehaviorExistInRuleTree(ruleObject):
    """
    Return True only if the rule or its children contain a behavior object else rule is of no use to us.
    """
    if "behaviors" in ruleObject["rules"]:
        return True

    if "children" in ruleObject:
        for childRule in ruleObject["children"]:
            isAny = checkIfAnyBehaviorExistInRuleTree(childRule)
            if isAny:
                return isAny


def convertToNGINXConfig(nginxServerBlocks, env, brand, market):
    """
    Form the nginx config string with the server and the location blocks and return
    """
    nginxConfig = ""
    for nginxServerBlock in nginxServerBlocks:
        # Nginx server without locations block is of no use.
        if not "locations" in nginxServerBlock:
            continue

        nginxConfig += ' ' * 2 + "server {\n" + nginxServerBlock["server"] + "\n\n"
        locations = nginxServerBlock["locations"]
        locations.reverse()
        reOrderedLocations = moveDPLocationsAtEnd(locations)
        additionalLocations = getAdditionalLocations(env, brand, market)
        newLocations = additionalLocations + reOrderedLocations
        newLocations = splitLargeConfigLocations(newLocations)

        for location in newLocations:
            for locationStr, valueArr in location.items():
                nginxConfig += ' ' * 4 + "location " + locationStr + " {\n"
                for value in valueArr:
                    nginxConfig += value + "\n"
                nginxConfig += ' ' * 4 + "}\n\n"
        nginxConfig += ' ' * 2 + "}\n"

    return nginxConfig


def getAdditionalLocations(env, brand, market):
    """
    Add additional location blocks for idstorage and netstorage which is specific to akamai
    """
    additionalLocations = []
    if env == "PROD" or env == "AKTEST":
        brandFullName = constants.BRAND_FULL_NAME[brand]
        extension = "com" if market == "USA" else "ca"
        urlprefix = "www"
        if env == "AKTEST":
            urlprefix = "aktest-" + urlprefix

        dpURL = 'https://{}.{}.{}'.format(urlprefix, brandFullName, extension)

        proxyPassText = ' ' * 6 + "proxy_pass " + dpURL + ";"

        idStoragePathRegex = '(^(/api/visitor/v1/storage)$)'
        idStoragePathRegex = idStoragePathRegex.replace('.', '\.').replace('/', '\/').replace('*', '.*').replace('?', '.?')
        additionalLocations.append({"~* " + idStoragePathRegex: [proxyPassText]})

        netstoragePathRegex = '(^(/netstorage/*)$)'
        netstoragePathRegex = netstoragePathRegex.replace('.', '\.').replace('/', '\/').replace('*', '.*').replace('?', '.?')
        additionalLocations.append({"~* " + netstoragePathRegex: [proxyPassText]})

    return additionalLocations


def moveDPLocationsAtEnd(locations):
    """
    Move location blocks for the DP host at the end so ADG and other routes get preference first as nginx engine
    selects the first regex match it gets. Also add a default location for DP which will route all the requests
    that did not match any regex routes.
    """
    reOrderedLocations = []
    dpLocations = []
    dpProxyPassBlockForDefaultLocation = None  # contains the proxy_pass directive for DP to be used as default location for routing
    for location in locations:
        for locationStr, valueArr in location.items():
            isDPBlock = False
            for value in valueArr:
                # check for the DP hosts in proxy_pass directive
                if "proxy_pass" in value and \
                        any(dpHostPrefix in value for dpHostPrefix in ["origin-internal-ab-www",
                                                                       "origin-internal-rk-www",
                                                                       "origin-internal-ash-www",
                                                                       "origin-internal-sac-www",
                                                                       "origin-ab-aktest",
                                                                       "origin-rk-aktest",
                                                                       "origin-ash-aktest",
                                                                       "origin-sac-aktest"]):
                    dpLocations.append({locationStr: valueArr})
                    dpProxyPassBlockForDefaultLocation = valueArr
                    isDPBlock = True
                    break

            if not isDPBlock:
                reOrderedLocations.append({locationStr: valueArr})

    if dpProxyPassBlockForDefaultLocation:
        # add default routing location
        dpLocations.append({"/": dpProxyPassBlockForDefaultLocation})
        reOrderedLocations = reOrderedLocations + dpLocations

    return reOrderedLocations


def splitLargeConfigLocations(locations):
    """
    Split large config for ADG location block into smaller ones as nginx does not allow more than 4096 bytes and results
    in too long parameter error.
    Keep the negation regex part(does not match of) in all the smaller configs. Only the match one of regex parts is
    divided into smaller parts and is splitted at 3000 characters
    """
    updatedLocations = []
    for location in locations:
        for locationStr, valueArr in location.items():
            isADGBlock = False
            for value in valueArr:
                if "proxy_pass" in value and "origin-svc" in value:
                    isADGBlock = True
                    break

            if isADGBlock:
                #  Extract the match of and does not match of along with nginx regex identifier from the location string
                match = re.match(LOCATION_MATCH_REGEX, locationStr)
                if match:
                    if len(locationStr) > NGINX_LOCATION_CONFIG_LIMIT:
                        locationIdentifier = match.group(1)
                        negationRouteRegex = match.group(2)
                        routesOnlyMatchRegex = match.group(4)

                        # available length for the location block to add the match one of routes
                        availableLength = NGINX_LOCATION_CONFIG_LIMIT - len(negationRouteRegex)

                        # Atleast there should be space for 100 characters else error out
                        if availableLength < 100:
                            sys.exit("Negation regex is too long and as a result the location block for nginx could "
                                     "not be formed within nginx byte limit. Please reach to MEAD/TAHOE if this ever "
                                     "happens")
                        routes = routesOnlyMatchRegex.split('|')

                        # split to smaller location blocks
                        newGroupLength = 0
                        newGroupRoutes = []
                        for route in routes:
                            newGroupLength += len(route)
                            newGroupRoutes.append(route)
                            if newGroupLength >= availableLength:
                                newGroupRouteStr = "|".join(newGroupRoutes)
                                newLocationStr = f"{locationIdentifier}{negationRouteRegex}(^({newGroupRouteStr})$)"
                                updatedLocations.append({newLocationStr: valueArr})
                                newGroupLength = 0
                                newGroupRoutes = []
                        if newGroupRoutes:
                            newGroupRouteStr = "|".join(newGroupRoutes)
                            newLocationStr = f"{locationIdentifier}{negationRouteRegex}(^({newGroupRouteStr})$)"
                            updatedLocations.append({newLocationStr: valueArr})
                    else:
                        updatedLocations.append({locationStr: valueArr})
                else:
                    updatedLocations.append({locationStr: valueArr})
            else:
                updatedLocations.append({locationStr: valueArr})
    return updatedLocations


def handleRule(ruleObject, hosts, pathRegex, index, region, env):
    """
    Handler for the rule criteria and behavior objects
    """
    pathRegex, index, noFurtherProcessing = handleCriteria(ruleObject, hosts, pathRegex, index, region, env)
    pathRegex, processLater = handleBehaviors(ruleObject, hosts, pathRegex, region, env)

    return pathRegex, index, processLater, noFurtherProcessing


def handleCriteria(ruleObject, hosts, pathRegex, index, region, env):
    """
    Handler for the criteria objects
    """
    noFurtherProcessing = False
    if "criterias" in ruleObject["rules"]:
        for criteria in ruleObject["rules"]["criterias"]:
            if criteria["name"] == "hostname":
                index, noFurtherProcessing = handleHostNameCriteria(ruleObject, criteria, hosts, index, region, env)
                if noFurtherProcessing:
                    return pathRegex, index, noFurtherProcessing
            elif criteria["name"] == "path":
                pathRegex = handlePathCriteria(criteria, pathRegex)

    return pathRegex, index, noFurtherProcessing


def handleRegexHostRules(ruleObject, hosts, pathRegex, index, region, env):
    """
    Handler for the rule criteria and behavior objects for the regex hosts
    """
    if "criterias" in ruleObject["rules"]:
        for criteria in ruleObject["rules"]["criterias"]:
            if criteria["name"] == "hostname":
                index = handleRegexHostNameCriteria(criteria, hosts, index, region, env)
            elif criteria["name"] == "path":
                pathRegex = handlePathCriteria(criteria, pathRegex)

    # If there are no hosts for a given rule, use all of the existing hosts
    if not hosts:
        hosts = NGINX_SERVERBLOCKS_HOSTS_MAPPING.keys()

    # If there are still no hosts, use a wildcard regex host and add it as a serverBlock to the nginx config
    if not hosts:
        if env == "PROD" or env == "AKTEST":
            host = f"{region}.*"
            if env == "AKTEST":
                host = f"{region}-aktest.*"
            hosts = [host]
            serverBlockText = ""
            for serverBlockDirective in ["listen 8080;", "server_name ~{};".format(host),
                                         "proxy_ssl_ciphers HIGH:!DH;", "proxy_buffers 8 32k;",
                                         "proxy_buffer_size 32k;",
                                         'add_header Set-Cookie "WSGEO=US|CA|94203|38.5819|-121.4935";']:
                serverBlockText += ' ' * 4 + serverBlockDirective + "\n"
            NGINX_SERVER_BLOCKS.append({"server": serverBlockText})
            NGINX_SERVERBLOCKS_HOSTS_MAPPING[host] = index
            index += 1

    pathRegex, processLater = handleBehaviors(ruleObject, hosts, pathRegex, region, env)

    return pathRegex, index, processLater


def handleRegexHostNameCriteria(criteria, hosts, index, region, env):
    """
    Handler for the hostname criteria that includes a wildcard.
    """
    for value in criteria["options"]["values"]:
        if '*' in value:
            if env == "PROD" or env == "AKTEST":
                replacement = region
                if env == "AKTEST":
                    replacement = f"{region}-aktest"
                regexHost = value.replace('www', replacement)  # replace www in the regex with the corresponding env to form the nginx host regex
            else:
                regexHost = value.replace('www.', '')
                regexHost = re.sub('(ecmqa|ecmuat|perf|regression|qa|uat|staging|bpv|integration|ca)',
                                   r'internal-\1', regexHost)
            regexHost = regexHost.replace('.', '\.').replace('/', '\/').replace('*', '.*').replace('?', '.?')

            # Check for the regex match to the existing nginx hosts
            for host in NGINX_SERVERBLOCKS_HOSTS_MAPPING:
                match = re.match(regexHost, host)
                if match:
                    hosts.append(host)

            hosts.append(regexHost)

            # If the host does not already exist in nginx config, add one with the nginx
            # serverBlock and increment the host index
            if not regexHost in NGINX_SERVERBLOCKS_HOSTS_MAPPING:
                serverBlockText = ""
                for serverBlockDirective in ["listen 8080;", "server_name ~{};".format(regexHost),
                                             "proxy_ssl_ciphers HIGH:!DH;", "proxy_buffers 8 32k;",
                                             "proxy_buffer_size 32k;",
                                             'add_header Set-Cookie "WSGEO=US|CA|94203|38.5819|-121.4935";']:
                    serverBlockText += ' ' * 4 + serverBlockDirective + "\n"
                NGINX_SERVER_BLOCKS.append({"server": serverBlockText})
                NGINX_SERVERBLOCKS_HOSTS_MAPPING[regexHost] = index
                index += 1

    return index


def handleHostNameCriteria(ruleObject, criteria, hosts, index, region, env):
    """
    Handler for the hostname criteria.
    """
    noFurtherProcessing = False
    for value in criteria["options"]["values"]:
        # If the hostname contains a wildcard pattern, skip it for now and process it at the last when handling the
        # rules with regex
        if '*' in value:
            REGEX_HOSTS_RULES.append(ruleObject)
            continue

        # Since akamai has a single property for both prod and aktest rules, filter it here to only consider the hosts
        # applicable for the given env else stop further processing of that rule.
        if env == "PROD":
            if "aktest" in value:
                noFurtherProcessing = True
                return index, noFurtherProcessing
            else:
                # Ex. www.westelm.com replaced to east.westelm.com (nginx host)
                host = value.replace('www', region)
        elif env == "AKTEST":
            if "aktest" in value:
                # Ex. aktest-www.westelm.com replaced to east-akest.westelm.com (nginx host)
                host = value.replace('aktest-www', f"{region}-aktest")
                host = host.replace('aktest-secure', f"{region}-aktest")
            else:
                noFurtherProcessing = True
                return index, noFurtherProcessing
        else:
            # For non-prod, trim the www and replace the env name by adding internal prefix to it.
            host = value.replace('www.', '')
            host = re.sub('(ecmqa|ecmuat|perf|regression|qa|uat|staging|bpv|integration|ca)', r'internal-\1', host)

        hosts.append(host)

        # If the host does not already exist in nginx config, add one with the nginx
        # serverBlock and increment the hostindex
        if not host in NGINX_SERVERBLOCKS_HOSTS_MAPPING:
            serverBlockText = ""
            for serverBlockDirective in ["listen 8080;", "server_name {};".format(host),
                                         "proxy_ssl_ciphers HIGH:!DH;", "proxy_buffers 8 32k;",
                                         "proxy_buffer_size 32k;",
                                         'add_header Set-Cookie "WSGEO=US|CA|94203|38.5819|-121.4935";']:
                serverBlockText += ' ' * 4 + serverBlockDirective + "\n"
            NGINX_SERVER_BLOCKS.append({"server": serverBlockText})
            NGINX_SERVERBLOCKS_HOSTS_MAPPING[host] = index
            index += 1

    return index, noFurtherProcessing


def handlePathCriteria(criteria, pathRegex):
    """
    Handler for the path criteria.
    Convert the inclusion and exclusion rules into the nginx location path regex and return
    """
    matchOperator = criteria["options"]["matchOperator"]
    values = criteria["options"]["values"]

    if matchOperator == "MATCHES_ONE_OF":
        count = 1
        pathRegex += '(^('
        for value in values:
            value = value.replace('.', '\.').replace('*', '.*').replace('?', '.?')
            if count == len(values):
                pathRegex += value
            else:
                pathRegex += value + '|'
            count += 1
        pathRegex += ')$)'

    if matchOperator == "DOES_NOT_MATCH_ONE_OF":
        count = 1
        negationPathRegex = '(^(?!('
        for value in values:
            value = value.replace('.', '\.').replace('*', '.*').replace('?', '.?')
            if count == len(values):
                negationPathRegex += value
            else:
                negationPathRegex += value + '|'
            count += 1
        negationPathRegex += ')))'
        pathRegex = negationPathRegex + pathRegex

    return pathRegex


def handleBehaviors(ruleObject, hosts, pathRegex, region, env):
    """
    Handler for the rule behavior objects
    """
    locationBlocks = []  # Stores all the nginx location configs for this rule

    processLater = False

    # For no hosts and no path rule criterias, there is no point is proceeding
    if not hosts and pathRegex == "":
        return pathRegex, processLater

    # For no hosts but if there is a path criteria or any behavior, process the rule at the end with using
    # wild card hosts
    if not hosts and (pathRegex != "" or "behaviors" in ruleObject["rules"]):
        REGEX_HOSTS_RULES.append(ruleObject)
        processLater = True
        return pathRegex, processLater

    if hosts and "behaviors" in ruleObject["rules"]:
        for behavior in ruleObject["rules"]["behaviors"]:
            behaviorName = behavior["name"]
            if behaviorName == "rewriteUrl":
                handleReWriteBehavior(behavior, locationBlocks)

            if behaviorName == "origin":
                skipThisBehavior = handleOriginBehavior(behavior, env, region, locationBlocks)
                if skipThisBehavior:
                    continue

        if locationBlocks:
            formAndAddNginxServerBlock(pathRegex, hosts, locationBlocks, env, region)

    return pathRegex, processLater


def formAndAddNginxServerBlock(pathRegex, hosts, locationBlocks, env, region):
    """
    Form a location block and add it to the hosts
    """
    # If there is no path regex, use default path '/'
    locationPath = "/"
    if pathRegex != "":
        locationPath = '~* ' + pathRegex
    locationPathBlockMap = {locationPath: locationBlocks}

    # Add location block to all of this hosts
    for host in hosts:
        if env == "PROD" or env == "AKTEST":
            # filter out the hosts as per the dc region
            if (region == "east" and (not re.match(r"\bwest\b", host))) or (
                    region == "west" and (not re.match(r"\beast\b", host))):
                nginxServerBlock = NGINX_SERVER_BLOCKS[NGINX_SERVERBLOCKS_HOSTS_MAPPING[host]]
                locations = nginxServerBlock.get("locations", [])
                # only add if the same location is not already there
                if not checkIfPathPresentInLocation(locationPath, locations):
                    locations.append(locationPathBlockMap)
                    nginxServerBlock["locations"] = locations
        else:
            nginxServerBlock = NGINX_SERVER_BLOCKS[NGINX_SERVERBLOCKS_HOSTS_MAPPING[host]]
            locations = nginxServerBlock.get("locations", [])
            # only add if the same location is not already there
            if not checkIfPathPresentInLocation(locationPath, locations):
                locations.append(locationPathBlockMap)
                nginxServerBlock["locations"] = locations


def handleReWriteBehavior(behavior, locationBlocks):
    """
    Handler for rewrite rule.
    """
    behaviorAction = behavior["options"]["behavior"]
    if behaviorAction == "PREPEND":
        targetPathPrepend = behavior["options"]["targetPathPrepend"]
        if targetPathPrepend == "/{{builtin.AK_DOMAIN}}/":
            domain = "/$host/"
        else:
            domain = ""
            domain = re.sub('(ecmqa|ecmuat|perf|regression|qa|uat|staging|bpv|integration|ca)',
                            r'internal-\1', domain)
        rewriteText = ' ' * 6 + 'rewrite ^(.*)$ ' + domain + '$1;'
        locationBlocks.append(rewriteText)


def handleOriginBehavior(behavior, env, region, locationBlocks):
    """
    Handler for the akamai origin behavior.
    Return True if this behavior is of no use and needs to be skipped
    """
    # If there is a custom host header defined, use that as a proxy_pass for nginx
    forwardHostHeader = behavior["options"]["forwardHostHeader"]
    if forwardHostHeader == "CUSTOM":
        forwardHostName = behavior["options"]["customForwardHostHeader"]
    else:
        forwardHostName = behavior["options"]["hostname"]

    # If any variable in the hostname, replace it with the actual value
    if '{{user.' in forwardHostName:
        forwardHostName = akamaiConfigParser.AKAMAI_VARIABLES[forwardHostName]

    # If any akamai dns name, replace it with WSI domain name for the region
    if "akadns" in forwardHostName:
        forwardHostName = constants.AKAMAI_WSI_DOMAIN[forwardHostName][region]

    if not forwardHostName:
        return True

    # Since akamai has a single property for both prod and aktest rules, filter it here to only consider the origin
    # behaviors which are application to the given env in consideration and skip the others.
    if env == "PROD":
        if "preprd.origin-svc" in forwardHostName or "aktest" in forwardHostName:
            return True
        elif "origin-svc.collectandgather.com" in forwardHostName:
            forwardHostName = forwardHostName.replace('origin-svc', f"origin-{region}-svc")
        elif ("origin-ab" in forwardHostName or "origin-ash-www" in forwardHostName) and region == "west":
            return True
        elif ("origin-rk" in forwardHostName or "origin-sac-www" in forwardHostName) and region == "east":
            return True
        elif "origin-akab" in forwardHostName or "origin-akrk" in forwardHostName:
            return True
        elif "origin-svc" in forwardHostName:
            forwardHostName = f"{region}.{forwardHostName}"

        # set the proxy header only for the DP routes
        shouldSetProxyHeader = any(hostPrefix in forwardHostName for hostPrefix in ["origin-ab-www", "origin-rk-www",
                                                                                    "origin-ash-www", "origin-sac-www"])

        # For DP routes, change the hostname to use the internal VIP so when ESRE switches the traffic, internal VIP
        # will still point to the same region as opposed to the origin akamai VIP which gets point to the region to
        # which traffic is moved.
        if shouldSetProxyHeader:
            forwardHostName = forwardHostName.replace('origin', 'origin-internal')
    elif env == "AKTEST":
        if "origin-svc.collectandgather.com" in forwardHostName:
            forwardHostName = forwardHostName.replace('origin-svc', f"origin-{region}-svc")
        elif ("origin-akab" in forwardHostName or "origin-ab" in forwardHostName or
              "origin-ash" in forwardHostName) and region == "west":
            return True
        elif ("origin-akrk" in forwardHostName or "origin-rk" in forwardHostName or
              "origin-sac" in forwardHostName) and region == "east":
            return True
        elif ("origin-ab" in forwardHostName or "origin-rk" in forwardHostName or "origin-sac" in
              forwardHostName or "origin-ash" in forwardHostName) and not "aktest" in forwardHostName:
            return True
        elif "origin-aktest-www" in forwardHostName:
            if region == "west":
                forwardHostName = forwardHostName.replace('origin-aktest-www', 'origin-rk-aktest')
            else:
                forwardHostName = forwardHostName.replace('origin-aktest-www', 'origin-ab-aktest')
        elif "preprd.origin-svc" in forwardHostName:
            forwardHostName = forwardHostName.replace('preprd', f"preprd-{region}")
        elif "origin-svc" in forwardHostName:
            return True

        # set the proxy header only for the DP routes
        shouldSetProxyHeader = any(hostPrefix in forwardHostName for hostPrefix in ["origin-ab-aktest", "origin-rk-aktest",
                                                                                    "origin-ash-aktest", "origin-sac-aktest"])

    proxyPassText = ' ' * 6 + "proxy_pass https://" + forwardHostName + ";"
    if shouldSetProxyHeader:
        proxyPassText += "\n" + ' ' * 6 + "proxy_set_header   Host $host;"
    locationBlocks.append(proxyPassText)

    return False


def checkIfPathPresentInLocation(locationPath, locations):
    """
    Check and return if a locationPath is already present in the list.
    """
    for location in locations:
        if locationPath in location:
            return True
    return False

