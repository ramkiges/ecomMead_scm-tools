#!/usr/bin/env python3
"""
Utility to get the current prod version for services of different package types
and different k8s deploy type
"""
import subprocess
import time
import warnings
from releaseChangelog import constants
from wsgc import util
from kubernetes.client.rest import ApiException
from kubernetes import config
import kubernetes.client


def getK8sEcomAppVersionInProd(appNamespace, packagingType, helmImageName, kubeDeployType="deploy"):
    """
    Get the ecom app version for app running in K8s for different package type and different kube deploy type
    """

    warnings.filterwarnings('ignore')

    appVersion = None
    with kubernetes.client.ApiClient(config.load_kube_config(config_file=constants.PROD_SAC_ECOM_KUBECONFIG)) as apiClient:
        if kubeDeployType == "deploy":
            appVersion = getAppVersionForK8sDeployType(apiClient, appNamespace, helmImageName, packagingType)
        elif kubeDeployType == "cronjob":
            # For cronjob type call both v1 and v1beta1 as we have apps running on v1beta1
            appVersion, apiStatus = getAppVersionForK8sCronjobType(apiClient, appNamespace, helmImageName, packagingType)
            if appVersion is None and apiStatus == 404:
                appVersion, apiStatus = getAppVersionForK8sCronjobType(apiClient, appNamespace, helmImageName,
                                                                       packagingType, "v1beta1")
        elif kubeDeployType == "job":
            appVersion = getAppVersionForK8sJobType(apiClient, appNamespace, helmImageName, packagingType)
    return appVersion


def getK8sEcomAppVersionDeployDateInProd(appNamespace, packagingType, helmImageName, appVersionDeployed,
                                         kubeDeployType="deploy"):
    """
    Get the deploy date for the version running in prod for ecom app for different package type and kube deploy type
    """

    warnings.filterwarnings('ignore')

    # Get the helm release name
    getReleaseCommand = f"helm --kubeconfig={constants.PROD_SAC_ECOM_KUBECONFIG} list -n {appNamespace} -q"
    otherArgs = {'stderr': subprocess.DEVNULL}
    helmRelease = util.run(getReleaseCommand, **otherArgs)
    helmRelease = helmRelease.split('\n')[0]

    # List helm release revision history
    listRevisionsCommand = f"helm --kubeconfig={constants.PROD_SAC_ECOM_KUBECONFIG} history {helmRelease} -n {appNamespace}"
    revisions = util.run(listRevisionsCommand, **otherArgs)
    revisions = revisions.split('\n')

    curRevision = None
    revisionNumbers = {}
    # Extract revision date and app version from revision history
    for revisionEntry in revisions[1:]:
        splits = revisionEntry.split("\t")
        if len(splits) > 1:
            revisionNumber = splits[0].strip()
            revisionDate = splits[1].strip()
            revisionStructTime = time.strptime(revisionDate)
            revisionDateFormatted = time.strftime('%Y-%m-%dT%H:%M:%SZ', revisionStructTime)
            appVersion = splits[4].strip()

            revisionNumbers[revisionNumber] = {
                "date": revisionDateFormatted,
                "appVersion": appVersion
            }

            if "deployed" in revisionEntry:
                curRevision = revisionNumber

    # if only one revision than that has the deploy date
    if len(revisionNumbers) == 1:
        return revisionNumbers[curRevision]["date"]

    revNumbers = list(revisionNumbers.keys())
    revNumbers.sort(reverse=True)
    curRevisionIndex = revNumbers.index(curRevision)
    appDeployDate = revisionNumbers[curRevision]["date"]

    # Iterate over all revisions to find out when the app version was changed
    for revNumber in revNumbers[curRevisionIndex + 1:]:
        # For legacy packaging we can diretly use the app version from the helm revision command. For helm packaging,
        # that version is always 0.0.0 so fetch from the manifest deploy file.
        if packagingType == "legacy-helm":
            candidateAppversion = revisionNumbers[revNumber]["appVersion"]
        elif packagingType == "helm":
            candidateAppversion = getAppVersionFromRevision(appNamespace, helmRelease, revNumber, kubeDeployType, helmImageName)
        if candidateAppversion != appVersionDeployed:
            break
        appDeployDate = revisionNumbers[revNumber]["date"]

    return appDeployDate


def getAppVersionFromRevision(appNamespace, helmRelease, revision, kubeDeployType, helmImageName):
    """
    Get the manifest files for a particular helm revision and extract the app version from it.
    Look for the correct manifest file based on the kube deploy type.
    """

    appVersion = None
    getManifestForRevisionCommand = f"helm get manifest {helmRelease} --revision={revision} " \
                                    f"--kubeconfig={constants.PROD_SAC_ECOM_KUBECONFIG} -n {appNamespace}"
    otherArgs = {'stderr': subprocess.DEVNULL}
    manifests = util.run(getManifestForRevisionCommand, **otherArgs)
    manifests = manifests.split('---')
    deployManifest = None
    for manifest in manifests:
        if kubeDeployType == "cronjob":
            if 'kind: CronJob' in manifest:
                deployManifest = manifest
                break
        elif kubeDeployType == "deploy":
            if 'kind: Deployment' in manifest:
                deployManifest = manifest
                break

    if deployManifest:
        manifestLines = deployManifest.split("\n")
        for manifestLine in manifestLines:
            if helmImageName in manifestLine:
                appVersion = manifestLine.split(":")[-1]
                break

    return appVersion


def getAppVersionForK8sDeployType(apiClient, appNamespace, helmImageName, packagingType):
    """
    Get the ecom app version for app running in K8s for different package type and a "deploy" K8s type
    For helm package type, get the app version from the container image
    For legacy-helm package type, get the app version from the metadata annotations
    """

    appVersion = None
    try:
        apiInstance = kubernetes.client.AppsV1Api(apiClient)
        apiResponse = apiInstance.list_namespaced_deployment(appNamespace, pretty=True)
        if apiResponse:
            for deploymentObj in apiResponse.items:
                annotations = deploymentObj.spec.template.metadata.annotations
                if packagingType == "helm":
                    containers = deploymentObj.spec.template.spec.containers
                    for container in containers:
                        image = container.image
                        if helmImageName in image:
                            appVersion = image.split(":")[-1]
                            break
                    if appVersion:
                        break
                elif packagingType == "legacy-helm":
                    if "appVersion" in annotations:
                        appVersion = annotations["appVersion"]
                        break
    except ApiException as e:
        print(f"Exception when calling CoreV1Api: {e}")
    return appVersion



def getAppVersionForK8sCronjobType(apiClient, appNamespace, helmImageName, packagingType, apiversion="v1"):
    """
    Get the ecom app version for app running in K8s for different package type and a "cronjob" K8s type
    Different K8s api versions are supported as we have some apps still using v1beta1 api type.
    For helm package type, get the app version from the container image
    For legacy-helm package type, get the app version from the metadata annotations
    """

    appVersion = None
    apiStatus = 0
    try:
        if apiversion == "v1beta1":
            apiInstance = kubernetes.client.BatchV1beta1Api(apiClient)
        else:
            apiInstance = kubernetes.client.BatchV1Api(apiClient)
        apiResponse = apiInstance.list_namespaced_cron_job(appNamespace, pretty=True)
        if apiResponse:
            for cronjobObj in apiResponse.items:
                annotations = cronjobObj.spec.job_template.spec.template.metadata.annotations
                if packagingType == "helm":
                    containers = cronjobObj.spec.job_template.spec.template.spec.containers
                    for container in containers:
                        image = container.image
                        if helmImageName in image:
                            appVersion = image.split(":")[-1]
                            break
                    if appVersion:
                        break
                elif packagingType == "legacy-helm":
                    if "appVersion" in annotations:
                        appVersion = annotations["appVersion"]
                        break
    except ApiException as e:
        print(f"Exception when calling CoreV1Api: {e}")
        apiStatus = e.status
    return appVersion, apiStatus


def getAppVersionForK8sJobType(apiClient, appNamespace, helmImageName, packagingType):
    """
    Get the ecom app version for app running in K8s for different package type and a "job" K8s type
    For helm package type, get the app version from the container image
    For legacy-helm package type, get the app version from the metadata annotations
    """

    appVersion = None
    try:
        apiInstance = kubernetes.client.BatchV1Api(apiClient)
        apiResponse = apiInstance.list_namespaced_job(appNamespace, pretty=True)
        if apiResponse:
            for jobObj in apiResponse.items:
                annotations = jobObj.spec.template.metadata.annotations
                if packagingType == "helm":
                    containers = jobObj.spec.template.spec.containers
                    for container in containers:
                        image = container.image
                        if helmImageName in image:
                            appVersion = image.split(":")[-1]
                            break
                    if appVersion:
                        break
                elif packagingType == "legacy-helm":
                    if "appVersion" in annotations:
                        appVersion = annotations["appVersion"]
                        break
    except ApiException as e:
        print(f"Exception when calling CoreV1Api: {e}")
    return appVersion
