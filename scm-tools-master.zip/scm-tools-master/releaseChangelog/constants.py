#!/usr/bin/env python3

ALL_BRANDS = [
    'we',
    'ws',
    'pb',
    'pk',
    'pt',
    'mg',
    'rj',
    'gr'
]

# For repos having multiple brands deployment from same app repo are using {WS} as placeholder which is
# later replaced for each of the brands while using this constant.
ECOM_K8S_SERVICES_MAP = {
    'aos-login': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/aos-login-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/aos-login-k8s-package',
        'prod_namespace': 'ecommerce-aos-login-prod',
    },
    'assortment-export-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/assortment-export-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/assortment-export-{WS}-k8s-package',
        'prod_namespace': 'ecommerce-assortment-export-{WS}-prod',
    },
    'avs-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/avs-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/avs-service-helm-config',
        'prod_namespace': 'ecommerce-avs-service-prod',
        'helm_image': 'avs-war'
    },
    'b2b-app-product-finding': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/b2b-app-product-finding',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/b2b-app-product-finding-helm-config',
        'prod_namespace': 'ecommerce-b2b-app-product-finding-prod',
        'helm_image': 'b2b-app-product-finding'
    },
    'c3': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/c3-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/c3-helm-config',
        'prod_namespace': 'ecommerce-c3-prod',
        'helm_image': 'c3'
    },
    'cart-checkout': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/cart-checkout',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/cart-checkout-k8s-package',
        'prod_namespace': 'ecommerce-cart-checkout-prod',
    },
    'customer-data-privacy-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/customer-data-privacy-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/cdps-k8s-package',
        'prod_namespace': 'ecommerce-cdps-prod',
    },
    'delivery-gateway': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-app-delivery',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/delivery-gateway-helm-config',
        'prod_namespace': 'ecommerce-delivery-gateway-prod',
        'helm_image': 'delivery-gateway'
    },
    'ecom-admin-app-brand-build-activator': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-admin-app-brand-build-activator',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-build-activation-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-build-activation-prod',
        'helm_image': 'admin-app-brand-build-activator'
    },
    'ecom-app-config-all': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-config-all',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-config-all-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-config-all-prod',
        'helm_image': 'ecom-app-config-all'
    },
    'ecom-app-content': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-content',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-content-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-content-prod',
        'helm_image': 'ecom-app-content'
    },
    'ecom-app-content-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-content',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-content-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-content-prodrj',
        'helm_image': 'ecom-app-content'
    },
    'ecom-app-customer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-customer',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-customer-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-customer-prod',
        'helm_image': 'ecom-app-customer'
    },
    'ecom-app-global': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-global',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-global-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-global-prod',
        'helm_image': 'ecom-app-global'
    },
    'ecom-app-global-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-global',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-global-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-global-prodrj',
        'helm_image': 'ecom-app-global'
    },
    'ecom-app-order-servicing': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-order-servicing',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-order-servicing-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-order-servicing-prod',
        'helm_image': 'ecom-app-order-servicing'
    },
    'ecom-app-order-servicing-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-order-servicing',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-order-servicing-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-order-servicing-prodrj',
        'helm_image': 'ecom-app-order-servicing'
    },
    'ecom-app-phygital': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-phygital',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-phygital-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-phygital-prod',
        'helm_image': 'ecom-app-phygital'
    },
    'ecom-app-product': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-product',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-product-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-product-prod',
        'helm_image': 'ecom-app-product'
    },
    'ecom-app-product-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-product',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-product-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-product-prodrj',
        'helm_image': 'ecom-app-product'
    },
    'ecom-app-registry': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-registry',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-registry-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-registry-prod',
        'helm_image': 'ecom-app-registry'
    },
    'ecom-app-shop': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-shop',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-shop-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-shop-prod',
        'helm_image': 'ecom-app-shop'
    },
    'ecom-app-shop-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-app-shop',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-app-shop-helm-config',
        'prod_namespace': 'ecommerce-ecom-app-shop-prodrj',
        'helm_image': 'ecom-app-shop'
    },
    'ecom-svc-asset': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-asset',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-asset-k8s-package',
        'prod_namespace': 'ecommerce-ecom-svc-asset-prod',
    },
    'ecom-svc-catalog': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-catalog-webapp',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-catalog-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-catalog-prod',
        'helm_image': 'wsgc-ecom-svc-catalog-webapp'
    },
    'ecom-svc-catalog-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-catalog-webapp',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-catalog-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-catalog-prodrj',
        'helm_image': 'wsgc-ecom-svc-catalog-webapp'
    },
    'ecom-svc-content': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-content-webapp',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-content-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-content-prod',
        'helm_image': 'wsgc-content-webapp'
    },
    'ecom-svc-content-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-content-webapp',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-content-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-content-prodrj',
        'helm_image': 'wsgc-content-webapp'
    },
    'ecom-svc-customer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-customer',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-customer-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-customer-prod',
        'helm_image': 'webapp'
    },
    'ecom-svc-order-servicing': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-order-servicing',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-order-servicing-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-order-servicing-prod',
        'helm_image': 'wsgc-orderservicing-webapp'
    },
    'ecom-svc-order-servicing-rj': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-order-servicing',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-order-servicing-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-order-servicing-prodrj',
        'helm_image': 'wsgc-orderservicing-webapp'
    },
    'ecom-svc-phygital': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-phygital',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-phygital-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-phygital-prod',
        'helm_image': 'wsgc-ecom-svc-phygital-webapp'
    },
    'ecom-svc-registry': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-registry-webapp',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-svc-registry-helm-config',
        'prod_namespace': 'ecommerce-ecom-svc-registry-prod',
        'helm_image': 'wsgc-registry-webapp'
    },
    'experimentation-proxy': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/experimentation-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/experimentation-proxy-helm-config',
        'prod_namespace': 'ecommerce-experiment-proxy-prod',
        'helm_image': 'experimentation-proxy'
    },
    'experimentation-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/experimentation-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/experimentation-service-helm-config',
        'prod_namespace': 'ecommerce-experimentation-prod',
        'helm_image': 'experimentation-service'
    },
    'favorites-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/favorites-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/favorites-helm-config',
        'prod_namespace': 'ecommerce-favorites-service-prod',
        'helm_image': 'favorites-service'
    },
    'inventory-assortment-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory-assortment-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-assortment-service-helm-config',
        'prod_namespace': 'ecommerce-ias-prod',
        'helm_image': 'inventory-assortment-service'
    },
    'inventory-capacity-event-consumer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-capacity-event-consumer-helm-config',
        'prod_namespace': 'ecommerce-inventory-capacity-prod',
        'helm_image': 'inventory-capacity-event-consumer'
    },
    'inventory-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-service-helm-config',
        'prod_namespace': 'ecommerce-inventory-service-prod',
        'helm_image': 'inventory-service'
    },
    'inventory-refresh-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory-refresh-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-refresh-service-helm-config',
        'prod_namespace': 'ecommerce-inventory-refresh-service-prod',
        'helm_image': 'inventory-refresh-service'
    },
    'inventory-state-event-consumer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-state-event-consumer-helm-config',
        'prod_namespace': 'ecommerce-inventory-state-prod',
        'helm_image': 'inventory-state-event-consumer'
    },
    'inventory-transit-schedule-consumer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory-transit-schedule-consumer',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-transit-schedule-consumer-helm-config',
        'prod_namespace': 'ecommerce-itsc-prod',
        'helm_image': 'inventory-transit-schedule-consumer'
    },
    'inventory-transit-schedule-processor': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory-transit-schedule-processor',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/inventory-transit-schedule-processor-helm-config',
        'prod_namespace': 'ecommerce-itsp-prod',
        'helm_image': 'inventory-transit-schedule-processor'
    },
    'mdm-consumer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/mdm-consumer-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/mdm-consumer-helm-config',
        'prod_namespace': 'ecommerce-mdm-consumer-prod',
        'helm_image': 'mdm-consumer'
    },
    'ecom-order-utility': {
        'app_repo_url': 'https://github.wsgc.com/ESRE-Bedrock/ecom-order-utility',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/order-utility-helm-config',
        'prod_namespace': 'ecommerce-order-utility-prod',
        'helm_image': 'ecom-order-utility'
    },
    'privacy-ecom-processor': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/privacy-ecom-processor',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/privacy-ecom-processor-k8s-package',
        'prod_namespace': 'ecommerce-privacy-ecom-processor-prod',
        'kube_deploy_type': 'cronjob'
    },
    'profile-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/profile',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/profile-helm-config',
        'prod_namespace': 'ecommerce-profile-prod',
        'helm_image': 'wsgc-profile-service'
    },
    'data-loaders': {
        'app_repo_url': 'https://github.wsgc.com/Platform-Data/data-loaders',
        'packaging_repo_url': 'https://github.wsgc.com/Platform-Data/recommend-dataloader-helm-config',
        'prod_namespace': 'ecommerce-recommend-prod',
        'helm_image': 'data-loaders-web'
    },
    'recommendations-admin': {
        'app_repo_url': 'https://github.wsgc.com/Platform-Data/recommendations-admin',
        'packaging_repo_url': 'https://github.wsgc.com/Platform-Data/recommend-admin-helm-config',
        'prod_namespace': 'ecommerce-recommend-prod',
        'helm_image': 'recommendations-admin-war'
    },
    'recommendation-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/recommendation-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/recommend-helm-config',
        'prod_namespace': 'ecommerce-recommend-prod',
        'helm_image': 'recommendation-service-war'
    },
    'registry-admin': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/registry-admin',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/registry-admin-{WS}-helm-config',
        'prod_namespace': 'ecommerce-registry-admin-{WS}-prod',
        'helm_image': 'wsgc-reg-admin'
    },
    'registryv2': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/registry',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/registryv2-k8s-package',
        'prod_namespace': 'ecommerce-registryv2-prod',
    },
    'rtim-event-consumer': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/inventory',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/rtim-event-consumer-helm-config',
        'prod_namespace': 'ecommerce-rtim-event-consumer-prod',
        'helm_image': 'rtim-event-consumer'
    },
    'business-sales-connector-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/business-sales-connector-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/salesforceconnector-helm-config',
        'prod_namespace': 'ecommerce-salesforceconnector-prod',
        'helm_image': 'businesssalesconnector-app'
    },
    'short-token': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/short-token',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/short-token-helm-config',
        'prod_namespace': 'ecommerce-shorttoken-prod',
        'helm_image': 'wsgc-short-token-webapp'
    },
    'ecom-sitemap-data-orchestrator': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-sitemap-data-orchestrator',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ecom-sitemap-data-orchestrator-helm-config',
        'prod_namespace': 'ecommerce-sitemap-data-orchestrator-prod',
        'helm_image': 'sitemap-job',
        'kube_deploy_type': 'cronjob'
    },
    'stored-value-card-orchestration': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/stored-value-card-orchestration-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/stored-value-card-orchestration-service-helm-config',
        'prod_namespace': 'ecommerce-stored-value-card-orchestration-prod',
        'helm_image': 'stored-value-card-orchestration'
    },
    'stores-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/stores-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/storelocator-helm-config',
        'prod_namespace': 'ecommerce-storelocator-prod',
        'helm_image': 'wsgc-storelocator'
    },
    'recipe-content-sync-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ws-recipe-content-sync',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ws-recipe-content-sync-helm-config',
        'prod_namespace': 'ecommerce-ws-recipe-content-sync-prod',
        'helm_image': 'wsgc-recipe-content-sync-service'
    },
    'ws-recipe-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ws-recipe-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/ws-recipe-service-helm-config',
        'prod_namespace': 'ecommerce-ws-recipe-service-prod',
        'helm_image': 'wsgc-recipes-webapp'
    },
    'wsi-b2b': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/wsi-b2b',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/wsi-b2b-helm-config',
        'prod_namespace': 'ecommerce-wsi-b2b-prod',
        'helm_image': 'wsi-b2b'
    },
    'credit-card-orchestration-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/credit-card-orchestration-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/credit-card-orchestration-service-helm-config',
        'prod_namespace': 'enterprise-cc-orchestration-prod',
        'helm_image': 'wsgc-creditcard-orchestration-webapp'
    },
    'credit-card-tokenization-service': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/credit-card-tokenization-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/credit-card-tokenization-service-helm-config',
        'prod_namespace': 'enterprise-cc-tokenization-prod',
        'helm_image': 'cc-tokenization'
    },
    'membership-service': {
        'app_repo_url': 'https://github.wsgc.com/Enterprise-Services/membership-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/membership-service-helm-config',
        'prod_namespace': 'enterprise-membership-service-prod',
        'helm_image': 'membership-service-war'
    },
    'reward-certificate-service': {
        'app_repo_url': 'https://github.wsgc.com/Enterprise-Services/reward-certificate-service',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/reward-certificate-service-helm-config',
        'prod_namespace': 'enterprise-reward-certificate-service-prod',
        'helm_image': 'reward-certificate-service'
    },
    'etcd-syncappconfig': {
        'app_repo_url': 'https://github.wsgc.com/eCommerce-Bedrock/ecom-svc-app-delivery',
        'packaging_repo_url': 'https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/etcd-syncappconfig-k8s-package',
        'prod_namespace': 'ecommerce-etcd-syncappconfig-prod',
        'kube_deploy_type': 'job'
    },
}

ECOM_KUBE_SERVICE_ACCOUNT = "svcak8sci"
ECOM_PROD_SAC_KUBE_CLUSTER = "ts-sharedplatform-sac-prod"

MFE_BUILD_PROD_SAC_DOMESTIC_RUNDECK_JOB_IDS = {
    'MG': '64dab493-730b-4128-863e-c628c573ef6c',
    'PB': 'd9b4d557-05ca-4fed-8fc0-d4c2a0b5e43c',
    'PK': '538c4927-3ed0-4ff3-b507-03c0b76cf4f1',
    'PT': 'cd2d5e9a-3a93-4d3b-9f78-b0b532fd6b75',
    'WE': '45156b2d-f5e4-446b-8f75-a934bb8ddbf8',
    'WS': '0554d86f-f466-403a-9c91-8a3418f5607f',
    'RJ': '09784544-ce65-49ac-b587-d1084498fc64',
    'GR': 'c5bbe941-b5f4-4ecf-b201-b3f5b8a93a1d'
}

PROD_SAC_ECOM_KUBECONFIG = f"/var/lib/jenkins/.kube/{ECOM_KUBE_SERVICE_ACCOUNT}/{ECOM_PROD_SAC_KUBE_CLUSTER}"
