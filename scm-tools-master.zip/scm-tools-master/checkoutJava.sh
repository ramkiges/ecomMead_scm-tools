#!/bin/bash
#
# checkoutJava.sh
#
# Check out the dp-sites repo listed in java.yaml into a directory
# named "java/dp-sites".  If the directory already exists, fail with
# an error message.
#
# This is intended for use upon the first checkout of a shortcut, to
# create the Java for it within the given shortcut directory structure.
#
# Tooling exists that expects the directory to be named
# "java/dp-sites"; do not change that here without also changing it in
# other tooling.
#
# This SCM location for this script is:
#
#    https://github.wsgc.com/eCommerce-DevOps/scm-tools
#
# Its latest version should be copied to each of:
#
#    https://repos.wsgc.com/svn/shortcuts/evolution/trunk
#    https://repos.wsgc.com/svn/shortcuts/evolution/branches/trunk-shortcut
#    https://repos.wsgc.com/svn/shortcuts/evolution/branches/shortcut_dp_template_no_java
#
# in order that it by usable by those shortcuts and copies of them.

set -e
set -o nounset

JAVA_YAML="java.yaml"
DP_SITES_DIR="java/dp-sites"

if [[ ! -f $JAVA_YAML ]]; then
    echo "[ERROR] No '$JAVA_YAML' found in the current directory." >&2
    exit 1
fi

lookupValueFromKey() {
    # Given a keyword (one of "organization", "repo", or "branch"),
    # look up the value in the java.yaml file, whose structure looks
    # like, e.g.,
    #
    #    organization: eCommerce-Bedrock
    #    repo: dp-sites
    #    branch: release
    #
    # This routine doesn't guard against regexp characters in the key,
    # or accomodate spaces in the values, which isn't expected to be a
    # problem for its intended use.
    #
    # Guard against Macs confusing \r-before-\n as part of the value,
    # when java.yaml has DOS line endings on a Mac.  (Checking out
    # files with DOS line endings is common at WSI among users who use
    # Tortoise to interact with Subversion while also use the Mac CLI
    # in those same repos.)  Note that this doesn't guard against
    # *this script* being checked out in such a manner!  But a user
    # could (and did) figure out how to adjust line endings on this
    # script without also doing so for java.yaml.
    local key=$1
    local prefix="^ *$key: *"
    local cr=$'\r'
    local value=$(sed -E -n "/$prefix/s/$prefix([^ $cr]+).*$/\\1/p" "$JAVA_YAML")

    echo "$value"
}

main() {
    local GHE_ORG=$(lookupValueFromKey "organization")
    local GHE_REPO=$(lookupValueFromKey "repo")
    local GHE_BRANCH=$(lookupValueFromKey "branch")

    if [[ $GHE_REPO != "dp-sites" ]]; then
        echo "[WARN] The repository is not named 'dp-sites', which is highly unusual"
        echo "[WARN] Continuing with repository '$GHE_REPO'..."
    fi

    if [[ -d $DP_SITES_DIR ]] && ! rmdir "$DP_SITES_DIR" &>/dev/null; then
        # The directory exists and was not empty.
        echo "[ERROR] Directory '$DP_SITES_DIR' already exists." >&2
        echo "[ERROR] You may remove it and rerun this if you are sure that you" >&2
        echo "[ERROR] no longer need the existing Java checkout." >&2
        exit 1
    fi

    mkdir -p "$DP_SITES_DIR"

    local GHE_URL="git@github.wsgc.com:$GHE_ORG/$GHE_REPO"
    echo "Cloning branch $GHE_BRANCH of $GHE_ORG/$GHE_REPO into $DP_SITES_DIR..."
    git clone -b "$GHE_BRANCH" "$GHE_URL" "$DP_SITES_DIR"
}

main
