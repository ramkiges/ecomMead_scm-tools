"""
gheTools_test.py

Unit tests for wsgc/gheTools.py.

Run from top-level scm-tools dir as 'PYTHONPATH=. tests/gheTools_test.py'.
"""
import unittest

from wsgc import semver
from wsgc import gheTools


class GHEToolsTestCase(unittest.TestCase):
    def test_getVersionChangeInHunk(self):
        def runSubtest(pipelineType, diff, expectedOldver, expectedNewver):
            with self.subTest(pipelineType=pipelineType):
                nodeSemverConfigs = semver.PIPELINE_SEMVER_CONFIGS[pipelineType]
                nodeSearchTemplate = nodeSemverConfigs['searchTemplate']
                oldver, newver = gheTools.getVersionChangeInHunk(diff, nodeSearchTemplate)
                self.assertEqual((oldver, newver), (expectedOldver, expectedNewver))

        # Node.
        nodeDiff = """diff --git a/package.json b/package.json
index ccf0256cde..4ef3fa556b 100644
--- a/package.json
+++ b/package.json
@@ -1,6 +1,6 @@
 {
   "name": "ecom-app-shop",
-  "version": "0.2.0",
+  "version": "0.2.10",
   "description": "microfrontend (MFE) for the /shop portion of the ecommerce site",
   "main": "src/server.js",
   "scripts": {
"""
        runSubtest(pipelineType='Node',
                   diff=nodeDiff,
                   expectedOldver=semver.Semver(0, 2, 0),
                   expectedNewver=semver.Semver(0, 2, 10))

        # Helm Chart.
        helmChartDiff = """diff --git a/Chart.yaml b/Chart.yaml
index 46f22e235a..aa476bc29e 100755
--- a/Chart.yaml
+++ b/Chart.yaml
@@ -2,4 +2,4 @@ apiVersion: v2
 name: node-webapp-chart
 description: A Helm chart for simple Node web apps running on Kubernetes
 type: application
-version: 1.4.0
+version: 2.0.0
diff --git a/values.yaml b/values.yaml
index d35a8bcc91..fda52a30bb 100755
--- a/values.yaml
+++ b/values.yaml
@@ -36,7 +36,7 @@ deployment:
 # since the last time the host pulled it down.  Change to IfNotPresent
 # if you only ever rely on fixed image tags (as in prod configs,
 # perhaps) and want to skip that (typically) quick step during deployment.
-imagePullPolicy: Always
+imagePullPolicy: IfNotPresent
 
 # deployment.image.registry will be used for the nginx registry.
"""
        runSubtest(pipelineType='HelmChart',
                   diff=helmChartDiff,
                   expectedOldver=semver.Semver(1, 4, 0),
                   expectedNewver=semver.Semver(2, 0, 0))

        # Helm Project.
        helmProjectDiff = """diff --git a/README.md b/README.md
index 7420491566..e4cf733ae1 100644
--- a/README.md
+++ b/README.md
@@ -1,2 +1,4 @@
 # wsi-b2b-helm-config
 Helm Project config for the WSI B2B application
+
+Meaningless change.
diff --git a/project.yaml b/project.yaml
index d6196ccb51..d57e358793 100644
--- a/project.yaml
+++ b/project.yaml
@@ -1,3 +1,3 @@
 # Project metadata.
 name: wsi-b2b
-version: 1.6.8
+version: 1.6.10
"""
        runSubtest(pipelineType='HelmProject',
                   diff=helmProjectDiff,
                   expectedOldver=semver.Semver(1, 6, 8),
                   expectedNewver=semver.Semver(1, 6, 10))

        # Python App, version change.
        pythonAppDiff = """diff --git a/app.yaml b/app.yaml
index bd97479bdf..1d9c10f6bd 100644
--- a/app.yaml
+++ b/app.yaml
@@ -1,7 +1,7 @@
 project:
   name: k8s-dashboard
   description: "DevOps Kubernetes Dashboard"
-  version: 0.1.2
+  version: 0.1.1
 
 docker:
   org: ecom
"""
        runSubtest(pipelineType='PythonApp',
                   diff=pythonAppDiff,
                   expectedOldver=semver.Semver(0, 1, 2),
                   expectedNewver=semver.Semver(0, 1, 1))

        # Python App, no version to new version.
        pythonAppDiff = """diff --git a/app.yaml b/app.yaml
index bd97479bdf..1d9c10f6bd 100644
--- a/app.yaml
+++ b/app.yaml
@@ -1,7 +1,7 @@
 project:
   name: k8s-dashboard
   description: "DevOps Kubernetes Dashboard"
+  version: 0.1.1
 
 docker:
   org: ecom
"""
        runSubtest(pipelineType='PythonApp',
                   diff=pythonAppDiff,
                   expectedOldver=None,
                   expectedNewver=semver.Semver(0, 1, 1))


if __name__ == '__main__':
    unittest.main()
