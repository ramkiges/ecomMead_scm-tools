#!/usr/bin/env python3
"""
svnLocks_test.py

Unit tests for svnLocks.py

Run from top-level scm-tools dir as 'wsgc/svnLocks_test.py', or have the
top-level scm-tools dir in your PYTHONPATH.
"""

import os
import unittest
import inspect
import re

from wsgc import svnLocks


class TestLocks(unittest.TestCase):
    @classmethod
    def addNewTest(cls, testName, accessType, username, releaseName,
                   beforeConfFilename, afterConfFilename):
        def newTest(self):
            # Customize the contents of the config file for the username.
            with open(beforeConfFilename) as f:
                confFileContents = f.read()

            confFileContents = confFileContents.replace("__USERNAME__", username)

            conf = svnLocks.ConfFile(confFilename=beforeConfFilename,
                                     releaseName=releaseName,
                                     confFileContents=confFileContents)

            if accessType == "grant":
                conf.grantWriteAccess(username)
            else:
                conf.revokeWriteAccess(username)

            # Open the expected afterimage, update accordingly, and compare with the config file as
            # modified by the grant/revoke.
            with open(afterConfFilename) as f:
                afterConfFileContents = f.read()

            afterConfFileContents = afterConfFileContents.replace("__USERNAME__", username)

            self.assertEqual(conf.asStr(), afterConfFileContents)

        testFuncName = "test_{}".format(testName)
        setattr(TestLocks, testFuncName, newTest)


# Get the absolute path of the test data directory.
ourDir = os.path.dirname(inspect.getfile(inspect.currentframe()))
testDataDir = os.path.join(ourDir, "data")

# Get the list of usernames we want to test.  It is the developer's
# duty to make sure that they're not among the names already present
# in the test file templates.
with open(os.path.join(testDataDir, "usernames")) as f:
    usernames = f.read().splitlines()

with open(os.path.join(testDataDir, "releaseName")) as f:
    releaseName = f.read().splitlines()[0].strip()

for accessType in ("grant", "revoke"):
    confDir = os.path.join(testDataDir, accessType)
    for dirpath, _, filenames in os.walk(confDir):
        for filename in filenames:
            match = re.match(r'^(.*)\.before$', filename)
            if not match:
                continue  # Deal with .after when we see .before

            testNameBase = match.group(1)
            beforeConfFilename = os.path.join(dirpath, filename)
            afterConfFilename = os.path.join(dirpath, "{}.after".format(testNameBase))

            for username in usernames:
                testName = "{}_{}_{}".format(accessType, testNameBase, username)
                TestLocks.addNewTest(testName=testName,
                                     accessType=accessType,
                                     username=username,
                                     releaseName=releaseName,
                                     beforeConfFilename=beforeConfFilename,
                                     afterConfFilename=afterConfFilename)


if __name__ == '__main__':
    unittest.main()
