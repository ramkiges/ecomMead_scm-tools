These directories hold copies of the logrotate configurations active
on the scm-tools box.  There are two, one for the hook server and one
for the merge-o-tron.

On the scm-tools box (scm-toolsprd-rk1 currently), the files reside in
the log directories they govern.  logrotate is called explicitly from
svnowner's crontab on the merge box.

(A copy of that crontab is saved in data/crontabs/merge-o-tron.)
