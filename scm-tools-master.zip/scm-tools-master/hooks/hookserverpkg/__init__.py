"""
WSGI-aware SCM "hook server".

This is a service that can be called to perform tasks in response to SCM events.

For GitHub Enterprise, configure the repository to call this as, e.g.:

  https://scm-toolsprd-rk1.wsgc.com/hooks/ghe_event_handler?jirapr=1

  jirapr=1 enables adding a Jira comment when a PR is created.

Launched by Apache configs contained in wsgc-devops-toolchain-scm-webhooks-config, located at:

  https://github.wsgc.com/eCommerce-DevOps/toolchain-scm-webhooks-config

See the code in individual libs to see the names of Jenkins jobs that we expect to exist.
"""
import logging, sys
from flask import Flask


application = Flask(__name__)
# Handler to log to stdout. Apache will pick up the logs
application.logger.addHandler(logging.StreamHandler(sys.stdout))
application.logger.setLevel(logging.INFO)


from . import gheHooks
from . import rundeckUtils
from . import hooksUtil
from wsgc.util import setupCIEnv


# Apache MOD WSGI doesn't start with the appropriate environment
# variables. This function will setup all needed environment variables
# to run webhooks under Apache.
setupCIEnv()
