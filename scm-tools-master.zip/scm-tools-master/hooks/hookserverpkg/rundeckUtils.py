"""
rundeckUtils.py

Routines implementing miscellaneous utilities for making Rundeck's life easier.
"""

import os
import re
import sys

import flask
import distutils.version

from . import application
from . import hooksUtil

# Include the top-level directory in the lookup path, so we can find the wsgc libs.
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))

import wsgc.util

@application.route('/get-recent-pkg-vers', methods=['GET'])
def get_recent_pkg_vers():
    # Gets the latest versions (defaulting to 5) of the kubernetes package and returns them as a json array
    try:
        request = flask.request
        package = request.args.get('package', '')
        packageType = request.args.get('packageType', '')
        versionsCount = int(request.args.get('versionsCount', '5'))
        if packageType == 'helmProject':
            url = 'https://artifactory.wsgc.com/artifactory/api/search/artifact?name={}&repos=helm-configs-local'.format(package)
        else:
            url = 'https://artifactory.wsgc.com/artifactory/wsgc-releases/com/wsgc/devops/k8s/{}/maven-metadata.xml'.format(package)
        response = wsgc.util.callURL(url)
        body = response.text

        if packageType == 'helmProject':
            latestVersions = re.findall(r'helm-configs-local/{}-(\d+\.\d+\.\d+)\.zip'.format(package), body)
        else:
            latestVersions = wsgc.util.getContentByXPath(body, './/versions/version')
    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    return sorted_items(latestVersions, versionsCount)


@application.route('/get-recent-app-vers', methods=['GET'])
def get_ghe_tags():
    try:
        request = flask.request
        repo = request.args.get('repo', '')
        org = request.args.get('org', 'eCommerce-Bedrock')
        versionsCount = int(request.args.get('versionsCount', '5'))
        tags = wsgc.gheTools.getTagNames(org, repo)
        # This isn't a perfect solution, but should suffice to filter out tags that bear no resemblance to a version number
        versionsIsh = re.compile(r'.*\d+\.\d+\.\d+$')
        latestVersions = list(filter(versionsIsh.match, tags))
    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    return sorted_items(latestVersions, versionsCount)


@application.route('/get-recent-branches', methods=['GET'])
def get_ghe_branches():
    try:
        request = flask.request
        branchesCount = int(request.args.get('branchesCount', '10'))
        releaseBranchesOnly = request.args.get('releaseBranchesOnly', 'true')
        repo = request.args.get('repo', '')
        org = request.args.get('org', 'eCommerce-Bedrock')
        branches = wsgc.gheTools.getBranchNames(org, repo)
        # This isn't a perfect solution, but should suffice to filter out branches that bear no resemblance to releases
        if releaseBranchesOnly == 'true':
            releaseIsh = re.compile(r'release(?:-\d+(?:\.\d+)*(?:\.x)?)?$')
            branches = list(filter(releaseIsh.match, branches))
    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    branches.reverse()
    return flask.jsonify(branches[0:branchesCount])

@application.route('/get-branches-default-sorted', methods=['GET'])
def get_ghe_branches_sorted():
    try:
        request = flask.request
        defaultBranch = request.args.get('defaultBranch', 'release')
        branchesCount = int(request.args.get('branchesCount', '10'))
        releaseBranchesOnly = request.args.get('releaseBranchesOnly', 'true')
        repo = request.args.get('repo', '')
        org = request.args.get('org', 'eCommerce-Bedrock')
        branches = wsgc.gheTools.getBranchNames(org, repo)
        # This isn't a perfect solution, but should suffice to filter out branches that bear no resemblance to releases
        if releaseBranchesOnly == 'true':
            releaseIsh = re.compile(r'release(?:-\d+(?:\.\d+)*(?:\.x)?)?$')
            branches = list(filter(releaseIsh.match, branches))
    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    branches.reverse()
    return sort_with_default(branches[0:branchesCount], defaultBranch)


@application.route('/get-application-list', methods=['GET'])
def get_application_list():
    # Gets the list of repos from eCommerce-Kubernetes-Bedrock as a proxy for applications
    # Optionally, (and by default) filter this list for only helm project repos
    try:
        request = flask.request
        orgName = request.args.get('org', 'eCommerce-Kubernetes-Bedrock')
        helmProjectsOnly = request.args.get('helmOnly', 'true')
        repos = wsgc.gheTools.getOrgRepoNames(orgName=orgName, includeArchived=False)
        if helmProjectsOnly == 'true':
            applications = []
            for repo in repos:
                application = re.match(r'(.*)-helm-config', repo)
                if application:
                    applications.append(application.group(1))
        else:
            applications = repos
            # Future include legacy k8-packages here
    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    applications.sort()
    return flask.jsonify(applications)


@application.route('/get-app-info-from-pkg-ver', methods=['GET'])
def get_app_info_from_pkg_vers():
    # Gets application information from package name and returns them as a json array
    try:
        request = flask.request
        package = request.args.get('package', '')
        packageVersion = request.args.get('packageVersion', '')
        appEnv = request.args.get('appEnv', '')

        headers = {}
        url = 'https://artifactory.wsgc.com/artifactory/api/search/artifact?name={}-{}.zip&repos=helm-configs-local'.format(package, packageVersion)
        headers = {'X-Result-Detail': 'properties'}
        response = wsgc.util.callURL(url=url, headers=headers)
        packageProperties = response.json().get('results')[0]['properties']
        if packageProperties:
            if appEnv in packageProperties:
                appVersion = packageProperties[appEnv][0].split(':')[1]
            else:
                appVersion = packageProperties['default'][0].split(':')[1]
        else:
            appVersion = 'unspecified'

    except Exception as e:
        hooksUtil.dumpStackAndAbort(e)

    return flask.jsonify(appVersion.split())


def sort_with_default(lst, default_element):
    lst.remove(default_element)  # Remove default element from the list
    sorted_list = [default_element] + lst  # Add the default element back at the beginning
    return flask.jsonify(sorted_list)

def sorted_items(items, maxItemCount, reverseSort=True):
    items.sort(key=distutils.version.LooseVersion, reverse=reverseSort)
    return flask.jsonify(items[0:maxItemCount])
