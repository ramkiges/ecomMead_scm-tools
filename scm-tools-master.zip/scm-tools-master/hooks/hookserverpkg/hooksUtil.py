#!/usr/bin/env python3
"""
hooksUtil.py

General-purpose routines supporting the webhook server.
"""

import sys
import os
import traceback

import requests
import flask

# Include the top-level directory in the lookup path, so we can find the wsgc libs.
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..'))
import wsgc.gheTools

# Import the top-level application object that manages our request.
from . import application

# This quiets the squawking about our certs not being signed by a trusted authority.  It may silence
# things we care about more than that, so if we can solve the cert problem some other way that would
# be preferable.  (We have decent certs now, but until we tell Python to trust our custom root
# authority we still need this.)
requests.packages.urllib3.disable_warnings()


JENKINS_URL = 'https://ecombuild.wsgc.com/jenkins'
JIRA_URL = 'https://jira.wsgc.com'

ALLOWED_JDK_VERSIONS = ['1.7', '1.8']


def dumpStackAndAbort(e):
    application.logger.error('Error: %s', e)

    # Magic cribbed from the internet.  The above message doesn't say what line the exception
    # occurred on; dumping the call stack narrows it down to a procedure.
    for frame in traceback.extract_tb(sys.exc_info()[2]):
        fname, lineno, _, text = frame
        application.logger.error("%s, line %d: %s", fname, lineno, text)

    flask.abort(400)


def parsePRViolations(violations):
    """
    Return statusState, msg, for populating back to a GHE PR.
    msg is None on success (no violations), or a length-limited,
    comma-separated combination of the strings in violations.

    The length is limited because GHE will only accept 140 characters
    for the message.
    """
    if violations:
        statusState = wsgc.gheTools.GHE_STATE_FAILURE
        msg = "\n".join(violations)
        MAX_MSG_LEN = 140
        if len(msg) > MAX_MSG_LEN:
            msg = msg[:MAX_MSG_LEN - 3] + "..."
    else:
        statusState = wsgc.gheTools.GHE_STATE_SUCCESS
        msg = None

    return statusState, msg
